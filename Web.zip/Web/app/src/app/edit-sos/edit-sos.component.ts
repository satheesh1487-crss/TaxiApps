import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { VehicleService } from '../common/services/vehicle.service';

@Component({
  selector: 'app-edit-sos',
  templateUrl: './edit-sos.component.html',
  styleUrls: ['./edit-sos.component.scss']
})
export class EditSosComponent implements OnInit {
  isSubmitted
  id: number;
  registerForm: FormGroup;
  constructor(  private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private vehicleService: VehicleService,
    private router: Router) { }

  ngOnInit(): void {
    this.route
    .queryParams
    .subscribe(params => {
      // Defaults to 0 if no query param provided.
      this.id = Number(params['id']);
    });

this.registerForm = this.formBuilder.group({
  name: ['', [Validators.required]],
  number: ['', [Validators.required]], 
});
this.getbyId();
  }
  getbyId(){
    this.vehicleService.getbyEmerId(this.id).subscribe(res => {
        this.registerForm = this.formBuilder.group({
        name: [ res.content.name, [Validators.required]],
        number: [ res.content.number, [Validators.required]], 
      });
    })
  }
  get f() {
    return this.registerForm.controls;
  } 
  submitted
  onSubmit() {
    this.submitted = true;
    this.isSubmitted = true; 
    if (!this.registerForm.valid) {
      return;
    }   
  // stop here if form is invalid
  //if (!this.registerForm.valid) {
  //    return;
 // }
    var serviceModal = {
      name: this.registerForm.controls.name.value,     
      number: this.registerForm.controls.number.value,
      Id: this.id, 
    };
      this.vehicleService.editEmer(serviceModal,this.id).subscribe(res => {
      if (res.isOK) {
        this.router.navigate(['manage-sos']);
      }
    });
  }
}
