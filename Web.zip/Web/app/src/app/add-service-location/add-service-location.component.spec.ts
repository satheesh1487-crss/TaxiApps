import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddServiceLocationComponent } from './add-service-location.component';

describe('AddServiceLocationComponent', () => {
  let component: AddServiceLocationComponent;
  let fixture: ComponentFixture<AddServiceLocationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddServiceLocationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddServiceLocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
