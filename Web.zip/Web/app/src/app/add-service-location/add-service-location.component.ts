import { Component, OnInit } from '@angular/core'; 
import { FormGroup, FormBuilder, Validators } from '@angular/forms'; 
import { Router, ActivatedRoute } from '@angular/router'; 
import { UtilityService } from 'src/app/common/services/utility.service';
import { ServiceLocationService } from 'src/app/common/services/servicelocation.service';
import { CurrencyService } from 'src/app/common/services/currency.service';
import { isGeneratedFile } from '@angular/compiler/src/aot/util';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-add-service-location',
  templateUrl: './add-service-location.component.html',
  styleUrls: ['./add-service-location.component.scss']
})
export class AddServiceLocationComponent implements OnInit {
  
  countries;
  zones;
  submitted =false;
  currencyList;
  currencysymbolList
  registerForm: FormGroup; 
  constructor(private utilityServcice: UtilityService,
    private serviceLocationService: ServiceLocationService,
    private currencyService: CurrencyService,
    private snackBar: MatSnackBar,
    private formBuilder: FormBuilder, 
    private router: Router) {  this.registerForm = this.formBuilder.group({
      serviceName: ['', Validators.required],
      Country: ['', Validators.required],
      Currencycode: ['', Validators.required],
      Countrysymbol: ['', Validators.required],
      TimeZone: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.fillDrop();
}
 
dropChange(evt,role){
this.utilityServcice.getZoneBycountryId(evt).subscribe(res => {
  this.zones = res.content;
});
this.currencyService.list().subscribe(res => {
  this.currencysymbolList= this.currencyList = res.content;
});
}
  
fillcountry(){
  this.utilityServcice.listCountry().subscribe(res => {
    this.countries = res.content;
  });
} 
 
  fillDrop() {  
     this.fillcountry();
  }
  onSubmit() {
    this.submitted = true;
    if (!this.registerForm.valid) {
      return;
    }
    var serviceModal = {
      serviceName: this.registerForm.controls.serviceName.value,
      countryId: this.registerForm.controls.Country.value,
      currencyId: this.registerForm.controls.Currencycode.value,
      symbolCurrencyId: this.registerForm.controls.Countrysymbol.value,
      timezoneId: this.registerForm.controls.TimeZone.value,    
    };
  
    this.serviceLocationService.save(serviceModal).subscribe(res => {
      if (res.isOK) {
        this.router.navigate(['service-location']);
      }
      else
      {
        this.snackBar.open(res.message, 'Fechar', {
          duration: 2000,
          panelClass: ['close-snackbar']
        });
      }
    });
  }
  cancel(){
    this.router.navigate(['service-location']);
  }
  get f() { return this.registerForm.controls; }
}
