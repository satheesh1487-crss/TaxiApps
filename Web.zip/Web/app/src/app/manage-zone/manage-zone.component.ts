import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { ZoneService } from '../common/services/zone.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-manage-zone',
  templateUrl: './manage-zone.component.html',
  styleUrls: ['./manage-zone.component.scss']
})
export class ManageZoneComponent implements OnInit {
  displayedColumns: string[] = ['no', 'zonename', 'serviceName','status', 'action'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  result: any;

  constructor(public zoneService: ZoneService,
    public router: Router, private dialog: MatDialog,
    private snackBar: MatSnackBar) { }


  ngOnInit(): void {
   this.fillZoneList();
  }
  fillZoneList(){
    this.zoneService.listZone().subscribe(res => {
      this.dataSource = new MatTableDataSource(res.content);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    })
  }
  ngAfterViewInit() {
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }
  redirectMap(id){
    this.router.navigate(['map-view'], { queryParams: { id: id } });
  }
  redirectEdit(id) {
    this.router.navigate(['edit-zone'], { queryParams: { id: id } });
  }
  updateStatus(id,status,isDelete) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        message: isDelete==true?'Are you sure want to delete?':'Are you sure want to change status?',
        buttonText: {
          primarybtn: 'Confirm',
          cancelbtn: 'Cancel'
        }
      }
    });

    dialogRef.afterClosed().subscribe((confirmed) => {
      if (confirmed.isOk) {
        if(isDelete){
       this.delete(id);
      }else{
        this.changestatus(id,status);
      }
      }
    });
  }
 
delete(id)
{
  this.zoneService.delete(id).subscribe(res => {
    if (res.isOK) {
      this.snackBar.open(res.message, 'Fechar', {
        duration: 2000,
        panelClass: ['delete-snackbar']
      });
      this.fillZoneList();
    }
  });
}
changestatus(id,status)
{
  this.zoneService.status(id,status).subscribe(res => {
    if (res.isOK) {
      this.snackBar.open(res.message, 'Fechar', {
        duration: 2000,
        panelClass: ['close-snackbar']
      });
      this.fillZoneList();
    }
  });
}
}
