import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { ReferralService } from '../common/services/referral.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manage-options',
  templateUrl: './manage-options.component.html',
  styleUrls: ['./manage-options.component.scss']
})
export class ManageOptionsComponent implements OnInit {
  registerForm:FormGroup;
  submitted;
  constructor(private formBuilder: FormBuilder,
    private referralService: ReferralService,
    private router: Router,
    private snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      referralWorth_Amount: ['', Validators.required],
      referralGain_Amount_PerPerson: ['', Validators.required],
      trip_to_completed_torefer: ['', Validators.required],
      trip_to_completed_toearn_refferalAmount: ['', Validators.required],
  });
  this.getbyId();
  }

  getbyId(){
    this.referralService.getByReferal().subscribe(res => {

     
        this.registerForm = this.formBuilder.group({
          referralWorth_Amount: [res.content.referralWorth_Amount, [Validators.required]],
          referralGain_Amount_PerPerson: [res.content.referralGain_Amount_PerPerson, [Validators.required]],
          trip_to_completed_torefer: [res.content.trip_to_completed_torefer, [Validators.required]],
          trip_to_completed_toearn_refferalAmount: [res.content.trip_to_completed_toearn_refferalAmount, [Validators.required]], 
      });
    })
  }
  onSubmit(){ 
    
    this.submitted = true;
   
    // stop here if form is invalid
     
    var body ={
      referralWorth_Amount: this.registerForm.controls.referralWorth_Amount.value,
      referralGain_Amount_PerPerson:this.registerForm.controls.referralGain_Amount_PerPerson.value,
      trip_to_completed_torefer:this.registerForm.controls.trip_to_completed_torefer.value,
      trip_to_completed_toearn_refferalAmount:this.registerForm.controls.trip_to_completed_toearn_refferalAmount.value
      }
   
    this.referralService.save(body).subscribe(res=>{
    if(res.isOK)
    {
      this.snackBar.open(res.message, 'Fechar', {
        duration: 2000,
        panelClass: ['close-snackbar']
      });
      this.getbyId();
    }
    })
      
      }
      get f() { return this.registerForm.controls; }

      cancel(){        
        this.router.navigate(['manage-options']);
      }
}
