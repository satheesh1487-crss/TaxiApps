import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { NotificationService } from '../common/services/notification.service';

@Component({
  selector: 'app-edit-sms',
  templateUrl: './edit-sms.component.html',
  styleUrls: ['./edit-sms.component.scss']
})
export class EditSmsComponent implements OnInit {
  submitted
  id
  registerForm: FormGroup;
  constructor(private notificationService: NotificationService,
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    this.route
      .queryParams
      .subscribe(params => {
       this.id = Number(params['id']);
      });
      this.registerForm = this.formBuilder.group({
        description: ['', Validators.required],
      });

      this.getbyId();
  } 
  
  getbyId() {
    this.notificationService.getBySmsId(this.id).subscribe(res => {
      if (res.isOK) {                
        this.registerForm = this.formBuilder.group({         
          description: [res.content.description, Validators.required],         
        });      
      }
    })
  }
  get f() { return this.registerForm.controls; }
  onSubmit() {
    this.submitted = true;
   
    var smsModal = {
      description: this.registerForm.controls.description.value,     
      Id: this.id 
    };
      this.notificationService.editSms(smsModal,this.id).subscribe(res => {
      if (res.isOK) {
        this.router.navigate(['manage-sms-options']);
      }
    });
  }
  cancel(){
    this.router.navigate(['manage-sms-options']);
  }
}
