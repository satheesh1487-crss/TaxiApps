import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActiveConfirmComponent } from './active-confirm.component';

describe('ActiveConfirmComponent', () => {
  let component: ActiveConfirmComponent;
  let fixture: ComponentFixture<ActiveConfirmComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActiveConfirmComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActiveConfirmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
