import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
export interface ConfirmationData {
  header: string;
  message: string;
  icon: string;
  primarybtn: string;
  cancelbtn: string;
}
@Component({
  selector: 'app-active-confirm',
  templateUrl: './active-confirm.component.html',
  styleUrls: ['./active-confirm.component.scss']
})
export class ActiveConfirmComponent implements OnInit {

  constructor(private dialogRef: MatDialogRef<ActiveConfirmComponent>,
    @Inject(MAT_DIALOG_DATA) public data: ConfirmationData) { }

  ngOnInit(): void {
  }
  
  accept() {
    this.dialogRef.close({
      isOk: true,
      data: {}
    });
  }

  reject() {
    this.dialogRef.close({
      isOk: false,
      data: {}
    });
  }
}
