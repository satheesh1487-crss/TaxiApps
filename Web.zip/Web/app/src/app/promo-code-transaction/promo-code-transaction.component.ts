import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { PromoService } from '../common/services/promo.service';
@Component({
  selector: 'app-promo-code-transaction',
  templateUrl: './promo-code-transaction.component.html',
  styleUrls: ['./promo-code-transaction.component.scss']
})
export class PromoCodeTransactionComponent implements OnInit {
  displayedColumns: string[] = ['no', 'driverName', 'rating','comment','requestid','userName'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  result: any;
  
  constructor(public promoService:PromoService, public router:Router) { }
  

  ngOnInit(): void {
    this.promoService.listPromoTransaction().subscribe(res=>      
      { 
        console.log(res)
        this.dataSource = new MatTableDataSource(res.content);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      })
  }
  ngAfterViewInit() { 
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  redirectEdit(id)
  {
    console.log('Edit RollId?=Id' +id);
    //this.router.navigate(['edit-role'], { queryParams: { id: id } });
  } 
}


