import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PromoCodeTransactionComponent } from './promo-code-transaction.component';

describe('PromoCodeTransactionComponent', () => {
  let component: PromoCodeTransactionComponent;
  let fixture: ComponentFixture<PromoCodeTransactionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PromoCodeTransactionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PromoCodeTransactionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
