import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CurrencyService } from '../common/services/currency.service';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-add-currency',
  templateUrl: './add-currency.component.html',
  styleUrls: ['./add-currency.component.scss']
})
export class AddCurrencyComponent implements OnInit {
  submitted = false;
  standard: any;
  constructor(private formBuilder: FormBuilder,
    private currencyService:CurrencyService,
    private snackBar: MatSnackBar,
    public router:Router) { }
  registerForm:FormGroup;
  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      currencyname: ['', Validators.required],
      currencysymbol: ['', Validators.required],
      StandardName: ['', Validators.required]
    });
    this.currencyService.listStandard().subscribe(res=>      
      { 
        this.standard = res.content; 
      })
  }
  Standval='';
  dropChange(evt,role){
    switch(role){
      case "Stand":
        this.Standval=evt.srcElement.value;
        break;
      }
  }
  get f() { return this.registerForm.controls; }
  onSubmit() {    
    this.submitted = true;
 
    if (!this.registerForm.valid) {
        return;
    }
    var currencyModal = {
      currencyName: this.registerForm.controls.currencyname.value,
      currencySymbol: this.registerForm.controls.currencysymbol.value,
      standardId: this.registerForm.controls.StandardName.value
    };
    this.currencyService.save(currencyModal).subscribe(res => {
      if (res.isOK) {
        this.router.navigate(['manage-currency']);
      }
      else
      {
        this.snackBar.open(res.message, 'Fechar', {
          duration: 2000,
          panelClass: ['close-snackbar']
        });
      }
    });
  } 
  cancel(){
    this.router.navigate(['manage-currency']);
  } 
}
