import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageWalletPaymentComponent } from './manage-wallet-payment.component';

describe('ManageWalletPaymentComponent', () => {
  let component: ManageWalletPaymentComponent;
  let fixture: ComponentFixture<ManageWalletPaymentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageWalletPaymentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageWalletPaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
