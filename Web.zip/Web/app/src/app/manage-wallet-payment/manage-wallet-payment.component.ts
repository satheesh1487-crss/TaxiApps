import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { DriverService } from '../common/services/driver.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { ExcelService } from '../common/services/export.service';

@Component({
  selector: 'app-manage-wallet-payment',
  templateUrl: './manage-wallet-payment.component.html',
  styleUrls: ['./manage-wallet-payment.component.scss']
})
export class ManageWalletPaymentComponent implements OnInit {
  displayedColumns: string[] = ['no', 'registrationCode', 'driverName', 'email', 'phoneNumber', 'rating', 'isActive','action'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  result: any;
  driverWallet=[];
  constructor(public driverService:DriverService, public router:Router,
    public exportService:ExcelService,
    private dialog: MatDialog,
    private snackBar: MatSnackBar) {}
  

  ngOnInit(): void {
    this.driverService.listWalletPayment().subscribe(res=>      
      { 
        this.driverWallet =res.content
        this.dataSource = new MatTableDataSource(res.content);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      })
  }
  ngAfterViewInit() { 
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  redirectEdit(id)
  {
    console.log('Edit RollId?=Id' +id);
    //this.router.navigate(['edit-role'], { queryParams: { id: id } });
  } 
  redirectToWallet(id){
    this.router.navigate(['driver-wallet'], { queryParams: { id: id } });
  }
  redirectToAdd(id){
    this.router.navigate(['add-money-wallet'], { queryParams: { id: id } });
  }
  openDialog() {
    const dialogRef = this.dialog.open(ConfirmDialogComponent,{
      data:{
        message: 'Are you sure want to delete?',
        buttonText: {
          ok: 'Save',
          cancel: 'No'
        }
      }
    });
    
    dialogRef.afterClosed().subscribe((confirmed ) => {
      if (confirmed.isOk) {       
        this.snackBar.open('Closing snack bar in a few seconds', 'Fechar', {
          duration: 2000,
          panelClass: ['delete-snackbar']
        });
      }
    });
  }
  exportexcel():void {
    this.exportService.exportAsExcelFile(this.driverWallet, 'DriverWallet');
 }
}
