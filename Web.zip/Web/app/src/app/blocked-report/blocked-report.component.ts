import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router'; 
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog'; 
import { UserService } from 'src/app/common/services/user.service';
import { ConfirmDialogComponent } from 'src/app/confirm-dialog/confirm-dialog.component';
import { ExcelService } from '../common/services/export.service';
@Component({
  selector: 'app-blocked-report',
  templateUrl: './blocked-report.component.html',
  styleUrls: ['./blocked-report.component.scss']
})
export class BlockedReportComponent implements OnInit {
  displayedColumns: string[] = ['no', 'name', 'email', 'phonenumber','blockedstatus', 'status'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  result: any;
  blockedUserReport=[];
  constructor(public userService:UserService, 
    public exportService:ExcelService,
    public router:Router,private dialog: MatDialog,
    private snackBar: MatSnackBar) {}
  

  ngOnInit(): void {
   this.fillBlockedUser();
  }
  fillBlockedUser(){
    this.userService.listBlockUser().subscribe(res=>      
      { 
        this.blockedUserReport =res.content
        this.dataSource = new MatTableDataSource(res.content);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      })
  }
  ngAfterViewInit() { 
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  redirectEdit(id)
  {
    
    //this.router.navigate(['edit-role'], { queryParams: { id: id } });
  } 
  openDialog(id,status) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent,{
      data:{
        message: 'Are you sure want to active?',
        buttonText: {
          primarybtn: 'Confirm',
          cancelbtn: 'Cancel'
        }
      }
    });
   
    dialogRef.afterClosed().subscribe((confirmed) => {
      if (confirmed.isOk) {
        if (confirmed) {
          this.userService.statusUser(id,status).subscribe(res=>{
            if(res.isOK)
            { 
        this.status(id,status);
        
      }
    })
      }
      }
      
    });
  } 
  status(id,status){
    this.userService.statusUser(id,status).subscribe(res=>{
      if(res.isOK)
      {
        this.fillBlockedUser();
        this.snackBar.open(res.message, 'Fechar', {
          duration: 2000,
          panelClass: ['close-snackbar']
        });
      }
    });
  }
  exportexcel():void {
    this.exportService.exportAsExcelFile(this.blockedUserReport, 'BlockedUserReport');
 }
}

