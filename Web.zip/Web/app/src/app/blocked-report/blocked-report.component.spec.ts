import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlockedReportComponent } from './blocked-report.component';

describe('BlockedReportComponent', () => {
  let component: BlockedReportComponent;
  let fixture: ComponentFixture<BlockedReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BlockedReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlockedReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
