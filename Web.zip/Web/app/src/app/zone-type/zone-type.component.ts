import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-zone-type',
  templateUrl: './zone-type.component.html',
  styleUrls: ['./zone-type.component.scss']
})
export class ZoneTypeComponent implements OnInit {
  authService: any;
  router: any;
  isSubmitted=false;
  constructor(private formBuilder: FormBuilder) { }
  registerForm:FormGroup;
  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      Typename:['',Validators.required],
      PaymentType:['',Validators.required],
      Billtype:['',Validators.required]
    });
    
  }

  ErrorMessage

  TypeVal ='';
  PaymentVal ='';
  BillVal ='';

dropChange(evt,role){

  switch(role){
    case "Type":
      this.TypeVal=evt.srcElement.value;
      break;
      case "Payment":
        this.PaymentVal=evt.srcElement.value;
      break;
      case "Bill":
        this.BillVal=evt.srcElement.value;
      break;
    }
}

  onSubmit(){ 
    this.isSubmitted = true;

    // stop here if form is invalid
    if (this.registerForm.invalid) {
        return;
    }
  }

  get f() {
    
    return this.registerForm.controls;
  }
  // City Names
  City: any = ['Florida', 'South Dakota', 'Tennessee', 'Michigan']
}
