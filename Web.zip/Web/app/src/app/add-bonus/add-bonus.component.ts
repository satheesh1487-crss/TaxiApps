import { Component, OnInit } from '@angular/core';
import { DriverService } from '../common/services/driver.service';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-add-bonus',
  templateUrl: './add-bonus.component.html',
  styleUrls: ['./add-bonus.component.scss']
})
export class AddBonusComponent implements OnInit {
  driverList;
  submitted
  constructor( private driverService:DriverService,
     private formBuilder: FormBuilder,private snackBar: MatSnackBar,private router: Router ) { }
  registerForm:FormGroup;
  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      driverName: ['', Validators.required],
      amount: ['', Validators.required],
      reason: ['', Validators.required]
    });
    this.driverService.listDriver().subscribe(res=>      
      { 
        this.driverList = res.content; 
      })
  }
  get f() { return this.registerForm.controls; }
  
  onSubmit() {
    this.submitted = true;
  
    var modalUser={
      driverid: this.registerForm.controls.driverName.value,
      amount: this.registerForm.controls.amount.value,
      reason: this.registerForm.controls.reason.value,
    }


    this.driverService.saveBouns(modalUser).subscribe(res => {
      if(res.isOK)
      {
        this.router.navigate(['manage-bonus']);
      }
      else
      {
        this.snackBar.open(res.message, 'Fechar', {
          duration: 2000,
          panelClass: ['close-snackbar']
        });
      }
    });
  }
  
cancel(){
  this.router.navigate(['manage-bonus']);
}
}

