import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ledger-report',
  templateUrl: './ledger-report.component.html',
  styleUrls: ['./ledger-report.component.scss']
})
export class LedgerReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
