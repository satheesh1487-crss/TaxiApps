import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router'; 
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog'; 
import { ServiceLocationService } from 'src/app/common/services/servicelocation.service';
import { ConfirmDialogComponent } from 'src/app/confirm-dialog/confirm-dialog.component';
import { ExcelService } from '../common/services/export.service';

@Component({
  selector: 'app-service-location',
  templateUrl: './service-location.component.html',
  styleUrls: ['./service-location.component.scss']
})
export class ServiceLocationComponent implements OnInit {
  displayedColumns: string[] = ['no', 'name', 'currencycode','currencysymbol','timezone','country','action'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  result: any;
  serviceLocation=[];
  constructor(public serviceLocationService:ServiceLocationService,
     public router:Router,
     public excelService:ExcelService,
     private dialog: MatDialog,
    private snackBar: MatSnackBar) { }
  

  ngOnInit(): void {
    this.fillLocationService();  
  }
  fillLocationService(){
    this.serviceLocationService.list().subscribe(res=>      
      {        
        this.serviceLocation =res.content;  
        this.dataSource = new MatTableDataSource(res.content);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      });
  }
  ngAfterViewInit() { 
  }

  applyFilter(filterValue: string) {    
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  redirectEdit(id)
  {
   
  this.router.navigate(['edit-service-location'], { queryParams: { id: id } });
  } 
  delete(id) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent,{
      data:{
        message: 'Are you sure want to delete?',
        buttonText: {
          primarybtn: 'Confirm',
          cancelbtn: 'Cancel'
        }
      }
    }); 

    dialogRef.afterClosed().subscribe((confirmed) => {
      if (confirmed.isOk) { 
        this.serviceLocationService.delete(id).subscribe(res=>{
          if(res.isOK){
            this.snackBar.open(res.message, 'Action', {
              duration: 2000,
              panelClass: ['delete-snackbar']
            });
          }
          this.fillLocationService();
        });
      }
    });
  }

  exportexcel():void {
    this.excelService.exportAsExcelFile(this.serviceLocation, 'ServiceLocation');
 }

}
