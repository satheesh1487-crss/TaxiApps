import { Component, OnInit } from '@angular/core';
import { DriverService } from '../common/services/driver.service';
import { Router } from '@angular/router';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { PromoService } from '../common/services/promo.service';
import { ZoneService } from '../common/services/zone.service';
import { ServiceLocationService } from '../common/services/servicelocation.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-add-promo-code',
  templateUrl: './add-promo-code.component.html',
  styleUrls: ['./add-promo-code.component.scss']
})
export class AddPromoCodeComponent implements OnInit {
  registerForm:FormGroup;
  submitted;
  vechileType;
  id
  constructor( private promoService:PromoService,
    private zoneService:ZoneService,
    private snackBar: MatSnackBar,
    private formBuilder: FormBuilder,private router: Router) { }

  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      coupenCode: ['', Validators.required],
      estimateAmt: ['', Validators.required],
      value: ['', Validators.required],
      zoneid: ['', Validators.required],
      type: ['', Validators.required],
      uses: ['', Validators.required],
      repeatedlyUse: ['', Validators.required],
      startDate: [new Date(), Validators.required],
      expiryDate: [new Date(), Validators.required]
    });

    this.zoneService.listZone().subscribe(res=>      
      { 
        this.vechileType = res.content; 
      })
  }

  numberOnly(event): boolean {
   
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  
  get f() { return this.registerForm.controls; }
  onSubmit() {
    this.submitted = true;
    if (!this.registerForm.valid) {
      return;
    }
    var modalUser={
      coupenCode: this.registerForm.controls.coupenCode.value,
      estimateAmt: this.registerForm.controls.estimateAmt.value,
      value:Number( this.registerForm.controls.value.value),
      zoneid: this.registerForm.controls.zoneid.value,
      type: this.registerForm.controls.type.value,
      uses: this.registerForm.controls.uses.value,
      repeatedlyUse: this.registerForm.controls.repeatedlyUse.value,
      startDate: this.registerForm.controls.startDate.value,
      expiryDate: this.registerForm.controls.expiryDate.value,
    }


    this.promoService.save(modalUser).subscribe(res => {
      if(res.isOK)
      {
        this.router.navigate(['promo-code-manage-option']);
      }
      else
      {
        this.snackBar.open(res.message, 'Fechar', {
          duration: 2000,
          panelClass: ['close-snackbar']
        });
      }
    });
    
  }
  cancel(){
    this.router.navigate(['promo-code-manage-option']);
  }
}
