import { Component, OnInit } from '@angular/core';
import { DriverService } from '../common/services/driver.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { PromoService } from '../common/services/promo.service';
import { ZoneService } from '../common/services/zone.service';

@Component({
  selector: 'app-edit-promo-code',
  templateUrl: './edit-promo-code.component.html',
  styleUrls: ['./edit-promo-code.component.scss']
})
export class EditPromoCodeComponent implements OnInit {
  registerForm:FormGroup;
  submitted;
  id: number;
  vechileType;
  modalPromo: any;
  constructor( private promoService:PromoService,
    private zoneService:ZoneService,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private router: Router) { }

  ngOnInit(): void {
    this.route
    .queryParams
    .subscribe(params => {
      // Defaults to 0 if no query param provided.
      this.id = Number(params['id']);
    });

    this.registerForm = this.formBuilder.group({
      coupenCode: ['', Validators.required],
      estimateAmount: ['', Validators.required],
      value: ['', Validators.required],
      zoneid: ['', Validators.required],
      type: ['', Validators.required],
      uses: ['', Validators.required],
      repeatedlyUse: ['', Validators.required],
      startDate: [new Date(), Validators.required],
      expiryDate: [new Date(), Validators.required]
    });

    this.zoneService.listType(1).subscribe(res=>      
      { 
        this.vechileType = res.content; 
      })

      this.getbyId();  
  }

  getbyId() {
    this.promoService.getById(this.id).subscribe(res => {
      if (res.isOK) {
        this.modalPromo = res.content;
        this.registerForm = this.formBuilder.group({ 
          coupenCode: [this.modalPromo.coupencode, Validators.required],
          estimateAmount: [this.modalPromo.estimateAmt, Validators.required],
          reason: [this.modalPromo.reason, Validators.required],
          zoneid: [this.modalPromo.zoneid, Validators.required],
          type: [this.modalPromo.type, Validators.required],
          uses: [this.modalPromo.uses, Validators.required],
          repeatedlyUse: [this.modalPromo.repeatedlyuse, Validators.required],
          startDate: [this.modalPromo.startdate, Validators.required],
          expiryDate: [this.modalPromo.expirydate, Validators.required]
          
        });
      }
    })
  }
  get f() { return this.registerForm.controls; }
  onSubmit() {
    this.submitted = true;
    if (this.registerForm.invalid) {
      return;
    }
    var modalPromo={
      coupenCode: this.registerForm.controls.coupenCode.value,
      estimateAmount: this.registerForm.controls.estimateAmount.value,
      reason: this.registerForm.controls.value.value,
      zoneid: this.registerForm.controls.zoneid.value,
      type: this.registerForm.controls.type.value,
      uses: this.registerForm.controls.uses.value,
      repeatedlyUse: this.registerForm.controls.repeatedlyUse.value,
      startDate: this.registerForm.controls.startDate.value,
      expiryDate: this.registerForm.controls.expiryDate.value,
    }


    this.promoService.edit(modalPromo).subscribe(res => {
      if(res.isOK)
      {
        this.router.navigate(['promo-code-manage-option']);
      }
    });
  }
  cancel(){
    this.router.navigate(['promo-code-manage-option']);
  }
}
