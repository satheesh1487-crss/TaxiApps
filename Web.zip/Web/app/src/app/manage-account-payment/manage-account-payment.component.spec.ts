import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageAccountPaymentComponent } from './manage-account-payment.component';

describe('ManageAccountPaymentComponent', () => {
  let component: ManageAccountPaymentComponent;
  let fixture: ComponentFixture<ManageAccountPaymentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageAccountPaymentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageAccountPaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
