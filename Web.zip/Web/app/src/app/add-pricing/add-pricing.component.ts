import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from '../common/auth/auth.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MustMatch } from '../common/utility/common.validator';
import { UtilityService } from '../common/services/utility.service';
import { UserService } from '../common/services/user.service';
import { ZoneService } from '../common/services/zone.service';


@Component({
  selector: 'app-add-pricing',
  templateUrl: './add-pricing.component.html',
  styleUrls: ['./add-pricing.component.scss']
})
export class AddPricingComponent implements OnInit {
  submitted = false;
  
  zoneId: any;
  typeId: any;
  constructor(private router:Router,
    private authService:AuthService,
    private userService:UserService,
    private route: ActivatedRoute,
    private zoneService: ZoneService,
    private utilityService:UtilityService,
    private formBuilder: FormBuilder) { }
    registerForm:FormGroup;
   
  ngOnInit(): void {
    this.route
    .queryParams
    .subscribe(params => {
      // Defaults to 0 if no query param provided.
     this.zoneId = Number(params['zoneId']);
        this.typeId = Number(params['zoneTypeId']);
    });

    this.registerForm = this.formBuilder.group({
      Baseprice: ['', Validators.required],
      priceperdistance: ['', Validators.required],
      freewaitingtime: ['', Validators.required],
      waitingcharges: ['', Validators.required],
      cancellationfee: ['', Validators.required],
      dropfee: ['', Validators.required],
      admincommtype: ['', Validators.required],
      admincommission: ['', Validators.required],
      Driversavingper: ['', Validators.required],
      basedistance: ['', Validators.required],
      pricepertime: ['', Validators.required],
      customseldrifee: ['', Validators.required],
      Basepricel: ['', Validators.required],
      priceperdistancel: ['', Validators.required],
      freewaitingtimel: ['', Validators.required],
      waitingchargesl: ['', Validators.required],
      cancellationfeel: ['', Validators.required],
      dropfeel: ['', Validators.required],
      admincommtypel: ['', Validators.required],
      admincommissionl: ['', Validators.required],
      Driversavingperl: ['', Validators.required],
      basedistancel: ['', Validators.required],
      pricepertimel: ['', Validators.required],
      customseldrifeel: ['', Validators.required],
   });
   this.getbyId();   
}
ErrorMessage
getbyId(){
  this.zoneService.getBySetPrice(this.zoneId,this.typeId).subscribe(res => {
    if(res.isOK)
    {
      if(res.content.length > 0){
    this.registerForm = this.formBuilder.group({
      Baseprice: [res.content[0].baseprice, Validators.required],
      priceperdistance: [res.content[0].priceperdistance, Validators.required],
      freewaitingtime: [res.content[0].freewaitingtime, Validators.required],
      waitingcharges: [res.content[0].waitingcharges, Validators.required],
      cancellationfee: [res.content[0].cancellationfee, Validators.required],
      dropfee: [res.content[0].dropfee, Validators.required],
      admincommtype: [res.content[0].admincommtype, Validators.required],
      admincommission: [res.content[0].admincommission, Validators.required],
      Driversavingper: [res.content[0].driversavingper, Validators.required],
      basedistance: [res.content[0].basedistance, Validators.required],
      pricepertime: [res.content[0].pricepertime, Validators.required],
      customseldrifee: [res.content[1].customerIdfee, Validators.required],
      Basepricel: [res.content[1].baseprice, Validators.required],
      priceperdistancel: [res.content[1].priceperdistance, Validators.required],
      freewaitingtimel: [res.content[1].freewaitingtime, Validators.required],
      waitingchargesl: [res.content[1].waitingcharges, Validators.required],
      cancellationfeel: [res.content[1].cancellationfee, Validators.required],
      dropfeel: [res.content[1].dropfee, Validators.required],
      admincommtypel: [res.content[1].admincommtype, Validators.required],
      admincommissionl: [res.content[1].admincommission, Validators.required],
      Driversavingperl: [res.content[1].driversavingper, Validators.required],
      basedistancel: [res.content[1].basedistance, Validators.required],
      pricepertimel: [res.content[1].pricepertime, Validators.required],
    });
      }
    }
  })
}
  numberOnly(event): boolean {
   
  const charCode = (event.which) ? event.which : event.keyCode;
  if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    return false;
  }
  return true;

}

  get f() { return this.registerForm.controls; }

   onSubmit() {
         this.submitted = true;
    if (!this.registerForm.valid) {
      return;
  }
   var  priceModalNow=[];
    
   priceModalNow.push({     
    basePrice: this.registerForm.controls.Baseprice.value,
    pricePerDistance: this.registerForm.controls.priceperdistance.value,
    freewaitingtime: this.registerForm.controls.freewaitingtime.value,
    waitingCharges: this.registerForm.controls.waitingcharges.value,
    cancellationFee: this.registerForm.controls.cancellationfee.value,
    dropFee: this.registerForm.controls.dropfee.value,
    admincommtype: this.registerForm.controls.admincommtype.value,
    admincommission: this.registerForm.controls.admincommission.value,
    driversavingper: this.registerForm.controls.Driversavingper.value,     
      baseDistance: this.registerForm.controls.basedistance.value,
      pricePerTime: this.registerForm.controls.pricepertime.value    ,
      rideType:"RIDE NOW",
      zoneTypeid:this.typeId  
    });

    priceModalNow.push({     
      basePrice: this.registerForm.controls.Basepricel.value,
    pricePerDistance: this.registerForm.controls.priceperdistancel.value,
    freewaitingtime: this.registerForm.controls.freewaitingtimel.value,
    waitingCharges: this.registerForm.controls.waitingchargesl.value,
    cancellationFee: this.registerForm.controls.cancellationfeel.value,
    dropFee: this.registerForm.controls.dropfeel.value,
    admincommtype: this.registerForm.controls.admincommtypel.value,
    admincommission: this.registerForm.controls.admincommissionl.value,
    driversavingper: this.registerForm.controls.Driversavingperl.value,     
      baseDistance: this.registerForm.controls.basedistancel.value,
      pricePerTime: this.registerForm.controls.pricepertimel.value,      
      customerIdfee:Number(this.registerForm.controls.customseldrifee.value),
      rideType:"RIDE LATER",
      zoneTypeid:this.typeId  
    }); 
  this.zoneService.editSetPrice(priceModalNow).subscribe(res => {
    if (res.isOK) {
      this.router.navigate(['set-price'], { queryParams: { zoneId: this.zoneId } });
      
     
    }
  });

  
}
cancel(){
  this.router.navigate(['set-price'], { queryParams: { zoneId: this.zoneId } });
      
}
}
