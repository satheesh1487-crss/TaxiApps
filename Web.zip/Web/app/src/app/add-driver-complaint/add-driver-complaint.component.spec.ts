import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddDriverComplaintComponent } from './add-driver-complaint.component';

describe('AddDriverComplaintComponent', () => {
  let component: AddDriverComplaintComponent;
  let fixture: ComponentFixture<AddDriverComplaintComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddDriverComplaintComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddDriverComplaintComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
