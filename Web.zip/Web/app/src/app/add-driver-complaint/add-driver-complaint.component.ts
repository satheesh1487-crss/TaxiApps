import { Component, OnInit } from '@angular/core';
import { ZoneService } from '../common/services/zone.service';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { ComplaintService } from '../common/services/complaint.service';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-add-driver-complaint',
  templateUrl: './add-driver-complaint.component.html',
  styleUrls: ['./add-driver-complaint.component.scss']
})
export class AddDriverComplaintComponent implements OnInit {
  zoneList: any;
  registerForm:FormGroup;
  submitted
  constructor(private zoneService:ZoneService,
    private complaintService:ComplaintService,
    private router:Router,
    private snackBar: MatSnackBar,
    private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      zoneId: ['', Validators.required],
      driverComplaintType: ['', Validators.required],
      driverComplaintTitle: ['', Validators.required]
    });
  
    this.fillZone();
  }

  fillZone(){
    this.zoneService.listZone().subscribe(res=>      
      { 
        this.zoneList = res.content; 
      });
  }
  get f() { return this.registerForm.controls; }
  onSubmit(){
    this.submitted = true;
      if (this.registerForm.invalid) {
          return;
      }
    var body={
      zoneId:this.registerForm.controls.zoneId.value,
      driverComplaintType:this.registerForm.controls.driverComplaintType.value,
      driverComplaintTitle:this.registerForm.controls.driverComplaintTitle.value,
    }


    this.complaintService.saveDriver(body).subscribe(res=>{
      if(res.isOK)
      {
        this.router.navigate(['driver-complaint']);
      }
      else
      {
        this.snackBar.open(res.message, 'Fechar', {
          duration: 2000,
          panelClass: ['close-snackbar']
        });
      }
    })

  }
  cancel(){
    this.router.navigate(['driver-complaint']);
  }
 // /api/ComplaintManagement/AddUserComplainttemplate

}
