import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditDriverCancellationComponent } from './edit-driver-cancellation.component';

describe('EditDriverCancellationComponent', () => {
  let component: EditDriverCancellationComponent;
  let fixture: ComponentFixture<EditDriverCancellationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditDriverCancellationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditDriverCancellationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
