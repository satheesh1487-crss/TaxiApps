import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { Router, ActivatedRoute } from '@angular/router';
import { VehicleService } from '../common/services/vehicle.service';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { ZoneService } from '../common/services/zone.service';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
@Component({
  selector: 'app-zone-type-view',
  templateUrl: './zone-type-view.component.html',
  styleUrls: ['./zone-type-view.component.scss']
})
export class ZoneTypeViewComponent implements OnInit {
  displayedColumns: string[] = ['no', 'zonename', 'Status', 'action'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  result: any;
  zoneId: number;

  constructor(public zoneService: ZoneService,     
    private route:ActivatedRoute, 
    private router:Router,
    private dialog: MatDialog,
    private snackBar: MatSnackBar) { }


  ngOnInit(): void {
    this.route
    .queryParams
    .subscribe(params => {
      // Defaults to 0 if no query param provided.
      this.zoneId = Number(params['zoneId']);
    });
    this.fillZone();
  }

  fillZone(){
    this.zoneService.listType(this.zoneId ).subscribe(res => {
      this.dataSource = new MatTableDataSource(res.content);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    })
  }
  ngAfterViewInit() {
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }
  add(){
    this.router.navigate(['add-zone-type'], { queryParams: { zoneId: this.zoneId } });
  }
  redirectEdit(id) {
  
    this.router.navigate(['edit-zone-type'], { queryParams: { typeId: id,zoneId:this.zoneId } });
  }
  status(id,status) {     
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        message: 'Are you sure want to change status?',
        buttonText: {
          primarybtn: 'Confirm',
          cancelbtn: 'Cancel'
        }
      }
    });

    dialogRef.afterClosed().subscribe((confirmed) => {
      if (confirmed.isOk) {
        this.zoneService.statusType(id,status).subscribe(res => {
          if (res.isOK) {
            this.snackBar.open(res.message, 'Fechar', {
              duration: 2000,
              panelClass: ['close-snackbar']
            });
            this.fillZone();
          }
        });
      }
    });
  };
}