import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ZoneTypeViewComponent } from './zone-type-view.component';

describe('ZoneTypeViewComponent', () => {
  let component: ZoneTypeViewComponent;
  let fixture: ComponentFixture<ZoneTypeViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ZoneTypeViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ZoneTypeViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
