import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-put-fine',
  templateUrl: './manage-put-fine.component.html',
  styleUrls: ['./manage-put-fine.component.scss']
})
export class ManagePutFineComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
