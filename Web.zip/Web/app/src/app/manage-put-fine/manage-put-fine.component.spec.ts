import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagePutFineComponent } from './manage-put-fine.component';

describe('ManagePutFineComponent', () => {
  let component: ManagePutFineComponent;
  let fixture: ComponentFixture<ManagePutFineComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagePutFineComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagePutFineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
