import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from '../common/auth/auth.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { VehicleService } from '../common/services/vehicle.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { UploadService } from '../common/services/fileupload.service';

@Component({
  selector: 'app-edit-vehicle-type',
  templateUrl: './edit-vehicle-type.component.html',
  styleUrls: ['./edit-vehicle-type.component.scss']
})
export class EditVehicleTypeComponent implements OnInit {
  filename
  submitted = false;
  id: number;
  modelVehicle: any;
  constructor(private router:Router,
    private snackBar: MatSnackBar,
    private uploadService:UploadService,
    private vehicleService:VehicleService,    
    private route:ActivatedRoute,
    private formBuilder: FormBuilder) { }
    registerForm:FormGroup;
  ngOnInit(): void {
    this.route.queryParams
    .subscribe(params => {
      // Defaults to 0 if no query param provided.
      this.id = Number(params['id']);
    });
    this.registerForm = this.formBuilder.group({
      TypeName: ['', Validators.required],
      fileupload:['']
  });

  this.vehicleService.getById(this.id).subscribe(res=>      
    {       
      if(res.isOK){       
        this.modelVehicle = res.content;
        this.registerForm = this.formBuilder.group({
          TypeName: [this.modelVehicle.name, Validators.required],
          fileupload: [this.modelVehicle.image, Validators.required]          
      });
      this.uploaded =res.imageName;
      }
    });
  }

  ErrorMessage

  isFileUploading=false;
  fileExtention_config="jpg, jpeg ,png";
  fileMatched=false;
  
    handlerFileInput(files: FileList) {       
     
      var file_extension;
      var file_extension_list=this.fileExtention_config.replace(',','').split(" ");
      
      for (let fileIndex = 0; fileIndex < files.length ; fileIndex++) {        
        for( let fileExtensionIndex =0;fileExtensionIndex<file_extension_list.length; fileExtensionIndex++) {
            file_extension =files[fileIndex].name.split('.')[1];
              if(file_extension_list[fileExtensionIndex].replace('.','').replace(',','').toLowerCase()==file_extension.toLowerCase()) {
                  this.fileMatched =true;
                  break;
                }
          }
        }
  
      if(this.fileMatched==false) {     
        this.ErrorMessage ='Please upload given listed files' +file_extension_list;    
          return;
      }
  
      if(files.length ==0)  {
      return;  
      }
      debugger
      this.uploadService.upload(files[0]).subscribe(res=>{
        if(res.isOK)
        {
          this.uploaded =res.content;
        }
       
      }); 
      this.isFileUploading = true;
    }
    

get f() { return this.registerForm.controls; }
uploaded="";
onSubmit() {
  this.submitted = true;

  // stop here if form is invalid
  if (this.registerForm.invalid) {
      return;
  }

  if(this.uploaded==""){
    this.snackBar.open('Please select file', 'Fechar', {
      duration: 2000,
      panelClass: ['delete-snackbar']
    });
    return;
  }

  var vehicleModal = {
    name: this.registerForm.controls.TypeName.value,
    imageName: this.uploaded,
    id:this.id
  };
  this.vehicleService.edit(vehicleModal,this.id).subscribe(res => {
    if (res.isOK) {
      this.router.navigate(['manage-vehicle-type']);
    }
  });
}
cancel(){
  this.router.navigate(['manage-vehicle-type']);
} 
}

