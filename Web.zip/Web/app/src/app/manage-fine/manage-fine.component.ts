import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { DriverService } from '../common/services/driver.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { ExcelService } from '../common/services/export.service';


@Component({
  selector: 'app-manage-fine',
  templateUrl: './manage-fine.component.html',
  styleUrls: ['./manage-fine.component.scss']
})
export class ManageFineComponent implements OnInit {
  displayedColumns: string[] = ['no', 'registrationcode', 'name', 'phonenumber', 'amount', 'reason',  'ispaid','action'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  result: any;
  driverFine=[];
  constructor(public driverService:DriverService, 
    public exportService:ExcelService,
    public router:Router,private dialog: MatDialog,
  private snackBar: MatSnackBar) {}
  

  ngOnInit(): void {
   this.fillFine();
  }
  fillFine(){
    this.driverService.DriverManageFine().subscribe(res=>      
      { 
        this.driverFine =res.content
        this.dataSource = new MatTableDataSource(res.content);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      })
  }
  ngAfterViewInit() { 
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  redirctToEdit(id)
  {
     
    this.router.navigate(['edit-fine'], { queryParams: { id: id } });
  } 
  openDialog(id) {   
    const dialogRef = this.dialog.open(ConfirmDialogComponent,{
      data:{
        message: 'Are you sure want to delete?',
        buttonText: {
          primarybtn: 'Confirm',
          cancelbtn: 'Cancel'
        }
      }
    });
    dialogRef.afterClosed().subscribe((confirmed) => {
      if (confirmed.isOk) {
       this.driverService.deleteDriverFine(id).subscribe(res=>{
         if(res.isOK)
         {
          this.snackBar.open(res.message, 'Fechar', {
            duration: 2000,
            panelClass: ['delete-snackbar']
          });
          this.fillFine();
         }
       })
        
      }
    });
  }
  exportexcel():void {
    this.exportService.exportAsExcelFile(this.driverFine, 'Driver');
 }
}
