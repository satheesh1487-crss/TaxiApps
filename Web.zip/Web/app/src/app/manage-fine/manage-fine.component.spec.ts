import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageFineComponent } from './manage-fine.component';

describe('ManageFineComponent', () => {
  let component: ManageFineComponent;
  let fixture: ComponentFixture<ManageFineComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageFineComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageFineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
