import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-business-report',
  templateUrl: './business-report.component.html',
  styleUrls: ['./business-report.component.scss']
})
export class BusinessReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
