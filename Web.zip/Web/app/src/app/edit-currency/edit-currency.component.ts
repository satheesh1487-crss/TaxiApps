import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CurrencyService } from '../common/services/currency.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-edit-currency',
  templateUrl: './edit-currency.component.html',
  styleUrls: ['./edit-currency.component.scss']
})
export class EditCurrencyComponent implements OnInit {
  submitted = false;
  Standval='';
  id: number;
  modelCurrency: any;
  standard: any;

  constructor(private formBuilder: FormBuilder,
    private currencyService:CurrencyService,
    public router:Router,
    private route:ActivatedRoute) { }
  registerForm:FormGroup;
  ngOnInit(): void {
    this.route.queryParams
    .subscribe(params => {
      // Defaults to 0 if no query param provided.
      this.id = Number(params['id']);
    });
    this.currencyService.listStandard().subscribe(res=>      
      { 
        this.standard = res.content; 
      })
    this.registerForm = this.formBuilder.group({
      currencyname: ['', Validators.required],
      currencysymbol: ['', Validators.required],
      StandardName: ['', Validators.required]
    });
    
    this.currencyService.getById(this.id).subscribe(res=>      
      {       
        if(res.isOK){       
          this.modelCurrency = res.content;
          this.registerForm = this.formBuilder.group({
            currencyname: [this.modelCurrency.currencyName, Validators.required],
            currencysymbol: [this.modelCurrency.currencySymbol, Validators.required],
            StandardName: [this.modelCurrency.standardId, Validators.required]
        });
        }
      }); 
  }


  dropChange(evt,role){

    switch(role){
      case "Stand":
        this.Standval=evt.srcElement.value;
        break;
      }
  }

  get f() { return this.registerForm.controls; }

  onSubmit() {
    this.submitted = true;
  
    // stop here if form is invalid
    if (this.registerForm.invalid) {
        return;
    }
    var currencyModal = {
      currencyName: this.registerForm.controls.currencyname.value,
      currencySymbol: this.registerForm.controls.currencysymbol.value,
      standardId: this.registerForm.controls.StandardName.value,
      currencyID:this.id
    };
    this.currencyService.edit(currencyModal).subscribe(res => {
      if (res.isOK) {
        this.router.navigate(['manage-currency']);
      }
    });
  }
  // City Names
  City: any = ['Florida', 'South Dakota', 'Tennessee', 'Michigan']

  cancel(){
    this.router.navigate(['manage-currency']);
  } 
}
