import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spinner',
  templateUrl: './spinner.component.html',
  styleUrls: ['./spinner.component.scss']
})
export class SpinnerComponent implements OnInit {


  showLoader: boolean =false;
  constructor(
    //private spinnerService: SpinnerService
    ) {
    
    //spinnerService.getMessage().subscribe(t => this.showLoader = t);
  }

  ngOnInit(): void {
  }

}
