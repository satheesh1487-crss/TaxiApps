import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-doc-view',
  templateUrl: './manage-doc-view.component.html',
  styleUrls: ['./manage-doc-view.component.scss']
})
export class ManageDocViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
