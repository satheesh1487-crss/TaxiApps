import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageDocViewComponent } from './manage-doc-view.component';

describe('ManageDocViewComponent', () => {
  let component: ManageDocViewComponent;
  let fixture: ComponentFixture<ManageDocViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageDocViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageDocViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
