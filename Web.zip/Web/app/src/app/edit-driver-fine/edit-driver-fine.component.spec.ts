import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditDriverFineComponent } from './edit-driver-fine.component';

describe('EditDriverFineComponent', () => {
  let component: EditDriverFineComponent;
  let fixture: ComponentFixture<EditDriverFineComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditDriverFineComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditDriverFineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
