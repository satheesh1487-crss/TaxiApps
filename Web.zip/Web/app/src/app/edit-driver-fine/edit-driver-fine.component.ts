import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-edit-driver-fine',
  templateUrl: './edit-driver-fine.component.html',
  styleUrls: ['./edit-driver-fine.component.scss']
})
export class EditDriverFineComponent implements OnInit {
  submitted = false;
  constructor(private formBuilder: FormBuilder) { }
  registerForm:FormGroup;
  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      Driver: ['', Validators.required],
      amount: ['', Validators.required],
      Reason: ['', Validators.required]
    });
  }
  get f() { return this.registerForm.controls; }

  onSubmit() {
    this.submitted = true;
  
    // stop here if form is invalid
    if (this.registerForm.invalid) {
        return;
    }
  }
}
