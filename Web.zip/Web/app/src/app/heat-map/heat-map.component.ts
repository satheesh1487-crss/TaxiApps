import { Component, OnInit } from '@angular/core';
import { ServiceLocationService } from '../common/services/servicelocation.service';

@Component({
  selector: 'app-heat-map',
  templateUrl: './heat-map.component.html',
  styleUrls: ['./heat-map.component.scss']
})
export class HeatMapComponent implements OnInit {
  arealist
  constructor(private serviceLocationService:ServiceLocationService) { }

  ngOnInit(): void {
    this.fillServcieArea();
  }
fillServcieArea(){
  this.serviceLocationService.list().subscribe(res => {
    if (res.isOK) {
      this.arealist = res.content;
    }
  });
}
}
