import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DriverReportsComponent } from './driver-reports.component';

describe('DriverReportsComponent', () => {
  let component: DriverReportsComponent;
  let fixture: ComponentFixture<DriverReportsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DriverReportsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DriverReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
