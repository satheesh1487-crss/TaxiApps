import { Component, OnInit, HostListener, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MustMatch } from '../common/utility/common.validator';
import { AdminService } from '../common/services/admin.service';
import { Router, ActivatedRoute } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-edit-password',
  templateUrl: './edit-password.component.html',
  styleUrls: ['./edit-password.component.scss']
})
export class EditPasswordComponent implements OnInit {
  submitted = false;
  setpassword;
  id;
  editPassModel: any;
  constructor(private formBuilder: FormBuilder,
    private router:Router,
    private snackBar: MatSnackBar,
    private adminService:AdminService,
    private route:ActivatedRoute) { }
  registerForm:FormGroup;
    ngOnInit(): void {
      this.route.queryParams
    .subscribe(params => {
      // Defaults to 0 if no query param provided.
      this.id = Number(params['id']);
    });

    this.registerForm = this.formBuilder.group({
      password: ['', [Validators.required, Validators.minLength(8)]],
        confirmPassword: ['', Validators.required],
    });
    this.getbyId();
 
}
getbyId(){
  this.adminService.getById(this.id).subscribe(res=>      
    {          
        this.registerForm = this.formBuilder.group({
      password: ['', [Validators.required, Validators.minLength(8)]],
      confirmPassword: ['', Validators.required],
    }, {
      validator: MustMatch('password', 'confirmPassword')
  });
  
});
}
   ErrorMessage
   
get f() { return this.registerForm.controls; }

onSubmit() {
  this.submitted = true;
  if (!this.registerForm.valid) {
    return;
  }  
  var editPassModal = {
    password: this.registerForm.controls.password.value,     
    confirmPassword: this.registerForm.controls.confirmPassword.value,
    id:this.id
  };
    this.adminService.editPwd(editPassModal,this.id).subscribe(res => {
    if (res.isOK) {
      this.router.navigate(['manageadmin']);
    }else
    {
      this.snackBar.open(res.message, 'Fechar', {
        duration: 2000,
        panelClass: ['close-snackbar']
      });
    }
  });
 
}
}
