import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { RoleService } from '../common/services/role.service';
import { RequestService } from '../common/services/request.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { ExcelService } from '../common/services/export.service';

@Component({
  selector: 'app-manage-request',
  templateUrl: './manage-request.component.html',
  styleUrls: ['./manage-request.component.scss']
})
export class ManageRequestComponent implements OnInit {
  displayedColumns: string[] = ['no', 'dateTime', 'requestid','username', 'drivername','tripstatus','paymentoption','action'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  requestList=[];
  roles: any=[];
  
  constructor(public requestService:RequestService,
    public roleService:RoleService,
    public exportService:ExcelService,
    public route:Router,
    private dialog: MatDialog,
  private snackBar: MatSnackBar) {}
  

  ngOnInit(): void {
    this.fillRequest();     
  }
  fillRequest(){
    this.requestService.listRequest().subscribe(res=>      
      { 
        this.requestList =res.content;
        this.dataSource = new MatTableDataSource(res.content);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      })    
  }
  ngAfterViewInit() { 
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  redirectEdit(id)
  {debugger
    this.route.navigate(['view-more'], { queryParams: { id: id } });
  } 
 
  exportexcel():void {
    this.exportService.exportAsExcelFile(this.requestList, 'ManageRequest');
 }
}
