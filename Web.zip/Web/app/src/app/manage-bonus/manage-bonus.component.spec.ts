import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageBonusComponent } from './manage-bonus.component';

describe('ManageBonusComponent', () => {
  let component: ManageBonusComponent;
  let fixture: ComponentFixture<ManageBonusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageBonusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageBonusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
