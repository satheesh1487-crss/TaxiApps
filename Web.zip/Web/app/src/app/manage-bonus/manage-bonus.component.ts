import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { DriverService } from '../common/services/driver.service';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ExcelService } from '../common/services/export.service';

@Component({
  selector: 'app-manage-bonus',
  templateUrl: './manage-bonus.component.html',
  styleUrls: ['./manage-bonus.component.scss']
})
export class ManageBonusComponent implements OnInit {
  displayedColumns: string[] = ['no', 'registrationcode', 'name', 'phonenumber', 'amount', 'reason'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  result: any;
  driverBonus=[];
  constructor(public driverService:DriverService,
    public router:Router, 
    public exportService:ExcelService,
    private dialog: MatDialog,
    private snackBar: MatSnackBar) { }
  

  ngOnInit(): void {
   this.fillBonus();
  }
  fillBonus(){
    this.driverService.bounsList().subscribe(res=>      
      { 
        this.driverBonus =res.content
        this.dataSource = new MatTableDataSource(res.content);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      })
  }
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  redirctToEdit(id)
  {
     
    this.router.navigate(['edit-fine'], { queryParams: { id: id } });
  } 
  openDialog(id) {   
    const dialogRef = this.dialog.open(ConfirmDialogComponent,{
      data:{
        message: 'Are you sure want to delete?',
        buttonText: {
          primarybtn: 'Confirm',
          cancelbtn: 'Cancel'
        }
      }
    });
    dialogRef.afterClosed().subscribe((confirmed) => {
      if (confirmed.isOk) {
       this.driverService.deleteDriverFine(id).subscribe(res=>{
         if(res.isOK)
         {
          this.fillBonus();
         }
       })
        this.snackBar.open('Closing snack bar in a few seconds', 'Fechar', {
          duration: 2000,
          panelClass: ['delete-snackbar']
        });
      }
    });
  }
  exportexcel():void {
    this.exportService.exportAsExcelFile(this.driverBonus, 'Driver');
 }
}