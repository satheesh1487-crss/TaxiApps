import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PromoCodeManageOptionComponent } from './promo-code-manage-option.component';

describe('PromoCodeManageOptionComponent', () => {
  let component: PromoCodeManageOptionComponent;
  let fixture: ComponentFixture<PromoCodeManageOptionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PromoCodeManageOptionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PromoCodeManageOptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
