import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { PromoService } from '../common/services/promo.service';
@Component({
  selector: 'app-promo-code-manage-option',
  templateUrl: './promo-code-manage-option.component.html',
  styleUrls: ['./promo-code-manage-option.component.scss']
})
export class PromoCodeManageOptionComponent implements OnInit {
  displayedColumns: string[] = ['no', 'coupencode', 'estimateAmt','value','type','uses','status','startdate','expirydate','operation','action'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  result: any;
  constructor(public snackBar: MatSnackBar,
    private dialog: MatDialog,public promoService:PromoService, public router:Router) { }

  ngOnInit(): void {
    this.fillPromo();
   
  }
  fillPromo(){
    this.promoService.listManageOption().subscribe(res=>      
      { 
        console.log(res)
        this.dataSource = new MatTableDataSource(res.content);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      })
  }
  ngAfterViewInit() { 
  }
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  redirectEdit(id)
  {
    this.router.navigate(['edit-promo-code'], { queryParams: { id: id } });
  } 
  openDialog(id) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent,{
      data:{
        message: 'Are you sure want to delete?',
        buttonText: {
          primarybtn: 'Confirm',
          cancelbtn: 'Cancel'
        }
      }
    });
    
    dialogRef.afterClosed().subscribe((confirmed) => {
      
      if (confirmed.isOk) {
        
        this.promoService.delete(id).subscribe(res=>{
          if(res.isOK){
            this.snackBar.open(res.message,"Fechar", {
              duration: 2000,
              panelClass: ['delete-snackbar']
            });
            this.fillPromo();
          }
        })
        
      }
    });
  }

  updateStatus(id,status) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent,{
      data:{
        message: 'Are you sure want to change the status?',
        buttonText: {
          primarybtn: 'Confirm',
          cancelbtn: 'Cancel'
        }
      }
    });
    
    dialogRef.afterClosed().subscribe((confirmed) => {
      
      if (confirmed.isOk) {
         
        this.promoService.status(id,status).subscribe(res=>{
          if(res.isOK){
            this.snackBar.open(res.content,"Fechar", {
              duration: 2000,
              panelClass: ['close-snackbar']
            });
            this.fillPromo();
          }
        })
        
      }
    });
  }
  
}
