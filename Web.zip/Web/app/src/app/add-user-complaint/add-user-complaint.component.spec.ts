import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddUserComplaintComponent } from './add-user-complaint.component';

describe('AddUserComplaintComponent', () => {
  let component: AddUserComplaintComponent;
  let fixture: ComponentFixture<AddUserComplaintComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddUserComplaintComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddUserComplaintComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
