import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router, ActivatedRoute } from '@angular/router';
import { DriverService } from '../common/services/driver.service';


@Component({
  selector: 'app-edit-reward-point',
  templateUrl: './edit-reward-point.component.html',
  styleUrls: ['./edit-reward-point.component.scss']
})
export class EditRewardPointComponent implements OnInit {
  submitted
  id
  registerForm: FormGroup;
  constructor(private driverService: DriverService,
    private formBuilder: FormBuilder,
    private snackBar: MatSnackBar,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    this.route
      .queryParams
      .subscribe(params => {
       this.id = Number(params['id']);
      });
      this.registerForm = this.formBuilder.group({
        rewardPoint: ['', Validators.required],
      });

      this.getbyId();
  } 
  
  getbyId() {
    this.driverService.getByRewardId(this.id).subscribe(res => {
      if (res.isOK) {                
        this.registerForm = this.formBuilder.group({         
          rewardPoint: [res.content.rewardPoint, Validators.required],         
        });      
      }
    })
  }
  get f() { return this.registerForm.controls; }
  onSubmit() {
    this.submitted = true;
   
    var rewardModal = {
      rewardPoint: this.registerForm.controls.rewardPoint.value,     
      driverid: this.id 
    };
      this.driverService.editReward(rewardModal,this.id).subscribe(res => {
      if (res.isOK) {
        this.router.navigate(['manage-driver']);
      }else
      {
        this.snackBar.open(res.message, 'Fechar', {
          duration: 2000,
          panelClass: ['close-snackbar']
        });
      }
    });
  }
  cancel(){
    this.router.navigate(['manage-driver']);
  }
}
