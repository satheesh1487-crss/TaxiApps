import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditRewardPointComponent } from './edit-reward-point.component';

describe('EditRewardPointComponent', () => {
  let component: EditRewardPointComponent;
  let fixture: ComponentFixture<EditRewardPointComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditRewardPointComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditRewardPointComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
