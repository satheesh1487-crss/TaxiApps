import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddZoneTypeComponent } from './add-zone-type.component';

describe('AddZoneTypeComponent', () => {
  let component: AddZoneTypeComponent;
  let fixture: ComponentFixture<AddZoneTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddZoneTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddZoneTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
