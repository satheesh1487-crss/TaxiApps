import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../common/auth/auth.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ErrorService } from '../common/services/error.services';
import { TranslatePipe } from '../common/utility/translate.pipe';
import { MatSnackBar } from '@angular/material/snack-bar';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  registerForm:FormGroup;
  submitted=false;
  ErrorMsg: any;

  constructor(private authService:AuthService,   
    public errorService:ErrorService,
    private formBuilder: FormBuilder) {
           this.errorService.getErrorMsg().subscribe(res=>  {           
          this.ErrorMsg=res;          
        });
        this.authService.isLoggedIn.subscribe(res=>{
          
        })
     }
  
  ngOnInit(){
    localStorage.setItem('lang', 'jp');
    this.registerForm = this.formBuilder.group({
      username: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]],
      rememberMe: [false, Validators.requiredTrue]
  });

  

  }
  onSubmit(){ 
  this.submitted = true;
 
  // stop here if form is invalid
   
  var body ={
    email: this.registerForm.controls.username.value,
    password:this.registerForm.controls.password.value
    }
 
  this.authService.login(body);;
    
    }

get f() {
    return this.registerForm.controls;
    } 
 
    
  //  this.router.navigate(['manageadmin'])
  }
