import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReviewDriverToUserComponent } from './review-driver-to-user.component';

describe('ReviewDriverToUserComponent', () => {
  let component: ReviewDriverToUserComponent;
  let fixture: ComponentFixture<ReviewDriverToUserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReviewDriverToUserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReviewDriverToUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
