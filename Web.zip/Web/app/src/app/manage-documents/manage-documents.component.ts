import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router'; 
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog'; 
import { DriverService } from '../common/services/driver.service';

@Component({
  selector: 'app-manage-documents',
  templateUrl: './manage-documents.component.html',
  styleUrls: ['./manage-documents.component.scss']
})
export class ManageDocumentsComponent implements OnInit {
  displayedColumns: string[] = ['no', 'documentName', 'status','viewdocument'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  result: any;
  
  constructor(public driverService:DriverService,
     public router:Router,
     private dialog: MatDialog,
    private snackBar: MatSnackBar) { }
  

  ngOnInit(): void {
    this.fillDoc();  
  }
  fillDoc(){
    this.driverService.listDocument().subscribe(res=>      
      {        
        this.dataSource = new MatTableDataSource(res.content);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      });
  }
  ngAfterViewInit() { 
  }

  applyFilter(filterValue: string) {    
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }
/*
  redirectEdit(id)
  {
   
  this.router.navigate(['edit-email'], { queryParams: { id: id } });
  } 
*/
}
