import { Component, OnInit } from '@angular/core';
import { AuthService } from '../common/auth/auth.service';
import { Router } from '@angular/router';
declare var $:any;

@Component({
  selector: 'app-profile-header',
  templateUrl: './profile-header.component.html',
  styleUrls: ['./profile-header.component.scss']
})
export class ProfileHeaderComponent implements OnInit {

  constructor(private authService:AuthService,
    public router: Router,) { }
profileName
  ngOnInit(): void {
this.profileName =localStorage.getItem('username')

$(document).ready(function(){
 $(".toggle-bar").click(function(){
   $(".side-bar ").css("display","block");
 });
 $(".cls-btn").click(function(){
  $(".side-bar ").css("display","none");
 });
});

  }
  logout(){
    localStorage.clear();
    this.authService.loginState =false;
    this.router.navigate(['login']);
   
  }

}
