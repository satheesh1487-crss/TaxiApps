import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-zone-view',
  templateUrl: './zone-view.component.html',
  styleUrls: ['./zone-view.component.scss']
})
export class ZoneViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
