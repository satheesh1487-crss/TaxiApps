import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadDriversComponent } from './upload-drivers.component';

describe('UploadDriversComponent', () => {
  let component: UploadDriversComponent;
  let fixture: ComponentFixture<UploadDriversComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UploadDriversComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadDriversComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
