import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-upload-drivers',
  templateUrl: './upload-drivers.component.html',
  styleUrls: ['./upload-drivers.component.scss']
})
export class UploadDriversComponent implements OnInit {
  submitted = false;
  constructor(private formBuilder: FormBuilder) { }
  registerForm:FormGroup;
  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      fileupload:['']
    });
  }
  ErrorMessage

  isFileUploading=false;
  fileExtention_config="jpg, jpeg ,png";
  fileMatched=false;
  
    handlerFileInput(files: FileList) {       
     
      var file_extension;
      var file_extension_list=this.fileExtention_config.replace(',','').split(" ");
      
      for (let fileIndex = 0; fileIndex < files.length ; fileIndex++) {        
        for( let fileExtensionIndex =0;fileExtensionIndex<file_extension_list.length; fileExtensionIndex++) {
            file_extension =files[fileIndex].name.split('.')[1];
              if(file_extension_list[fileExtensionIndex].replace('.','').replace(',','').toLowerCase()==file_extension.toLowerCase()) {
                  this.fileMatched =true;
                  break;
                }
          }
        }
  
      if(this.fileMatched==false) {     
        this.ErrorMessage ='Please upload given listed files' +file_extension_list;    
          return;
      }
  
      if(files.length ==0)  {
      return;  
      }
      this.isFileUploading = true;
    
    }

    onSubmit() {
      this.submitted = true;
    
      // stop here if form is invalid
      if (this.registerForm.invalid) {
          return;
      }
    }
}
