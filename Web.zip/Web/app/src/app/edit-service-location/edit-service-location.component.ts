import { Component, OnInit } from '@angular/core';

import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { UtilityService } from 'src/app/common/services/utility.service';
import { ServiceLocationService } from 'src/app/common/services/servicelocation.service';
import { CurrencyService } from 'src/app/common/services/currency.service';
import { isGeneratedFile } from '@angular/compiler/src/aot/util';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-edit-service-location',
  templateUrl: './edit-service-location.component.html',
  styleUrls: ['./edit-service-location.component.scss']
})
export class EditServiceLocationComponent implements OnInit {

  countries
  zones;
  submitted
  registerForm: FormGroup;
  id;
  currencyList;
  serviceLocation ;
  currencysymbolList: any;
  constructor(private utilityServcice: UtilityService,
    private serviceLocationService: ServiceLocationService,
    private currencyService: CurrencyService,
    private formBuilder: FormBuilder,
    private snackBar: MatSnackBar,
    private route: ActivatedRoute,
    private router: Router) {
    this.registerForm = this.formBuilder.group({
      serviceName: ['', Validators.required],
      Country: ['', Validators.required],
      CurrencyId: ['', Validators.required],
      Countrysymbol: ['', Validators.required],
      TimeZone: ['', Validators.required],
    });
  }

  ngOnInit(): void {
    this.route
      .queryParams
      .subscribe(params => {
        // Defaults to 0 if no query param provided.
        this.id = Number(params['id']);
      });
    this.fillDrop();
  }
  fillDrop() {
    this.fillCountry();
  }
  fillCountry() {
    this.utilityServcice.listCountry().subscribe(res => {
      this.countries = res.content;
      this.getbyId();
    });
  }
  getbyId() {
    this.serviceLocationService.getById(this.id).subscribe(res => {
      if (res.isOK) {
        this.serviceLocation  = res.content;
        this.fillCurrencyInfo(res.content.countryId); 
        this.registerForm = this.formBuilder.group({         
          Country: [res.content.countryId, Validators.required],         
        });      
      }
    })
  }
  
  fillCurrencyInfo(id) {
    this.utilityServcice.getZoneBycountryId(id).subscribe(res => {
      this.zones = res.content;
    });
    this.currencyService.list().subscribe(res => {
      this.currencysymbolList = this.currencyList = res.content;
      this.registerForm = this.formBuilder.group({
        serviceName: [this.serviceLocation.serviceName, Validators.required],
        Country: [this.serviceLocation.countryId, Validators.required],
        CurrencyId: [this.serviceLocation.currencyId, Validators.required],
        Countrysymbol: [this.serviceLocation.symbolCurrencyId, Validators.required],
        TimeZone: [this.serviceLocation.timezoneId, Validators.required]
      });
    });
  }

  dropChange(evt, role) {
    this.fillCurrencyInfo(evt);
  }
  get f() { return this.registerForm.controls; }
  onSubmit() {
    this.submitted = true;
    if (!this.registerForm.valid) {
      return;
    }
    var serviceModal = {
      serviceName: this.registerForm.controls.serviceName.value,
      currencyId: this.registerForm.controls.CurrencyId.value,
      countryId: this.registerForm.controls.Country.value,
      timezoneId: this.registerForm.controls.TimeZone.value,
      serviceId: this.id
    };
    this.serviceLocationService.edit(serviceModal).subscribe(res => {
      if (res.isOK) {
        this.router.navigate(['service-location']);
      }
      else
      {
        this.snackBar.open(res.message, 'Fechar', {
          duration: 2000,
          panelClass: ['close-snackbar']
        });
      }
    });
  }
  cancel(){
    this.router.navigate(['service-location']);
  }
}
