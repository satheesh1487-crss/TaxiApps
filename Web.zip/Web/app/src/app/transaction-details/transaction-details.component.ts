import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { RoleService } from '../common/services/role.service';
import { TransactionService } from '../common/services/transaction.service';

@Component({
  selector: 'app-transaction-details',
  templateUrl: './transaction-details.component.html',
  styleUrls: ['./transaction-details.component.scss']
})
export class TransactionDetailsComponent implements OnInit {
  displayedColumns: string[] = ['no', 'requestID', 'username', 'driverName','promodiscount','referalAmount','adminAmount','driverAmount','servicetaxinpercentage','total','payment','ispaid'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  roles: any=[];
  
  constructor(public transactionService:TransactionService,public roleService:RoleService,public route:Router) { }
  

  ngOnInit(): void {
     this.transactionService.listTransaction().subscribe(res=>      
       { 
         console.log(res)
         this.dataSource = new MatTableDataSource(res.content);
         this.dataSource.paginator = this.paginator;
         this.dataSource.sort = this.sort;
       })

       this.roleService.listRole().subscribe(res=>      
         { 
          
           this.roles = res.content; 
         })
  }
  ngAfterViewInit() { 
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

   redirectEdit(id)
   {
     this.route.navigate(['/edit-user'], { queryParams: { id: id } });
   } 
}
