import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router'; 
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';  
import { UserService } from 'src/app/common/services/user.service';
import { ConfirmDialogComponent } from 'src/app/confirm-dialog/confirm-dialog.component';
import { ExcelService } from 'src/app/common/services/export.service';

@Component({
  selector: 'app-manage-user',
  templateUrl: './manage-user.component.html',
  styleUrls: ['./manage-user.component.scss']
})
export class ManageUserComponent implements OnInit {
  displayedColumns: string[] = ['no', 'name', 'email', 'phonenumber', 'status','action'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  result: any;
  userList=[];
  constructor(public userService:UserService, public router:Router,
    private dialog: MatDialog,
    public exportService:ExcelService,
    private snackBar: MatSnackBar) {}
  

  ngOnInit(): void {
    
this.fillUser();
      
  }


  fillUser(){
    this.userService.listUser().subscribe(res=>      
      { 
        this.userList =res.content
        this.dataSource = new MatTableDataSource(res.content);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort; 
      
      var outObject = res.content.reduce(function(a, e) {
        // GROUP BY estimated key (estKey), well, may be a just plain key
        // a -- Accumulator result object
        // e -- sequentally checked Element, the Element that is tested just at this itaration
      
        // new grouping name may be calculated, but must be based on real value of real field
        let estKey = (e['status']); 
      
        (a[estKey] ? a[estKey] : (a[estKey] = null || [])).push(e);
        return a;
      }, {});
      
     this.IsActive =outObject.true==undefined ? 0 : outObject.true.length;
     this.InActive =outObject.false ==undefined ? 0 :outObject.false.length;
      })
  }
  IsActive
  InActive
  ngAfterViewInit() { 
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  redirectEdit(id)
  {
    this.router.navigate(['edit-user'], { queryParams: { id: id } });
  } 
  openDialog(id,status,isDelete) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent,{
      data:{
        message: isDelete==true?'Are you sure want to delete?':'Are you sure want to change status?',
        buttonText: {
          primarybtn: 'Confirm',
          cancelbtn: 'Cancel'
        }
      }
    });
   
    dialogRef.afterClosed().subscribe((confirmed) => {
      if (confirmed.isOk) {
        if(isDelete)
        this.delete(id);
        else
        this.status(id,status);
        
      }
    });
  }
  delete(id){
    this.userService.deleteUser(id).subscribe(res=>{
      if(res.isOK)
      {
        this.fillUser();
        this.snackBar.open(res.message, 'Action', {
          duration: 2000,
          panelClass: ['delete-snackbar']
        });
      }
    });
  }
  status(id,status){
    this.userService.statusUser(id,status).subscribe(res=>{
      if(res.isOK)
      {
        this.fillUser();
        this.snackBar.open(res.message, 'Action', {
          duration: 2000,
          panelClass: ['close-snackbar']
        });
      }
    });
  }
  download(){
    this.userService.downloaduser().subscribe(res=>{


    });
  }
  exportexcel():void {
    this.exportService.exportAsExcelFile(this.userList, 'User');
 }
}

