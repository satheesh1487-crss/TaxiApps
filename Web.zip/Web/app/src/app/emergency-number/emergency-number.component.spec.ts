import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmergencyNumberComponent } from './emergency-number.component';

describe('EmergencyNumberComponent', () => {
  let component: EmergencyNumberComponent;
  let fixture: ComponentFixture<EmergencyNumberComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmergencyNumberComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmergencyNumberComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
