import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ManageAdminComponent } from './admin-management/manage-admin/manage-admin.component';
import { ManageAdminEditComponent } from './admin-management/manage-admin-edit/manage-admin-edit.component';
import { ManageRoleComponent } from './admin-management/manage-role/manage-role.component';
import { EditRoleComponent } from './admin-management/edit-role/edit-role.component';
import { SetPrivillageComponent } from './set-privillage/set-privillage.component';
import { ManageZoneComponent } from './manage-zone/manage-zone.component';
import { AddZoneComponent } from './add-zone/add-zone.component';
import { ZoneViewComponent } from './zone-view/zone-view.component';
import { EditZoneComponent } from './edit-zone/edit-zone.component';
import { AddAdminComponent } from './admin-management/add-admin/add-admin.component';
import { AddAdminTypeComponent } from './admin-management/add-admin-type/add-admin-type.component';
import { ManageOperationComponent } from './manage-operation/manage-operation.component';
import { ZoneTypeComponent } from './zone-type/zone-type.component';
import { ZoneSettingsComponent } from './zone-settings/zone-settings.component';
import { ManageTypeComponent } from './manage-type/manage-type.component';
import { VehicleTypeComponent } from './vehicle-type/vehicle-type.component';
import { EditVehicleTypeComponent } from './edit-vehicle-type/edit-vehicle-type.component';
import { ManagePricingComponent } from './manage-pricing/manage-pricing.component';
import { SetPriceComponent } from './set-price/set-price.component';
import { AddPricingComponent } from './add-pricing/add-pricing.component';
import { SurgePricingComponent } from './surge-pricing/surge-pricing.component';
import { ManageUserComponent } from './user-management/manage-user/manage-user.component';
import { BlockedUserComponent } from './user-management/blocked-user/blocked-user.component';
import { ManageDriverComponent } from './manage-driver/manage-driver.component';
import { AddDriverComponent } from './add-driver/add-driver.component';
import { UploadDriversComponent } from './upload-drivers/upload-drivers.component';
import { EditDriverComponent } from './edit-driver/edit-driver.component';
import { ManageDocumentsComponent } from './manage-documents/manage-documents.component';
import { ManageWalletPaymentComponent } from './manage-wallet-payment/manage-wallet-payment.component';
import { DriverWalletComponent } from './driver-wallet/driver-wallet.component';
import { AddMoneyWalletComponent } from './add-money-wallet/add-money-wallet.component';
import { ManageAccountPaymentComponent } from './manage-account-payment/manage-account-payment.component';
import { ManageAccountTransferComponent } from './manage-account-transfer/manage-account-transfer.component';
import { ManageEarningPaymentComponent } from './manage-earning-payment/manage-earning-payment.component';
import { DriverEarningsComponent } from './driver-earnings/driver-earnings.component';
import { ManageFineComponent } from './manage-fine/manage-fine.component';
import { ManagePutFineComponent } from './manage-put-fine/manage-put-fine.component';
import { AddPutFineComponent } from './add-put-fine/add-put-fine.component';
import { EditDriverFineComponent } from './edit-driver-fine/edit-driver-fine.component';
import { ManageBonusComponent } from './manage-bonus/manage-bonus.component';
import { AddBonusComponent } from './add-bonus/add-bonus.component';
import { ManageBlockedDriverComponent } from './manage-blocked-driver/manage-blocked-driver.component';
import { ManageBlockedDocumentsComponent } from './manage-blocked-documents/manage-blocked-documents.component';
import { ManageCurrencyComponent } from './manage-currency/manage-currency.component';
import { AddCurrencyComponent } from './add-currency/add-currency.component';
import { EditCurrencyComponent } from './edit-currency/edit-currency.component';
import { ManageRequestComponent } from './manage-request/manage-request.component';
import { ViewMoreComponent } from './view-more/view-more.component';
import { ManageScheduleComponent } from './manage-schedule/manage-schedule.component';
import { TransactionDetailsComponent } from './transaction-details/transaction-details.component';
import { ManagePushComponent } from './manage-push/manage-push.component';
import { ManageSmsOptionComponent } from './manage-sms-option/manage-sms-option.component';
import { EditSmsComponent } from './edit-sms/edit-sms.component';
import { ManageSmsComponent } from './manage-sms/manage-sms.component';
import { ManageEmailComponent } from './manage-email/manage-email.component';
import { EditEmailComponent } from './edit-email/edit-email.component';
import { ManageOptionsComponent } from './manage-options/manage-options.component';
import { UserReferralComponent } from './user-referral/user-referral.component';
import { DriverReferralComponent } from './driver-referral/driver-referral.component';
import { PromoCodeManageOptionComponent } from './promo-code-manage-option/promo-code-manage-option.component';
import { AddPromoCodeComponent } from './add-promo-code/add-promo-code.component';
import { PromoCodeTransactionComponent } from './promo-code-transaction/promo-code-transaction.component';
import { UserCancellationComponent } from './user-cancellation/user-cancellation.component';
import { AddUserCancellationComponent } from './add-user-cancellation/add-user-cancellation.component';
import { DriverCancellationComponent } from './driver-cancellation/driver-cancellation.component';
import { AddDriverCancellationComponent } from './add-driver-cancellation/add-driver-cancellation.component';
import { ReviewUserToDriverComponent } from './review-user-to-driver/review-user-to-driver.component';
import { ReviewDriverToUserComponent } from './review-driver-to-user/review-driver-to-user.component';
import { UserComplaintComponent } from './user-complaint/user-complaint.component';
import { AddUserComplaintComponent } from './add-user-complaint/add-user-complaint.component';
import { AddDriverComplaintComponent } from './add-driver-complaint/add-driver-complaint.component';
import { DriverComplaintComponent } from './driver-complaint/driver-complaint.component';
import { UserReportsComponent } from './user-reports/user-reports.component';
import { DriverReportsComponent } from './driver-reports/driver-reports.component';
import { BlockedReportComponent } from './blocked-report/blocked-report.component';
import { BlockedDriverReportsComponent } from './blocked-driver-reports/blocked-driver-reports.component';
import { FinanceReportComponent } from './finance-report/finance-report.component';
import { BusinessReportComponent } from './business-report/business-report.component';
import { TravelReportComponent } from './travel-report/travel-report.component';
import { LedgerReportComponent } from './ledger-report/ledger-report.component';
import { RatingReportComponent } from './rating-report/rating-report.component';
import { ManageSettingsComponent } from './manage-settings/manage-settings.component';
import { ManageFaqComponent } from './manage-faq/manage-faq.component';
import { AddFaqComponent } from './add-faq/add-faq.component';
import { MapViewComponent } from './map-view/map-view.component';
import { HeatMapComponent } from './heat-map/heat-map.component';
import { ActiveConfirmComponent } from './active-confirm/active-confirm.component';
import { UserWalletComponent } from './user-wallet/user-wallet.component';
import { ManageDocViewComponent } from './manage-doc-view/manage-doc-view.component';
import { EditRewardPointComponent } from './edit-reward-point/edit-reward-point.component';
import { DriverSavingsComponent } from './driver-savings/driver-savings.component';
import { DriverCancelationDataComponent } from './driver-cancelation-data/driver-cancelation-data.component';
import { EditPasswordComponent } from './edit-password/edit-password.component';
import { ZoneTypeViewComponent } from './zone-type-view/zone-type-view.component';
import { AddZoneTypeComponent } from './add-zone-type/add-zone-type.component';
import { EditZoneTypeComponent } from './edit-zone-type/edit-zone-type.component';
import { ServiceLocationComponent } from './service-location/service-location.component';
import { AddServiceLocationComponent } from './add-service-location/add-service-location.component';
import { ViewMoreScheduleComponent } from './view-more-schedule/view-more-schedule.component';
import { EmergencyNumberComponent } from './emergency-number/emergency-number.component';
import { AddSosComponent } from './add-sos/add-sos.component';
import { EditSosComponent } from './edit-sos/edit-sos.component';
import { TestComponent } from './test/test.component';
import { EditServiceLocationComponent } from './edit-service-location/edit-service-location.component';

import { EditFineComponent } from './edit-fine/edit-fine.component'; 
import { EditUserCancellationComponent } from './edit-user-cancellation/edit-user-cancellation.component';
import { EditDriverCancellationComponent } from './edit-driver-cancellation/edit-driver-cancellation.component';
import { EditFaqComponent } from './edit-faq/edit-faq.component';
import { EditPromoCodeComponent } from './edit-promo-code/edit-promo-code.component';
import { SpinnerComponent } from './spinner/spinner.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { DocumentUploadComponent } from './document-upload/document-upload.component';



export const routes: Routes = [
  {
    path: '',
    component: LoginComponent
  }, 
  {
    path: 'document-upload',
    component: DocumentUploadComponent
  },
    {
    path: 'profile',
    component: EditProfileComponent
  },
  {
    path: 'manage-settings',
    component: ManageSettingsComponent
  },
  {
    path: 'loader',
    component: SpinnerComponent
  },
  {
    path: 'edit-promo-code',
    component: EditPromoCodeComponent
  },
  {
    path: 'edit-faq',
    component: EditFaqComponent
  },
  {
    path: 'edit-user-cancellation',
    component: EditUserCancellationComponent
  },
  {
    path: 'edit-driver-cancellation',
    component: EditDriverCancellationComponent
  },
  {
    path: 'edit-sos',
    component: EditSosComponent
  },
  {
    path: 'manage-sos',
    component: EmergencyNumberComponent
  }, 
  
  {
    path: 'manage-blocked-driver',
    component: ManageBlockedDriverComponent
  }, 

  {
    path: 'add-sos',
    component: AddSosComponent
  }, 
  {
    path: 'view-more-schedule',
    component: ViewMoreScheduleComponent
  },
  {
    path: 'add-service-location',
    component: AddServiceLocationComponent
  }, 
  {
    path: 'service-location',
    component: ServiceLocationComponent
  }, 
  {
    path: 'add-zone-type',
    component: AddZoneTypeComponent
  }, 
  {
    path: 'edit-zone-type',
    component: EditZoneTypeComponent
  }, 
  {
    path: 'zone-type-view',
    component: ZoneTypeViewComponent
  }, 
  {
    path: 'edit-password',
    component: EditPasswordComponent
  }, 
  {
    path: 'driver-cancellation-data',
    component: DriverCancelationDataComponent
  }, 
  {
    path: 'driver-savings',
    component: DriverSavingsComponent
  }, 
  {
    path: 'edit-reward-point',
    component: EditRewardPointComponent
  }, 
  {
    path: 'document-view',
    component: ManageDocViewComponent
  }, 
  {
    path: 'user-wallet',
    component: UserWalletComponent
  }, 
  {
    path: 'active-form',
    component: ActiveConfirmComponent
  }, 
  {
    path: 'map-view',
    component: MapViewComponent
  }, 
  {
    path: 'heat-map',
    component: HeatMapComponent
  }, 
  {
    path: 'add-faq',
    component: AddFaqComponent
  }, 
  {
    path: 'login',
    component: LoginComponent
  }, 
  {
    path: 'manage-faq',
    component: ManageFaqComponent
  }, 
  {
    path: 'manage-setting',
    component: ManageSettingsComponent
  },
  {
    path: 'user-reports',
    component: UserReportsComponent
  },
  {
    path: 'driver-reports',
    component: DriverReportsComponent
  },
  {
    path: 'blocked-user-report',
    component: BlockedReportComponent
  },
  {
    path: 'blocked-driver-report',
    component: BlockedDriverReportsComponent
  },
  {
    path: 'finance-report',
    component: FinanceReportComponent
  },
  {
    path: 'business-report',
    component: BusinessReportComponent
  },
  {
    path: 'travel-report',
    component: TravelReportComponent
  },
  {
    path: 'ledger-report',
    component: LedgerReportComponent
  },
  {
    path: 'rating-report',
    component: RatingReportComponent
  },
  {
    path: 'user-complaint',
    component: UserComplaintComponent
  },
  {
    path: 'add-user-complaint',
    component: AddUserComplaintComponent
  },
  {
    path: 'add-driver-complaint',
    component: AddDriverComplaintComponent
  },
  {
    path: 'driver-complaint',
    component: DriverComplaintComponent
  },
  {
    path: 'review-user-to-driver',
    component: ReviewUserToDriverComponent
  },
  {
    path: 'review-driver-to-user',
    component: ReviewDriverToUserComponent
  },
  {
    path: 'user-cancellation',
    component: UserCancellationComponent
  },
  {
    path: 'add-user-cancellation',
    component: AddUserCancellationComponent
  },
  {
    path: 'driver-cancellation',
    component: DriverCancellationComponent
  },
  {
    path: 'add-driver-cancellation',
    component: AddDriverCancellationComponent
  },
  {
    path: 'promo-code-manage-option',
    component: PromoCodeManageOptionComponent
  },
  {
    path: 'add-promo-code',
    component: AddPromoCodeComponent
  },
  {
    path: 'promo-code-transaction',
    component: PromoCodeTransactionComponent
  },
  {
    path: 'manage-options',
    component: ManageOptionsComponent
  },
  {
    path: 'user-referral',
    component: UserReferralComponent
  },
  {
    path: 'driver-referral',
    component: DriverReferralComponent
  },
  {
    path: 'manage-push',
    component: ManagePushComponent
  },
  {
    path: 'manage-sms-options',
    component: ManageSmsOptionComponent
  },
  {
    path: 'edit-sms',
    component: EditSmsComponent
  },
  {
    path: 'manage-sms',
    component: ManageSmsComponent
  },
  {
    path: 'manage-email',
    component: ManageEmailComponent
  },
  {
    path: 'edit-email',
    component: EditEmailComponent
  },
  {
    path: 'transaction-details',
    component: TransactionDetailsComponent
  },
  {
    path: 'manage-request',
    component: ManageRequestComponent
  },
  {
    path: 'view-more',
    component: ViewMoreComponent
  },
  {
    path: 'manage-schedule',
    component: ManageScheduleComponent
  },
  {
    path: 'manage-currency',
    component: ManageCurrencyComponent
  },
  {
    path: 'add-currency',
    component: AddCurrencyComponent
  },
  {
    path: 'edit-currency',
    component: EditCurrencyComponent
  },
  {
    path: 'manage-blocked-documents',
    component: ManageBlockedDocumentsComponent
  },
  {
    path: 'blocked-drivers',
    component: ManageBlockedDriverComponent
  },
  {
    path: 'add-bonus',
    component: AddBonusComponent
  },
  {
    path: 'manage-bonus',
    component: ManageBonusComponent
  },
  {
    path: 'add-fine',
    component: AddPutFineComponent
  },
  {
    path: 'put-fine',
    component: ManagePutFineComponent
  },
  {
    path: 'manage-fine',
    component: ManageFineComponent
  },
  {
    path: 'edit-fine',
    component: EditFineComponent
  },
  {
    path: 'driver-earnings',
    component: DriverEarningsComponent
  },
  {
    path: 'manage-earning-payment',
    component: ManageEarningPaymentComponent
  },
  {
    path: 'manage-account-transfer',
    component: ManageAccountTransferComponent
  },  
  {
    path: 'manage-account-payment',
    component: ManageAccountPaymentComponent
  },
  {
    path: 'add-money-wallet',
    component: AddMoneyWalletComponent
  },
  {
    path: 'driver-wallet',
    component: DriverWalletComponent
  },
  {
    path: 'manage-wallet-payment',
    component: ManageWalletPaymentComponent
  },
  {
    path: 'manage-documents',
    component: ManageDocumentsComponent
  },
  {
    path: 'edit-driver',
    component: EditDriverComponent
  },
  {
    path: 'upload-drivers',
    component: UploadDriversComponent
  },
  {
    path: 'add-driver',
    component: AddDriverComponent
  },
  {
    path: 'manage-driver',
    component: ManageDriverComponent
  },
  
  {
    path: 'blocked-user',
    component: BlockedUserComponent
  },
  {
    path: 'manage-pricing',
    component: ManagePricingComponent
  },
  {
    path: 'manage-user',
    component: ManageUserComponent
  },
  {
    path: 'set-price',
    component: SetPriceComponent
  },
  {
    path: 'surge-pricing',
    component: SurgePricingComponent
  },
  {
    path: 'add-pricing',
    component: AddPricingComponent
  },
  {
    path: 'manage-vehicle-type',
    component: ManageTypeComponent
  },
  {
    path: 'add-vehicle-type',
    component: VehicleTypeComponent
  },
  {
    path: 'edit-vehicle-type',
    component: EditVehicleTypeComponent
  },
  {
    path: 'edit-service-location',
    component: EditServiceLocationComponent
  },
  {
    path: 'add-type',
    component: ZoneTypeComponent
  },
  {
    path: 'zone-settings',
    component: ZoneSettingsComponent
  },
  {
    path: 'dashboard',
    component: DashboardComponent
  },
  {
    path: 'manage-operation',
    component: ManageOperationComponent
  },
  {
    path: 'manageadmin',
    component: ManageAdminComponent
  },
  {
    path: 'edit-admin',
    component: ManageAdminEditComponent
  },
  {
    path: 'manage-role',
    component: ManageRoleComponent
  },
  {
    path: 'edit-role',
    component: EditRoleComponent
  },
  {
    path: 'test',
    component: TestComponent
  },
  {
    path: 'set-privillage',
    component: SetPrivillageComponent
  },
  {
    path: 'manage-zone',
    component: ManageZoneComponent
  },
  {
    path: 'add-zone',
    component: AddZoneComponent
  },
  {
    path: 'map-view',
    component: ZoneViewComponent
  },
  {
    path: 'edit-zone',
    component: EditZoneComponent
  },
  {
    path: 'add-admin',
    component: AddAdminComponent
  },
  {
    path: 'add-admin-type',
    component: AddAdminTypeComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
