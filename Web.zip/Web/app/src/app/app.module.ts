import { BrowserModule } from '@angular/platform-browser';
import { NgModule , NO_ERRORS_SCHEMA,CUSTOM_ELEMENTS_SCHEMA, APP_INITIALIZER} from '@angular/core';
import { AppInterceptor } from './common/auth/app.interceptor';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MatTableModule} from '@angular/material/table';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { MeunBarComponent } from './meun-bar/meun-bar.component';
import { ProfileHeaderComponent } from './profile-header/profile-header.component';
import { ProfileComponent } from './userinfo/profile/profile.component';
import { ChangepasswordComponent } from './userinfo/changepassword/changepassword.component';
import { AuthService } from './common/auth/auth.service';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ManageAdminComponent } from './admin-management/manage-admin/manage-admin.component';
import { ManageAdminEditComponent } from './admin-management/manage-admin-edit/manage-admin-edit.component';
import { ManageRoleComponent } from './admin-management/manage-role/manage-role.component';
import { EditRoleComponent } from './admin-management/edit-role/edit-role.component';
import { SetPrivillageComponent } from './set-privillage/set-privillage.component';
import { ManageUserComponent } from './user-management/manage-user/manage-user.component';
import { ManageZoneComponent } from './manage-zone/manage-zone.component';
import { AddZoneComponent } from './add-zone/add-zone.component';
import { ZoneViewComponent } from './zone-view/zone-view.component';
import { EditZoneComponent } from './edit-zone/edit-zone.component';
import { AddAdminComponent } from './admin-management/add-admin/add-admin.component';
import { AddAdminTypeComponent } from './admin-management/add-admin-type/add-admin-type.component';
import { ManageOperationComponent } from './manage-operation/manage-operation.component';
import { ZoneTypeComponent } from './zone-type/zone-type.component';
import { ZoneSettingsComponent } from './zone-settings/zone-settings.component';
import { ManageTypeComponent } from './manage-type/manage-type.component';
import { VehicleTypeComponent } from './vehicle-type/vehicle-type.component';
import { EditVehicleTypeComponent } from './edit-vehicle-type/edit-vehicle-type.component';
import { ManagePricingComponent } from './manage-pricing/manage-pricing.component';
import { SetPriceComponent } from './set-price/set-price.component';
import { AddPricingComponent } from './add-pricing/add-pricing.component';
import { SurgePricingComponent } from './surge-pricing/surge-pricing.component';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { BlockedUserComponent } from './user-management/blocked-user/blocked-user.component';
import { ManageDriverComponent } from './manage-driver/manage-driver.component';
import { AddDriverComponent } from './add-driver/add-driver.component';
import { UploadDriversComponent } from './upload-drivers/upload-drivers.component';
import { EditDriverComponent } from './edit-driver/edit-driver.component';
import { ManageDocumentsComponent } from './manage-documents/manage-documents.component';
import { ManageWalletPaymentComponent } from './manage-wallet-payment/manage-wallet-payment.component';
import { DriverWalletComponent } from './driver-wallet/driver-wallet.component';
import { AddMoneyWalletComponent } from './add-money-wallet/add-money-wallet.component';
import { ManageAccountPaymentComponent } from './manage-account-payment/manage-account-payment.component';
import { ManageAccountTransferComponent } from './manage-account-transfer/manage-account-transfer.component';
import { ManageEarningPaymentComponent } from './manage-earning-payment/manage-earning-payment.component';
import { DriverEarningsComponent } from './driver-earnings/driver-earnings.component';
import { ManageFineComponent } from './manage-fine/manage-fine.component';
import { ManagePutFineComponent } from './manage-put-fine/manage-put-fine.component';
import { AddPutFineComponent } from './add-put-fine/add-put-fine.component';
import { EditDriverFineComponent } from './edit-driver-fine/edit-driver-fine.component';
import { ManageBonusComponent } from './manage-bonus/manage-bonus.component'; 
import { AddBonusComponent } from './add-bonus/add-bonus.component';
import { ManageBlockedDriverComponent } from './manage-blocked-driver/manage-blocked-driver.component';
import { ManageBlockedDocumentsComponent } from './manage-blocked-documents/manage-blocked-documents.component';
import { ManageCurrencyComponent } from './manage-currency/manage-currency.component';
import { AddCurrencyComponent } from './add-currency/add-currency.component';
import { EditCurrencyComponent } from './edit-currency/edit-currency.component';
import { ManageRequestComponent } from './manage-request/manage-request.component';
import { ViewMoreComponent } from './view-more/view-more.component';
import { ManageScheduleComponent } from './manage-schedule/manage-schedule.component';
import { TransactionDetailsComponent } from './transaction-details/transaction-details.component';
import { ManagePushComponent } from './manage-push/manage-push.component';
import { ManageSmsOptionComponent } from './manage-sms-option/manage-sms-option.component';
import { EditSmsComponent } from './edit-sms/edit-sms.component';
import { ManageSmsComponent } from './manage-sms/manage-sms.component';
import { ManageEmailComponent } from './manage-email/manage-email.component';
import { EditEmailComponent } from './edit-email/edit-email.component';
import { ManageOptionsComponent } from './manage-options/manage-options.component';
import { UserReferralComponent } from './user-referral/user-referral.component';
import { DriverReferralComponent } from './driver-referral/driver-referral.component';
import { PromoCodeManageOptionComponent } from './promo-code-manage-option/promo-code-manage-option.component';
import { AddPromoCodeComponent } from './add-promo-code/add-promo-code.component';
import { PromoCodeTransactionComponent } from './promo-code-transaction/promo-code-transaction.component';
import { UserCancellationComponent } from './user-cancellation/user-cancellation.component';
import { AddUserCancellationComponent } from './add-user-cancellation/add-user-cancellation.component';
import { DriverCancellationComponent } from './driver-cancellation/driver-cancellation.component';
import { AddDriverCancellationComponent } from './add-driver-cancellation/add-driver-cancellation.component';
import { TestComponent } from './test/test.component';
import { MatSortModule } from '@angular/material/sort';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatMenu, MatMenuModule } from '@angular/material/menu';
import { MatTreeModule } from '@angular/material/tree';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { ConfirmDialogComponent } from './confirm-dialog/confirm-dialog.component';
import { MatDialog,MatDialogModule } from '@angular/material/dialog';
import { MatSnackBarModule } from '@angular/material/snack-bar';

import { CommonModule } from '@angular/common';
import { AddDriverComplaintComponent } from './add-driver-complaint/add-driver-complaint.component';
import { AddUserComplaintComponent } from './add-user-complaint/add-user-complaint.component';
import { BlockedDriverReportsComponent } from './blocked-driver-reports/blocked-driver-reports.component';
import { BlockedReportComponent } from './blocked-report/blocked-report.component';
import { BusinessReportComponent } from './business-report/business-report.component';
import { DriverComplaintComponent } from './driver-complaint/driver-complaint.component';
import { TranslatePipe } from './common/utility/translate.pipe';
import { DriverReportsComponent } from './driver-reports/driver-reports.component';
import { FinanceReportComponent } from './finance-report/finance-report.component';
import { LedgerReportComponent } from './ledger-report/ledger-report.component';
import { ManageSettingsComponent } from './manage-settings/manage-settings.component';
import { RatingReportComponent } from './rating-report/rating-report.component';
import { ReviewDriverToUserComponent } from './review-driver-to-user/review-driver-to-user.component';
import { ReviewUserToDriverComponent } from './review-user-to-driver/review-user-to-driver.component';
import { AppConfigService } from './common/services/app-initializer.service';
import { RoleService } from './common/services/role.service';
import { PromoService } from './common/services/promo.service';
import { UserService } from './common/services/user.service';
import { UploadService } from './common/services/fileupload.service';
import { AdminService } from './common/services/admin.service';
import { ZoneService } from './common/services/zone.service';
import { SettingService } from './common/services/settings.service';
import { CurrencyService } from './common/services/currency.service';
import { VehicleService } from './common/services/vehicle.service';
import { TravelReportComponent } from './travel-report/travel-report.component';
import { UserComplaintComponent } from './user-complaint/user-complaint.component';
import { UserReportsComponent } from './user-reports/user-reports.component';
import { SpinnerService } from './common/services/spinner.service';
import { DriverService } from './common/services/driver.service';
import { ComplaintService } from './common/services/complaint.service';
import { CancelService } from './common/services/cancel.service';
import { ReferralService } from './common/services/referral.service';
import { UtilityService } from './common/services/utility.service';
import { TranslateService } from './common/utility/translate.service';
import { TransactionService } from './common/services/transaction.service';
import { ReviewService } from './common/services/review.service';
import { RequestService } from './common/services/request.service';
import { ManageFaqComponent } from './manage-faq/manage-faq.component';
import { AddFaqComponent } from './add-faq/add-faq.component';
import { MapViewComponent } from './map-view/map-view.component';
import { HeatMapComponent } from './heat-map/heat-map.component';
import { ActiveConfirmComponent } from './active-confirm/active-confirm.component';
import { ExampleComponent } from './example/example.component';
import { UserWalletComponent } from './user-wallet/user-wallet.component';
import { ManageDocViewComponent } from './manage-doc-view/manage-doc-view.component';
import { EditRewardPointComponent } from './edit-reward-point/edit-reward-point.component';
import { DriverSavingsComponent } from './driver-savings/driver-savings.component';
import { DriverCancelationDataComponent } from './driver-cancelation-data/driver-cancelation-data.component';

import {AgmCoreModule} from '@agm/core';
import { EditPasswordComponent } from './edit-password/edit-password.component';
import { ZoneTypeViewComponent } from './zone-type-view/zone-type-view.component';
import { AddZoneTypeComponent } from './add-zone-type/add-zone-type.component';
import { EditZoneTypeComponent } from './edit-zone-type/edit-zone-type.component';
import { ServiceLocationComponent } from './service-location/service-location.component';
import { AddServiceLocationComponent } from './add-service-location/add-service-location.component';
import { ViewMoreScheduleComponent } from './view-more-schedule/view-more-schedule.component';
import { ServiceLocationService } from './common/services/servicelocation.service';
import { EditServiceLocationComponent } from './/edit-service-location/edit-service-location.component';
import { EmergencyNumberComponent } from './emergency-number/emergency-number.component';
import { AddSosComponent } from './add-sos/add-sos.component';
import { EditSosComponent } from './edit-sos/edit-sos.component';
import { NgApexchartsModule } from "ng-apexcharts";
import { PermissionService } from './common/services/permission.service';
import { EditFineComponent } from './edit-fine/edit-fine.component';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime'; 
import { ExcelService } from './common/services/export.service';
import { NotificationService } from './common/services/notification.service';
import { ManageFAQService } from './common/services/manageFAQ.service';
import { DashboardService } from './common/services/dashboard.service';
import { EditUserCancellationComponent } from './edit-user-cancellation/edit-user-cancellation.component';
import { EditDriverCancellationComponent } from './edit-driver-cancellation/edit-driver-cancellation.component';
import { EditFaqComponent } from './edit-faq/edit-faq.component';
import { EditPromoCodeComponent } from './edit-promo-code/edit-promo-code.component';
import { SpinnerComponent } from './spinner/spinner.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { DocumentUploadComponent } from './document-upload/document-upload.component';

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};
const appinitialize = (appconfigservice: AppConfigService) => { 
  return () => { return appconfigservice.loadConfigOnAppInit()}
 }
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    MeunBarComponent,
    ProfileHeaderComponent,
    ProfileComponent,
    ChangepasswordComponent,
    ManageAdminComponent,
    ManageAdminEditComponent,
    ManageRoleComponent,
    EditRoleComponent,
    SetPrivillageComponent,
    ManageUserComponent,
    ManageZoneComponent,
    AddZoneComponent,
    ZoneViewComponent,
    EditZoneComponent,
    AddAdminComponent,
    AddAdminTypeComponent,
    ManageOperationComponent,
    ZoneTypeComponent,
    ZoneSettingsComponent,
    ManageTypeComponent,
    VehicleTypeComponent,
    EditVehicleTypeComponent,
    ManagePricingComponent,
    SetPriceComponent,
    AddPricingComponent,
    SurgePricingComponent,
    BlockedUserComponent,
    ManageDriverComponent,
    AddDriverComponent,
    UploadDriversComponent,
    EditDriverComponent,
    ManageDocumentsComponent,
    ManageWalletPaymentComponent,
    DriverWalletComponent,
    AddMoneyWalletComponent,
    ManageAccountPaymentComponent,
    ManageAccountTransferComponent,
    ManageEarningPaymentComponent,
    DriverEarningsComponent,
    ManageFineComponent,
    ManagePutFineComponent,
    AddPutFineComponent,
    EditDriverFineComponent,
    ManageBonusComponent, 
    AddBonusComponent,
    ManageBlockedDriverComponent,
    ManageBlockedDocumentsComponent,
    ManageCurrencyComponent,
    AddCurrencyComponent,
    EditCurrencyComponent,
    ManageRequestComponent,
    ViewMoreComponent,
    ManageScheduleComponent,
    TransactionDetailsComponent,
    ManagePushComponent,
    ManageSmsOptionComponent,
    EditSmsComponent,
    ManageSmsComponent,
    ManageEmailComponent,
    EditEmailComponent,
    ManageOptionsComponent,
    UserReferralComponent,
    DriverReferralComponent,
    PromoCodeManageOptionComponent,
    AddPromoCodeComponent,
    PromoCodeTransactionComponent,
    UserCancellationComponent,
    AddUserCancellationComponent,
    DriverCancellationComponent,
    AddDriverCancellationComponent,
    TestComponent,
    ConfirmDialogComponent,
    AddDriverComplaintComponent,
    AddUserComplaintComponent,
    BlockedDriverReportsComponent,
    BlockedReportComponent,
    BusinessReportComponent,
    DriverComplaintComponent,
    DriverReportsComponent,
    FinanceReportComponent,
    LedgerReportComponent,
    ManageSettingsComponent,
    RatingReportComponent,
    ReviewDriverToUserComponent,
    ReviewUserToDriverComponent,
    TravelReportComponent,
    UserComplaintComponent,
    UserReportsComponent,
    ManageFaqComponent,
    AddFaqComponent,
    MapViewComponent,
    HeatMapComponent,
    ActiveConfirmComponent,
    ExampleComponent,
    TranslatePipe,
    UserWalletComponent,
    ManageDocViewComponent,
    EditRewardPointComponent,
    DriverSavingsComponent,
    DriverCancelationDataComponent,
    EditPasswordComponent,
    ZoneTypeViewComponent,
    AddZoneTypeComponent,
    EditZoneTypeComponent,
    ServiceLocationComponent,
    AddServiceLocationComponent,
    ViewMoreScheduleComponent,
    EditServiceLocationComponent,
    EmergencyNumberComponent,
    AddSosComponent,
    EditSosComponent,
    EditFineComponent,
    EditUserCancellationComponent,
    EditDriverCancellationComponent,
    EditFaqComponent,
    EditPromoCodeComponent,
    SpinnerComponent,
    EditProfileComponent,
    DocumentUploadComponent,     
    
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,
    NO_ERRORS_SCHEMA
  ],
  imports: [
    BrowserModule,
      AgmCoreModule.forRoot({
      apiKey: 'AIzaSyAwpTPjHhnVfQuq37V-Gc322b42qTKS-Io',
      libraries: ['places', 'drawing', 'geometry']
    }),
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule, 
    MatTableModule,
    MatSortModule,
    MatSnackBarModule,
     MatDialogModule,
    MatPaginatorModule,
    MatTreeModule,
    MatMenuModule,
    BrowserAnimationsModule,
    MatDialogModule,
    NgApexchartsModule,
    CommonModule,
    OwlDateTimeModule, 
    OwlNativeDateTimeModule,
],
  providers: [AuthService,AdminService,RoleService,UserService,CurrencyService,
    VehicleService,DriverService,ZoneService,RequestService,ReferralService,
    TransactionService,CancelService,ComplaintService,ReviewService,PromoService,
    UtilityService,TranslateService,ServiceLocationService,PermissionService,
    ExcelService,NotificationService,ManageFAQService,DashboardService,SettingService, UploadService,SpinnerService,
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    }, { provide: APP_INITIALIZER, useFactory: appinitialize,multi:true,deps:[AppConfigService]},
    {provide: HTTP_INTERCEPTORS, useClass: AppInterceptor, multi: true, }
  ],entryComponents:[ConfirmDialogComponent],
  bootstrap: [AppComponent],exports:[TranslatePipe]
})
export class AppModule { }
