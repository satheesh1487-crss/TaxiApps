import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { VehicleService } from '../common/services/vehicle.service';
import { DriverService } from '../common/services/driver.service';
import { Router, ActivatedRoute } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-edit-fine',
  templateUrl: './edit-fine.component.html',
  styleUrls: ['./edit-fine.component.scss']
})
export class EditFineComponent implements OnInit {
  submitted = false;
  id: number;
  constructor(private formBuilder: FormBuilder, 
    private driverService:DriverService, 
    private activatedRoute:ActivatedRoute, 
    private router:Router,
    private snackBar: MatSnackBar,
    private vehicleService:VehicleService) { }
  registerForm:FormGroup;
  driverList
  ngOnInit(): void {
    this.activatedRoute
    .queryParams
    .subscribe(params => {
      // Defaults to 0 if no query param provided.
      this.id = Number(params['id']);
    });
    this.registerForm = this.formBuilder.group({
      driverName: ['', Validators.required],
      amount: ['', Validators.required],
      Reason: ['', Validators.required]
    });

    this.driverService.listDriver().subscribe(res=>      
      { 
        this.driverList = res.content; 
        this.getbyId();
      })
  }
 
    getbyId(){
      this.driverService.getByFineId(this.id).subscribe(res => {debugger
          this.registerForm = this.formBuilder.group({
          
            driverName: [res.content.driverid, Validators.required],
            amount: [res.content.fineamount, Validators.required],
            Reason: [res.content.fine_reason, [Validators.required, Validators.email]],
          });
  });
}
  get f() { return this.registerForm.controls; }

  onSubmit() {
    this.submitted = true;
  
    var modalUser={
      driverFineId:this.id,
      driverid: this.registerForm.controls.driverName.value,
      fineamount: this.registerForm.controls.amount.value,
      fine_reason: this.registerForm.controls.Reason.value,
    }


    this.driverService.editDriverFine(modalUser,this.id).subscribe(res => {
      if(res.isOK)
      {
        this.router.navigate(['manage-fine']);
      }else
      {
        this.snackBar.open(res.message, 'Fechar', {
          duration: 2000,
          panelClass: ['close-snackbar']
        });
      }
    });
  }
  cancel(){
    this.router.navigate(['manage-fine']);
  }

}

