import { HttpClient} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BaseLayerService } from '../services/base.service';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { AppConfigService } from '../services/app-initializer.service';
import { ErrorService } from '../services/error.services';


@Injectable()


export class AuthService extends BaseLayerService {
  private loggedIn: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  loginState = localStorage.getItem('token') != null;
  logoutTimer = null;
  get isLoggedIn() {
    this.loggedIn.next(localStorage.getItem('token') != null);
    return this.loggedIn.asObservable();
  }

   
  constructor(
    protected router: Router,
    protected http: HttpClient,
    protected errorService:ErrorService,
    protected appConfig: AppConfigService) {
    super('login', http, router, appConfig,errorService);
    this.initLogoutTimer();
  }
  initLogoutTimer() {
    if (this.logoutTimer) {
      clearInterval(this.logoutTimer);
    }
    this.logoutTimer = setInterval(() => {
      this.checkAutoLogout();
    }, 500);
  }
  //Logout user automatically on time out
  //Logout user automatically on time out
  checkAutoLogout()
  {
    if(this.loginState)
    {
      let expiryTime = new Date(localStorage.getItem("expire_date"));

      let dateNow = new Date();

      if(expiryTime < dateNow)
        //this.logout();
        var r=0;
      else
      {
       this.getTimeDiffString(dateNow,expiryTime);
      }
    }
  }

  getTimeDiffString(dateSrc1:Date,dateSrc2:Date)
  {
    var date1 = dateSrc1.getTime();
    var date2 = dateSrc2.getTime();
    var duration = date2 - date1;
    var seconds = (duration/1000);
    var minutes = parseInt((seconds/60).toString(), 10);
    seconds = seconds%60;

    var hours = parseInt((minutes/60).toString(), 10);
    minutes = minutes%60;
    var nonMsSeconds =parseInt(seconds.toString(), 10);
    
    if(hours > 0)
      return hours.toString().padStart(2,'0') + ':' + minutes.toString().padStart(2,'0') + ':' + nonMsSeconds.toString().padStart(2,'0');
    else if(minutes > 0)
    return minutes.toString().padStart(2,'0') + ':' + nonMsSeconds.toString().padStart(2,'0');
    else
      return nonMsSeconds.toString().padStart(2,'0');
  }
 
  login(body) {
   //return this.http.post('https://taxiappzapi.azurewebsites.net/api/Login/LoginUser',body).subscribe((res:any)=> {
   return this.http.post('https://localhost:5001/api/Login/LoginUser',body).subscribe((res:any)=> {
      
      if(res.isOK==true){
         
        localStorage.setItem('token',res.content.token)
        localStorage.setItem('username',res.content.email);
       localStorage.setItem("expire_date",res.content.expiredate)
        localStorage.setItem('permission',res.content.menukey)
        localStorage.setItem('refreshtoken',res.content.refreshtoken);
        this.loggedIn.next(true);
        this.router.navigate(['dashboard']);
      }
      else{
        this.errorService.setErrorMsg(res.message);
      }
    });
    
     
  }
  getAuthToken(){
    return localStorage.getItem('token');
  }
  

}
