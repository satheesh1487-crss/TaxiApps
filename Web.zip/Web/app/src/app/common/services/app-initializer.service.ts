import { Injectable, Injector } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AppConfigService {

  public applicationInfo;
  private versionInfo;
  private sessionTimer;

  constructor(private injector: Injector) { }

   

  loadConfigOnAppInit() {
    const http = this.injector.get(HttpClient);
    

     http.get('./assets/config/app-config.json').toPromise().then(data => {
      this.applicationInfo = data;
      console.log(data)
    });

   


  }

  // get the configuration
  get Config() {
    return this.applicationInfo;
  }

  get baseUrl() {
    return this.applicationInfo.baseUrl;
  }

   

}
