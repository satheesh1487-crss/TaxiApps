
import {BaseLayerService } from '../services/base.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ErrorService } from './error.services';
import { AppConfigService } from './app-initializer.service';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable()
export class CancelService extends BaseLayerService{
   baseUrlVal: any;
    constructor(
        protected router: Router,
        protected http: HttpClient,
        protected errorService:ErrorService,
        protected appConfig: AppConfigService) {
        super('', http, router, appConfig,errorService);
        
      }

      listCancelUser():Observable<any>
      {
         return this.get<any>('api/CancelManagement/ManageUser')
      }

      saveUser(body):Observable<any>
      {
         return this.post<any>('api/CancelManagement/SaveCancelUser',body);
      }
      editUser(body):Observable<any>
      {
         return this.put<any>('api/CancelManagement/EditUser',body);
      }
      getByUserId(id):Observable<any>
      {
         return this.get<any>('api/CancelManagement/GetUserCancelEdit?userCancelId='+id);
      }
      deleteUser(id):Observable<any>
      {
         return this.delete('api/CancelManagement/DeleteUser?userCancelId='+id,id);
      }
      statusUser(usercancelid,status):Observable<any>
      {
         return super.put<any>('api/CancelManagement/StatusUser?userCancelId='+usercancelid+'&status='+status,null);
      }

      listCancelDriver():Observable<any>
      {
         return this.get<any>('api/CancelManagement/ManageDrivers')
      }

      saveDriver(body):Observable<any>
      {
         return this.post<any>('api/CancelManagement/SaveCancelDriver',body);
      }
      editDriver(body):Observable<any>
      {
         return this.put<any>('api/CancelManagement/EditDriver',body);
      }
      getByDriverId(id):Observable<any>
      {
         return this.get<any>('api/CancelManagement/GetDriverCancelEdit?driverCancelId='+id);
      }
      deleteDriver(id):Observable<any>
      {
         return this.delete('api/CancelManagement/DeleteDriver?driverCancelId='+id,id);
      }
      statusDriver(id,status):Observable<any>
      {
         return super.put<any>('api/CancelManagement/StatusDriver?driverCancelId='+id+'&status='+status,null);
      }
      listArea():Observable<any>
      {
         return this.get<any>('api/Vechile/listTypeWithZone')
      }
}
