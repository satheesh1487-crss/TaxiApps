
import {BaseLayerService } from '../services/base.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ErrorService } from './error.services';
import { AppConfigService } from './app-initializer.service';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable()
export class VehicleService extends BaseLayerService{
   baseUrlVal: any;
    constructor(
        protected router: Router,
        protected http: HttpClient,
        protected errorService:ErrorService,
        protected appConfig: AppConfigService) {
        super('', http, router, appConfig,errorService);
       
      }

      listtype():Observable<any>
      {
         return this.get<any>('api/Vechile/listType')
      }

     
      
      listVehiclePrice():Observable<any>
      {
         return this.get<any>('api/Vechile/manageVehiclePrice')
      }

      listEmer():Observable<any>
      {
         return this.get<any>('api/Vechile/listEmer')
      }

      save(body):Observable<any>
      {
         return this.post<any>('api/Vechile/saveType',body);
      }
      edit(body,id):Observable<any>
      {
         return this.put<any>('api/Vechile/editType',body);
      }
      getById(id):Observable<any>
      {
         return this.get<any>('api/Vechile/getTypebyId?id='+id);
      }
      delete(id):Observable<any>
      {
         return super.delete<any>('api/Vechile/deleteType?id='+id,id);
      }
      status(id,status):Observable<any>
      {
         return super.put<any>('api/Vechile/statusType?id='+id+'&isStatus='+status,null);
      }
      saveEmer(body):Observable<any>
      {
         return this.post<any>('api/Vechile/saveEmer',body);
      }
      editEmer(body,id):Observable<any>
      {
         return this.put<any>('api/Vechile/editEmer',body);
      }
      getbyEmerId(id):Observable<any>
      {
         return this.get<any>('api/Vechile/getbyEmerId?id='+id);
      }
      deleteEmer(id):Observable<any>
      {
         return super.delete<any>('api/Vechile/deleteEmer?id='+id,id);
      }
      statusEmer(id,status):Observable<any>
      {
         return super.put<any>('api/Vechile/statusEmer?id='+id+'&isStatus='+status,null);
      }

      saveWallet(body):Observable<any>
      {
         return this.post<any>('api/Driver/AddWallet',body);
      }

      getWallet(id):Observable<any>
      {
         return this.get<any>('api/Driver/driverWalletList?driverid='+id);
      }

      saveSurge(body):Observable<any>
      {
         return this.post<any>('api/Vechile/saveSurgePrice',body);
      }
     
      getBySurge(id):Observable<any>
      {
         return this.get<any>('api/Vechile/GetSurgePrice?id='+id);
      }
     
}
