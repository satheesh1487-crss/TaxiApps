
import {BaseLayerService } from './base.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ErrorService } from './error.services';
import { AppConfigService } from './app-initializer.service';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable()
export class AdminService extends BaseLayerService{
   baseUrlVal: any;
    constructor(
        protected router: Router,
        protected http: HttpClient,
        protected errorService:ErrorService,
        protected appConfig: AppConfigService) {
        super('', http, router, appConfig,errorService);
        
      }

      list():Observable<any>
      {
         return super.get<any>('api/SuperAdmin/list')
      }

      save(body):Observable<any>
      {
         return super.post<any>('api/SuperAdmin/save',body);
      }
      edit(body,id):Observable<any>
      {
         return super.put<any>('api/SuperAdmin/edit',body);
      }
      
      getById(id):Observable<any>
      {
         return super.get<any>('api/SuperAdmin/getbyId?Adminid='+id);
      }
      delete(id):Observable<any>
      {
         return super.delete<any>('api/SuperAdmin/delete?id='+id ,id);
      }
      status(id,status):Observable<any>
      {
         return super.put<any>('api/SuperAdmin/status?id='+id + '&status='+status,id);
      }
      editPwd(body,id):Observable<any>
      {
         return super.put<any>('api/SuperAdmin/editPassword',body);
      }
}
