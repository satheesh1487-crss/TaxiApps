
import {BaseLayerService } from '../services/base.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ErrorService } from './error.services';
import { AppConfigService } from './app-initializer.service';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable()
export class ReferralService extends BaseLayerService{
   baseUrlVal: any;
    constructor(
        protected router: Router,
        protected http: HttpClient,
        protected errorService:ErrorService,
        protected appConfig: AppConfigService) {
        super('', http, router, appConfig,errorService);
       
      }

      listUserRefferal():Observable<any>
      {
         return this.get<any>('api/Referral/UserRefferal')
      }

      save(body):Observable<any>
      {
         return this.post<any>('api/Referral/saveReferral',body);
      }
      edit(body,id):Observable<any>
      {
         return this.put<any>('api/Role/EditRole?id='+id,body);
      }
      getByReferal():Observable<any>
      {
         return this.get<any>('api/Referral/GetReferral');
      }
      delete(id):Observable<any>
      {
         return this.delete('api/Role/GetRole?Roleid='+id);
      }
}
