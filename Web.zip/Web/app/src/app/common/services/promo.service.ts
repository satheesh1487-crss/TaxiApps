
import {BaseLayerService } from '../services/base.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ErrorService } from './error.services';
import { AppConfigService } from './app-initializer.service';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable()
export class PromoService extends BaseLayerService{
   baseUrlVal: any;
    constructor(
        protected router: Router,
        protected http: HttpClient,
        protected errorService:ErrorService,
        protected appConfig: AppConfigService) {
        super('', http, router, appConfig,errorService);
     
      }

      listManageOption():Observable<any>
      {
         return this.get<any>('api/PromoManagement/ManageOption')
      }

      listPromoTransaction():Observable<any>
      {
         return this.get<any>('api/PromoManagement/PromoTransaction')
      }

      listRole():Observable<any>
      {
         return this.get<any>('api/Role/RoleList')
      }

      save(body):Observable<any>
      {
         return this.post<any>('api/PromoManagement/AddPromo',body);
      }
      edit(body):Observable<any>
      {
         return this.put<any>('api/PromoManagement/EditPromo',body);
      }
      status(id,status):Observable<any>
      {
         return this.put<any>('api/PromoManagement/IsActivePromo?promoid='+id +'&activestatus='+status,status);
      }
      getById(id):Observable<any>
      {
         return this.get<any>('api/PromoManagement/GetPromoDetails?promoid='+id);
      }
      delete(id):Observable<any>
      {
         return super.delete<any>('api/PromoManagement/IsDeletePromo?promoid='+id,id);
      }
}
