import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, Subject } from 'rxjs';
import { AuthService } from '../auth/auth.service'; 
import { AppConfigService } from './app-initializer.service';
import { ErrorService } from './error.services';
import { SpinnerService } from './spinner.service';

 
export class BaseLayerService {
  ErrorMessage;

  private isError = new Subject();
  constructor(
    protected apiBase: string,
    protected http: HttpClient, 
    protected router: Router, 
    protected appConfig:AppConfigService,
    protected errorService:ErrorService,
    
    private authService?: AuthService,

  ) { }
  protected get<T>(method: string, params?: HttpParams | { [param: string]: string | string[]; }) {
    const callBack = new Observable<T>(cd => {
     
      this.errorService.showSpinner();
        this.http.get<T>(this.getUrl(this.apiBase, method)).subscribe(
          response => {
            this.responseOk(response);
            cd.next(response);
            this.errorService.hideSpinner();
          },
          error => {           
            this.errorService.hideSpinner();
             this.responseError(error);
          });
          

    });
    return callBack;
  }

  protected post<T>(method: string, body: any, params?: HttpParams | { [param: string]: string | string[]; }) {   
    //var header=new HttpHeaders(headerDict)
    const callBack = new Observable<T>(cd => {
     
      this.errorService.showSpinner();
        this.http.post<T>(this.getUrl(this.apiBase, method),body).subscribe(  
          response => {
            this.responseOk(response);
            cd.next(response);
            this.errorService.hideSpinner();
          },
          error => {
            this.errorService.hideSpinner();
           
            this.responseError(error);
          
           
          });
         

    });
    return callBack;
  }
  protected put<T>(method: string, body: any, params?: HttpParams | { [param: string]: string | string[]; }) {
    //var header = new HttpHeaders(headerDict)
    const callBack = new Observable<T>(cd => {
      this.errorService.showSpinner();
      this.http.put<T>(this.getUrl(this.apiBase, method), body).subscribe(
        response => {
          this.responseOk(response);
          cd.next(response);
          this.errorService.hideSpinner();
        },
        error => {
         
          this.errorService.hideSpinner();
          this.responseError(error);
         
        });
    });
    return callBack;
  }

  protected delete<T>(method: string, body: any,params?: HttpParams | { [param: string]: string | string[]; }) {
     
    const callBack = new Observable<any>(cd => {
       this.errorService.showSpinner();
      this.http.delete<any>(this.getUrl(this.apiBase, method),).subscribe(
        response => {
          this.responseOk(response);
         cd.next(response);
         this.errorService.hideSpinner();
        },
        error => {
           this.errorService.hideSpinner();
          this.responseError(error);
        });
    });
    return callBack;
  }

  // To show the error message, when reponse bad execution result (user handled exception)
  private responseOk(response: any) {
   

  }


  // To Show the error message, when reponse bad execution result (user unhandled exception)
  private responseError(error: any) {
    if (error.status === 401) {     
      if(error.url.indexOf('authenticated')!==-1){        
        throw error;
      }else{
        this.isError.next(error.error.Message);
      }
      //this.router.navigate(['/denied-access']);
    }
    else if(error.status === 403){
      if(error.error.Message== "Access denied"){
        this.isError.next('You are not authorized to login this application. Please contact admininster');
      
      }else{
      this.isError.next(error.error.Message);
      
      }
    }
     else if (error.error != null && error.error.isOk === false && error.error.message !== '') {
      //this.notifierInfo.error(error.error.message);
   
      this.isError.next(error.error.Message);
      console.error(error.error.message);
    } else if (error.statusText === 'Unknown Error') { // show message when cannot connect to server
      // this.notifierInfo.error('Server cannot be reached');
      this.isError.next('Server cannot be reached');
      //this.ErrorMessage ='Server cannot be reached';
    } else if (error.status === 400) {
 
      this.errorService.setErrorMsg(error.error.Message);
   
    }
    else {
      this.isError.next(error);
      //  this.notifierInfo.error(error.error.message);
      //this.ErrorMessage = error.error.message;
      console.error(error);
    }
  }

  public getUrl(apiBase: any, method: any) {
   
    //return 'https://taxiappzapi.azurewebsites.net/'+ method;
    return 'https://localhost:5001/'+ method;
  }


  public getError() {
    return this.isError.asObservable();
  }
 

}
