import { Injectable } from '@angular/core';
import { Subject, Observable, BehaviorSubject } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class SpinnerService {

  public showLoader = new Subject<boolean>(); 

  constructor() { }

  private subject = new Subject<any>();

  showSpinner() {
    
      this.showLoader.next(true);
  }

  hideSpinner() {    
      this.showLoader.next(false);
  }
  
  }
