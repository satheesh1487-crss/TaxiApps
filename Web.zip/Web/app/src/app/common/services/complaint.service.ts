
import {BaseLayerService } from '../services/base.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ErrorService } from './error.services';
import { AppConfigService } from './app-initializer.service';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable()
export class ComplaintService extends BaseLayerService{
   baseUrlVal: any;
    constructor(
        protected router: Router,
        protected http: HttpClient,
        protected errorService:ErrorService,
        protected appConfig: AppConfigService) {
         
         super('' ,http, router, appConfig,errorService);
         
         
        
      }

      listComplaintUser():Observable<any>
      {
         return this.get<any>('api/ComplaintManagement/Manageuser')
      }

      listComplaintDrivers():Observable<any>
      {
         return this.get<any>('api/ComplaintManagement/ManageDriver')
      }

      listUser():Observable<any>
      {
         return this.get<any>('api/Role/RoleList')
      }

      saveUser(body):Observable<any>
      {
         return this.post<any>('api/ComplaintManagement/AddUserComplainttemplate',body);
      }

      saveDriver(body):Observable<any>
      {
         return this.post<any>('api/ComplaintManagement/AddDriverComplainttemplate',body);
      }

      edit(body,id):Observable<any>
      {
         return this.put<any>('api/Role/EditRole?id='+id,body);
      }
      getById(id):Observable<any>
      {
         return this.get<any>('api/Role/GetRole?Roleid='+id);
      }
      delete(id):Observable<any>
      {
         return this.delete('api/Role/GetRole?Roleid='+id);
      }
}
