
import {BaseLayerService } from '../services/base.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ErrorService } from './error.services';
import { AppConfigService } from './app-initializer.service';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable()
export class DriverService extends BaseLayerService{
   baseUrlVal: any;
    constructor(
        protected router: Router,
        protected http: HttpClient,
        protected errorService:ErrorService,
        protected appConfig: AppConfigService) {
        super('', http, router, appConfig,errorService);
       
      }
      
      listDriver():Observable<any>
      {
         return this.get<any>('api/Driver/DriverList')
      }
      listDocument():Observable<any>
      {
         return this.get<any>('api/Driver/listDocument')
      }
      listBlockDriver():Observable<any>
      {
         return this.get<any>('api/Driver/BlockedDriverList')
      }

      listWalletPayment():Observable<any>
      {
         return this.get<any>('api/Driver/WalletPaymentList')
      }

      listAccountPayment():Observable<any>
      {
         return this.get<any>('api/Driver/AccountPaymentList')
      }

      listEarningsPayment():Observable<any>
      {
         return this.get<any>('api/Driver/EarningsPaymentList')
      }
      
      saveDriver(body):Observable<any>
      {
         return super.post<any>('api/Driver/Save',body);
      }
      editDriver(body,id):Observable<any>
      {
         return super.put<any>('api/Driver/Edit',body);
      }
      getById(driverid):Observable<any>
      {
         return super.get<any>('api/Driver/GetDriverEdit?driverid='+driverid);
      }

      getByRewardId(driverid):Observable<any>
      {
         return super.get<any>('api/Driver/GetRewardEdit?driverid='+driverid);
      }
      editReward(body,id):Observable<any>
      {
         return super.put<any>('api/Driver/EditRewardPoint',body);
      }
      deleteDriver(driverid):Observable<any>
      {
         return super.delete<any>('api/Driver/DeleteDriver?driverid='+driverid ,driverid);
      }
      statusDriver(driverid,status):Observable<any>
      {
         return super.put<any>('api/Driver/InActivedriver?driverid='+driverid +'&status='+status ,driverid);
      }

      downloaddriver()
      {
         return super.get<any>('api/Driver/downloadDriver');
      }
      downloadBlock()
      {
         return super.get<any>('api/Driver/downloadBlocked');
      }

      DriverManageFine():Observable<any>
      {
         return this.get<any>('api/Driver/driverFineList')
      }

      DriverListBlocked():Observable<any>
      {
         return this.get<any>('api/Driver/ManageFine')
      }

      DriverWalletList():Observable<any>
      {
         return this.get<any>('api/Driver/WalletList')
      }

      DriverAccountPayment():Observable<any>
      {
         return this.get<any>('api/Driver/AccountPaymentList')
      }

      DriverEarningPayment():Observable<any>
      {
         return this.get<any>('api/Driver/EarningPaymentList')
      }

      DriverManageBonus():Observable<any>
      {
         return this.get<any>('api/Driver/ManageBonus')
     }
     saveFine(body):Observable<any>
     {
        return this.post<any>('api/Driver/addFine',body);
     }
 
     deleteDriverFine(driverid):Observable<any>
     {
        return super.delete<any>('api/Driver/DeleteFine?id='+driverid ,driverid);
     }
     getByFineId(driverid):Observable<any>
     {
        return super.get<any>('api/Driver/GetDriverFineEdit?driverid='+driverid);
     }
     editDriverFine(body,id):Observable<any>
     {
        return super.put<any>('api/Driver/EditFine',body);
     }


     saveBouns(body):Observable<any>
     {
        return this.post<any>('api/Driver/addBonus',body);
     }
 
     deleteBouns(driverid):Observable<any>
     {
        return super.delete<any>('api/Driver/deleteBonus?id='+driverid ,driverid);
     }
     getByBounsId(driverid):Observable<any>
     {
        return super.get<any>('api/Driver/getByBonusId?id='+driverid);
     }
     bounsList():Observable<any>
     {
        return super.get<any>('api/Driver/driverBonusList');
     }
     editBouns(body,id):Observable<any>
     {
        return super.put<any>('api/Driver/editBonus',body);
     }
}
