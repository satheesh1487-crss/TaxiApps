
import {BaseLayerService } from '../services/base.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ErrorService } from './error.services';
import { AppConfigService } from './app-initializer.service';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable()
export class UserService extends BaseLayerService{
   baseUrlVal: any;
    constructor(
        protected router: Router,
        protected http: HttpClient,
        protected errorService:ErrorService,
        protected appConfig: AppConfigService) {
        super('', http, router, appConfig,errorService);
       
      }

      listUser():Observable<any>
      {
         return this.get<any>('api/User/UserList')
      }
      listBlockUser():Observable<any>
      {
         return this.get<any>('api/User/BlockedUserList')
      }
      
      getById(userid):Observable<any>
      {
         return super.get<any>('api/User/GetUserEdit?userid='+userid);
      }
      deleteUser(userid):Observable<any>
      {
         return super.delete<any>('api/User/DeleteUser?userid='+userid ,userid);
      }
      statusUser(userid,status):Observable<any>
      {
         return super.put<any>('api/User/InActiveuser?userid='+userid +'&status='+status ,userid);
      }

      downloaduser()
      {
         return super.get<any>('api/User/downloadUser');
      }
      downloaduBlock()
      {
         return super.get<any>('api/User/downloadBlocked');
      }
}
