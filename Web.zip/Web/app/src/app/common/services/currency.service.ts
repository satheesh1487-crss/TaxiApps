
import {BaseLayerService } from '../services/base.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ErrorService } from './error.services';
import { AppConfigService } from './app-initializer.service';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable()
export class CurrencyService extends BaseLayerService{
   baseUrlVal='';
    constructor(
        protected router: Router,
        protected http: HttpClient,
        protected errorService:ErrorService,
        protected appConfig: AppConfigService) {
           
        super('' ,http, router, appConfig,errorService);
        
        
      }

      list():Observable<any>
      {
         return this.get<any>('api/Currency/listCurrency')
      }

      listStandard():Observable<any>
      {
         return this.get<any>('api/Currency/listStandard')
      }

      save(body):Observable<any>
      {
         return this.post<any>('api/Currency/saveCurrency',body);
      }
      edit(body):Observable<any>
      {
         return this.put<any>('api/Currency/editCurrency',body);
      }
      getById(id):Observable<any>
      {
         return this.get<any>('api/Currency/getCurrencybyId?id='+id);
      }
      delete(id):Observable<any>
      {
         return super.delete<any>('api/Currency/deleteCurrency?id='+id,id);
      }
      status(id,status):Observable<any>
      {
         return super.put<any>('api/Currency/statusType?id='+id+'&isStatus='+status,null);
      }
}
