import { Injectable } from '@angular/core'; 
import { Subject } from 'rxjs';

@Injectable()
export class PermissionService {
    private role: string;
    private permissions: string[];
    private handler = new Subject<any>();
    
    
    constructor() {
        
        const role = localStorage.getItem("role");
        const permissions = localStorage.getItem("permission");
        this.role = ((role && role !== 'undefined') ? role : '');
        this.permissions = permissions.split(',');
    }


    public checkPermission(feature: string): boolean {
        return (this.permissions
            && this.permissions.length > 0
            && this.permissions.indexOf(feature) >= 0);
    }

    broadcast(role: string, permissions: string[]) {
        this.role = role;
        this.permissions = permissions;
        this.handler.next(true);
    }

    public getHandler() { return this.handler; }
}
