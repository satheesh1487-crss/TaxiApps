
import {BaseLayerService } from '../services/base.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ErrorService } from './error.services';
import { AppConfigService } from './app-initializer.service';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable()
export class ServiceLocationService extends BaseLayerService{
   baseUrlVal: any;
    constructor(
        protected router: Router,
        protected http: HttpClient,
        protected errorService:ErrorService,
        protected appConfig: AppConfigService) {
        super('', http, router, appConfig,errorService);        
      }

      list():Observable<any>
      {
         return super.get<any>('api/service/list')
      }
      countryByservicelocId(Id):Observable<any>
      {
         return super.get<any>('api/service/getCountrybyId?id='+Id)
      }
      save(serviceModal):Observable<any>
      {
         return super.post<any>('api/service/save',serviceModal);
      }
      edit(serviceModal):Observable<any>
      {
         return super.put<any>('api/service/edit',serviceModal);
      }
      delete(id):Observable<any>
      {
         return super.delete<any>('api/service/delete?id='+id,id);        
      }

      getById(id):Observable<any>
      {
         return super.get<any>('api/service/getbyId?id='+id);        
      }
      
}
