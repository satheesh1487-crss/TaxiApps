
import {BaseLayerService } from '../services/base.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ErrorService } from './error.services';
import { AppConfigService } from './app-initializer.service';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable()
export class ManageFAQService extends BaseLayerService{
   baseUrlVal: any;
    constructor(
        protected router: Router,
        protected http: HttpClient,
        protected errorService:ErrorService,
        protected appConfig: AppConfigService) {
        super('', http, router, appConfig,errorService);        
      }

      list():Observable<any>
      {
         return super.get<any>('api/FAQ/listFAQ')
      }
      
      edit(body,id):Observable<any>
      {
         return super.put<any>('api/FAQ/editFAQ',body);
      }
      
      getById(id):Observable<any>
      {
         return super.get<any>('api/FAQ/getbyFAQId?id='+id);        
      }

      status(id,status):Observable<any>
      {
         return super.put<any>('api/FAQ/statusFAQ?id='+id+'&isStatus='+status,null);
      }
       
      delete(id):Observable<any>
      {
         return super.delete<any>('api/FAQ/deleteFAQ?id='+id,null);
      }
      
      save(body):Observable<any>
      {
         return super.post<any>('api/FAQ/saveFAQ',body);
      }
      
     
}
