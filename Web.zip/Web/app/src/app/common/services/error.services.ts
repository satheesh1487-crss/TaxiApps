import { Subject } from "rxjs";
import { Injectable } from "@angular/core";

@Injectable({providedIn:'root'})
export class ErrorService {
    public errorMsg = new Subject<any>();
    constructor() {

    }

    setErrorMsg(msg) {
        this.errorMsg.next(msg);
    }
    getErrorMsg() {
       return this.errorMsg.asObservable();
    }
    public showLoader = new Subject<boolean>();
    showSpinner() {
    
        this.showLoader.next(true);
    }
  
    hideSpinner() {    
        this.showLoader.next(false);
    }
    getSpinner(){
      return  this.showLoader.asObservable();
    }
}