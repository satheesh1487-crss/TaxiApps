
import {BaseLayerService } from '../services/base.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ErrorService } from './error.services';
import { AppConfigService } from './app-initializer.service';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable()
export class NotificationService extends BaseLayerService{
   baseUrlVal: any;
    constructor(
        protected router: Router,
        protected http: HttpClient,
        protected errorService:ErrorService,
        protected appConfig: AppConfigService) {
        super('', http, router, appConfig,errorService);        
      }

      listEmail():Observable<any>
      {
         return super.get<any>('api/ManageNotification/listEmail')
      }
      
      editEmail(body,id):Observable<any>
      {
         return super.put<any>('api/ManageNotification/editEmail',body);
      }
      
      getByEmailId(id):Observable<any>
      {
         return super.get<any>('api/ManageNotification/getbyEmailId?id='+id);        
      }

      statusEmail(id,status):Observable<any>
      {
         return super.put<any>('api/ManageNotification/statusEmail?id='+id+'&isStatus='+status,null);
      }
      
      listSms():Observable<any>
      {
         return super.get<any>('api/ManageNotification/listSms')
      }
      
      editSms(body,id):Observable<any>
      {
         return super.put<any>('api/ManageNotification/editSms',body);
      }
      
      getBySmsId(id):Observable<any>
      {
         return super.get<any>('api/ManageNotification/getbySmsId?id='+id);        
      }

      statusSms(id,status):Observable<any>
      {
         return super.put<any>('api/ManageNotification/statusSms?id='+id+'&isStatus='+status,null);
      }
}
