
import {BaseLayerService } from '../services/base.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ErrorService } from './error.services';
import { AppConfigService } from './app-initializer.service';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable()
export class ReviewService extends BaseLayerService{
   baseUrlVal: any;
    constructor(
        protected router: Router,
        protected http: HttpClient,
        protected errorService:ErrorService,
        protected appConfig: AppConfigService) {
        super('', http, router, appConfig,errorService);
      
      }

      listUsertoDriver():Observable<any>
      {
         return this.get<any>('api/ReviewManagement/UsertoDriver')
      }

      listDrivertoUser():Observable<any>
      {
         return this.get<any>('api/ReviewManagement/DrivertoUser')
      }

     
      status(id,activestatus):Observable<any>
      {
         return this.put<any>('api/ReviewManagement/UpdateReview?id='+id+'&activestatus='+activestatus,activestatus);
      }
      
}
