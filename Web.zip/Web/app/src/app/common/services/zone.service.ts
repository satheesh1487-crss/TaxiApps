
import { BaseLayerService } from '../services/base.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ErrorService } from './error.services';
import { AppConfigService } from './app-initializer.service';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable()
export class ZoneService extends BaseLayerService {
   baseUrlVal: any;
   constructor(
      protected router: Router,
      protected http: HttpClient,
      protected errorService: ErrorService,
      protected appConfig: AppConfigService) {
      super('', http, router, appConfig, errorService);

   }

   listZone(): Observable<any> {
      return this.get<any>('api/Zone/ZoneList')
   }
   serviceBasedZone(id): Observable<any> {
      return this.get<any>('api/Zone/serviceBasedZone?zoneId='+id)
   }
   
   listType(id): Observable<any> {
      return this.get<any>('api/Zone/ListZoneType?zoneid='+id)
   }
   save(body): Observable<any> {
      return super.post<any>('api/Zone/AddZone', body);
   }

   saveOperationType(body): Observable<any> {
      return super.post<any>('api/Zone/AddZoneType', body);
   }


   saveType1(body): Observable<any> {
      return super.post<any>('/api/Zone/AddZoneType', body);
   }
   edit(body): Observable<any> {
      return super.put<any>('api/Zone/EditZone', body);
   }

   editOperationType(body): Observable<any> {
      return super.put<any>('/api/Zone/EditZoneType', body);
   }
   getById(id): Observable<any> {
      return super.get<any>('/api/Zone/GetZonedetails?zoneid=' + id);
   }
   getByTypeId(id,typeId): Observable<any> {
      return super.get<any>('/api/Zone/GetZoneTypebyid?zoneid=' + id+ '&typeid=' + typeId);
   }
   delete(id): Observable<any> {
      return super.delete<any>('/api/Zone/DeleteZone?zoneid=' + id, id);
   }
   deleteType(id): Observable<any> {
      return super.delete<any>('/api/Zone/DeleteZone?zoneid=' + id, id); 
      
   }
   status(id, status): Observable<any> {
      return super.put<any>('/api/Zone/ActiveZone?zoneid=' + id + '&isStatus=' + status, id);
   }

   statusType(id, status): Observable<any> {
      return super.put<any>('/api/Zone/ActiveZone?zoneid=' + id + '&isStatus=' + status, id);
   }

   getBySetPrice(id,typeId): Observable<any> {
      return super.get<any>('/api/Zone/GetSetprice?zoneid=' + id + '&typeid=' + typeId);
   }
   
   editSetPrice(body): Observable<any> {
      return super.put<any>('/api/Zone/EditSetprice', body);
   }

   listZoneRelationVechileType(Id):Observable<any>
   {
      return this.get<any>('api/Zone/ZoneRelationVechileType?zoneId='+Id)
   }
}
