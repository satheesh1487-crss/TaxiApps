import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { ZoneService } from '../common/services/zone.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-manage-pricing',
  templateUrl: './manage-pricing.component.html',
  styleUrls: ['./manage-pricing.component.scss']
})
export class ManagePricingComponent implements OnInit {
  displayedColumns: string[] = ['no', 'zonename', 'status', 'action'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  result: any;
  zoneTypeId:number;
  constructor(public zoneService: ZoneService,
    public router: Router, private dialog: MatDialog,
    private snackBar: MatSnackBar) { }


  ngOnInit(): void {
   this.fillZoneList();
  }
  fillZoneList(){
    this.zoneService.listZone().subscribe(res => {
      this.dataSource = new MatTableDataSource(res.content);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    })
  }
  ngAfterViewInit() {
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }
  redirectSet(id){
    this.router.navigate(['set-price'], { queryParams: { zoneId: id } });
  }
  redirectSurge(id) {
    this.router.navigate(['surge-pricing'], { queryParams: { id: id } });
  }
 
}
