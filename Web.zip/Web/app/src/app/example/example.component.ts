import { Component, OnInit } from '@angular/core';
import { NumberFormatPipe } from '../common/utility/number.pipe';


@Component({
  selector: 'app-example',
  templateUrl: './example.component.html',
  styleUrls: ['./example.component.scss']
})
export class ExampleComponent implements OnInit {
  num1: number = 12.6384678;
  num2: number = 0.5;
  num3: number = 123456789;

  userNum: number;
  constructor(private formatPipe: NumberFormatPipe) { }

  ngOnInit(): void {
    
  }
  formatUserNumber() {
    this.userNum = this.formatPipe.transform(this.userNum);
  }
}
