import { Component, OnInit, ViewChild } from '@angular/core';
import ApexCharts from 'apexcharts/dist/apexcharts.common.js';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DashboardService } from '../common/services/dashboard.service';
//import { HubConnection, HubConnectionBuilder } from '@aspnet/signalr';  

@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
    registerForm: FormGroup;
    //private hubConnection: HubConnection; 
dataDashBoard

    constructor(private formBuilder: FormBuilder,
        private dashboardService: DashboardService) { }

    ngOnInit(): void { 

        /*
      
        this.hubConnection = new HubConnectionBuilder().withUrl("http://localhost:5000/message").build();
        this.hubConnection
          .start()
          .then(() => console.log('Connection started!'))
          .catch(err => console.log('Error while establishing connection :('));
    
        this.hubConnection.on('send', (data) => {
            console.log(data);  
        });
*/

        this.fill();
        var options1 = {
            chart: {
                height: 235,
                type: "radialBar",
            },
            series: [67, 80, 90],
            plotOptions: {
                radialBar: {
                    dataLabels: {
                        total: {
                            show: true,
                            label: 'TOTAL'
                        }
                    }
                }
            },
            labels: ['Total', 'Completed', 'Cancelled']
        };
        new ApexCharts(document.querySelector("#chart1"), options1).render();

        // Chart02

        var options2 = {
            series: [{
                name: "Completed",
                data: [45, 52, 38, 24, 33, 26, 21, 20, 6, 8, 15, 10],
                legend: {
                    colors: ['red']
                }
            }, {
                name: 'Cancelled',
                data: [87, 57, 74, 99, 75, 38, 62, 47, 82, 56, 45, 47]
            }],
            chart: {
                height: 215,
                type: 'line',
                zoom: {
                    enabled: false
                },
                toolbar: {
                    show: false
                }
            },

            colors: ['#556ee6', '#f1b44c'],
            dataLabels: {
                enabled: false
            },
            stroke: {
                width: [2, 2],
                curve: 'straight',
                dashArray: [0, 8, 5],
                colors: ['#556ee6', '#f1b44c']
            },
            title: {
                text: '',
                align: 'left'
            },

            legend: {
                tooltipHoverFormatter: function (val, opts) {
                    return val + ' - ' + opts.w.globals.series[opts.seriesIndex][opts.dataPointIndex] + ''
                }
            },
            markers: {
                size: 0,
                hover: {
                    sizeOffset: 6
                }
            },
            xaxis: {
                categories: ['01 Jan', '02 Jan', '03 Jan', '04 Jan', '05 Jan', '06 Jan', '07 Jan', '08 Jan', '09 Jan',
                    '10 Jan', '11 Jan', '12 Jan'
                ],
            },
            tooltip: {
                y: [{
                    title: {
                        formatter: function (val) {
                            return val + " (mins)"
                        }
                    }
                }, {
                    title: {
                        formatter: function (val) {
                            return val + " per session"
                        }
                    }
                }, {
                    title: {
                        formatter: function (val) {
                            return val;
                        }
                    }
                }]
            },
            grid: {
                borderColor: '#f1f1f1',
            }

        };

        var chart = new ApexCharts(document.querySelector("#chart2"), options2);
        chart.render();

        // Chart03

        var options3 = {
            series: [65],
            chart: {
                height: 100,
                type: 'radialBar',
            },
            stroke: {
                show: true,
                curve: 'smooth',
                lineCap: 'butt',
                colors: undefined,
                width: 2,
                dashArray: 0,
            },
            fill: {
                colors: ['#6d82e8'],
            },
            plotOptions: {
                radialBar: {
                    dataLabels: {
                        name: {
                            show: false,
                            fontSize: '22px',
                        },
                        value: {
                            show: false,
                            fontSize: '16px',
                        },
                        total: {
                            show: false,

                        }
                    }
                }
            },

        };

        var chart = new ApexCharts(document.querySelector("#chart3"), options3);
        chart.render();

        // Chart04

        var options4 = {
            series: [45],
            chart: {
                height: 100,
                type: 'radialBar',
            },
            stroke: {
                show: true,
                curve: 'smooth',
                lineCap: 'butt',
                colors: undefined,
                width: 2,
                dashArray: 0,
            },
            fill: {
                colors: ['#51ca9e'],
            },
            plotOptions: {
                radialBar: {
                    dataLabels: {
                        name: {
                            show: false,
                            fontSize: '22px',
                        },
                        value: {
                            show: false,
                            fontSize: '16px',
                        },
                        total: {
                            show: false,

                        }
                    }
                }
            },

        };

        var chart = new ApexCharts(document.querySelector("#chart4"), options4);
        chart.render();

        // Chart05

        var options5 = {
            series: [35],
            chart: {
                height: 100,
                type: 'radialBar',
            },
            stroke: {
                show: true,
                curve: 'smooth',
                lineCap: 'butt',
                colors: undefined,
                width: 2,
                dashArray: 0,
            },
            fill: {
                colors: ['#f47f7f'],
            },
            plotOptions: {
                radialBar: {
                    dataLabels: {
                        name: {
                            show: false,
                            fontSize: '22px',
                        },
                        value: {
                            show: false,
                            fontSize: '16px',
                        },
                        total: {
                            show: false,

                        }
                    }
                }
            },

        };

        var chart = new ApexCharts(document.querySelector("#chart5"), options5);
        chart.render();

        // Chart06

        var options6 = {
            series: [65],
            chart: {
                height: 100,
                type: 'radialBar',
            },
            stroke: {
                show: true,
                curve: 'smooth',
                lineCap: 'butt',
                colors: undefined,
                width: 2,
                dashArray: 0,
            },
            fill: {
                colors: ['#6d82e8'],
            },
            plotOptions: {
                radialBar: {
                    dataLabels: {
                        name: {
                            show: false,
                            fontSize: '22px',
                        },
                        value: {
                            show: false,
                            fontSize: '16px',
                        },
                        total: {
                            show: false,

                        }
                    }
                }
            },

        };

        var chart = new ApexCharts(document.querySelector("#chart6"), options6);
        chart.render();

        // Chart07

        var options7 = {
            series: [45],
            chart: {
                height: 100,
                type: 'radialBar',
            },
            stroke: {
                show: true,
                curve: 'smooth',
                lineCap: 'butt',
                colors: undefined,
                width: 2,
                dashArray: 0,
            },
            fill: {
                colors: ['#51ca9e'],
            },
            plotOptions: {
                radialBar: {
                    dataLabels: {
                        name: {
                            show: false,
                            fontSize: '22px',
                        },
                        value: {
                            show: false,
                            fontSize: '16px',
                        },
                        total: {
                            show: false,


                        }
                    }
                }
            },

        };

        var chart = new ApexCharts(document.querySelector("#chart7"), options7);
        chart.render();

        // Chart8

        var options8 = {
            series: [35],
            chart: {
                height: 100,
                type: 'radialBar',
            },
            stroke: {
                show: true,
                curve: 'smooth',
                lineCap: 'butt',
                colors: undefined,
                width: 2,
                dashArray: 0,
            },

            fill: {
                colors: ['#f47f7f'],
            },
            plotOptions: {
                radialBar: {
                    dataLabels: {
                        name: {
                            show: false,
                            fontSize: '22px',
                        },
                        value: {
                            show: false,
                            fontSize: '16px',
                        },
                        total: {
                            show: false,

                        }
                    }
                }
            },

        };

        var chart = new ApexCharts(document.querySelector("#chart8"), options8);
        chart.render();

        // Chart9

        var options9 = {
            series: [44, 55, 67, 83],
            chart: {
                height: 250,
                type: 'radialBar',
            },
            plotOptions: {
                radialBar: {
                    dataLabels: {
                        name: {
                            fontSize: '22px',
                        },
                        value: {
                            fontSize: '16px',
                        },
                        total: {
                            show: true,
                            label: 'Total',
                            formatter: function (w) {
                                // By default this function returns the average of all series. The below is just an example to show the use of custom formatter function
                                return 249
                            }
                        }
                    }
                }
            },
            labels: ['User Cancel', 'Driver Cancel', 'Payed Cancel', 'Free Cancel'],
        };

        var chart = new ApexCharts(document.querySelector("#chart9"), options9);
        chart.render();

        // Chart10


        var options10 = {
            series: [{
                name: 'Total Cancel',
                data: [44, 55, 57, 56, 61, 58, 63, 60, 66]
            }, {
                name: 'User Cancel',
                data: [76, 85, 101, 98, 87, 105, 91, 114, 94]
            }, {
                name: 'Driver Cancel',
                data: [35, 41, 36, 26, 45, 48, 52, 53, 41]
            }],
            chart: {
                type: 'bar',
                height: 250,
                toolbar: {
                    show: false
                }
            },
            plotOptions: {
                bar: {
                    horizontal: false,
                    columnWidth: '55%',
                    endingShape: 'rounded'
                },
            },
            dataLabels: {
                enabled: false
            },
            stroke: {
                show: true,
                width: 2,
                colors: ['transparent']
            },
            xaxis: {
                categories: ['Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'],
            },
            yaxis: {
                title: {
                    text: ''
                }
            },
            fill: {
                opacity: 1
            },
            tooltip: {
                y: {
                    formatter: function (val) {
                        return "$ " + val + " thousands"
                    }
                }
            }
        };

        var chart = new ApexCharts(document.querySelector("#chart10"), options10);
        chart.render();

       
    }
    total_Trips =  0;
    total_Turnover = 0;
    total_Approval_Drivers = 0;
    total_Blocked_Drivers = 0;
    total_Earnings=0;
    company_Earnings=0;
    driver_Earnings=0;
    completed_Trips=0;
    on_Going_Trips=0;
    cancelled_Trips=0;
    total_Admin_Earnings=0;
    total_Driver_Earnings=0;
    payment_Cash=0;
    payment_Cards=0;
    payment_Withdraw=0;
    total_Users=0;
    total_Active_Users=0;
    total_InActive_Users=0;
    total_Deleted_Users=0;
    total_Drivers=0;
    total_Active_Drivers=0;
    
    fill(){
        this.dashboardService.list().subscribe(res=>      
            { 
                this.dataDashBoard =res.content;             
                this.total_Earnings = this.dataDashBoard.total_Earnings;
                this.company_Earnings = this.dataDashBoard.company_Earnings;
                this.driver_Earnings = this.dataDashBoard.driver_Earnings;
                this.completed_Trips = this.dataDashBoard.completed_Trips;
                this.on_Going_Trips = this.dataDashBoard.on_Going_Trips;
                this.cancelled_Trips = this.dataDashBoard.cancelled_Trips;
                this.total_Admin_Earnings = this.dataDashBoard.total_Admin_Earnings;
                this.total_Driver_Earnings = this.dataDashBoard.total_Driver_Earnings;
                this.payment_Cash = this.dataDashBoard.payment_Cash;
                this.payment_Cards = this.dataDashBoard.payment_Cards;
                this.payment_Withdraw = this.dataDashBoard.payment_Withdraw;
                this.total_Users = this.dataDashBoard.total_Users;
                this.total_Active_Users = this.dataDashBoard.total_Active_Users;
                this.total_InActive_Users = this.dataDashBoard.total_InActive_Users;
                this.total_Deleted_Users = this.dataDashBoard.total_Deleted_Users;
                this.total_Drivers = this.dataDashBoard.total_Drivers;
                this.total_Active_Drivers = this.dataDashBoard.total_Active_Drivers;          
                this.total_Trips = this.dataDashBoard.total_Trips;
                this.total_Turnover = this.dataDashBoard.total_Turnover;                
                this.total_Approval_Drivers = this.dataDashBoard.total_Approval_Drivers;
                this.total_Blocked_Drivers = this.dataDashBoard.total_Blocked_Drivers;
              console.log(res)
            })
    }

}
