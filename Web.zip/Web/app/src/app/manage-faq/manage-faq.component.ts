import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router'; 
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog'; 
import { ServiceLocationService } from 'src/app/common/services/servicelocation.service';
import { ConfirmDialogComponent } from 'src/app/confirm-dialog/confirm-dialog.component';
import { ExcelService } from '../common/services/export.service';
import { NotificationService } from '../common/services/notification.service';
import { ManageFAQService } from '../common/services/manageFAQ.service';

@Component({
  selector: 'app-manage-faq',
  templateUrl: './manage-faq.component.html',
  styleUrls: ['./manage-faq.component.scss']
})
export class ManageFaqComponent implements OnInit {
  displayedColumns: string[] = ['no', 'FAQ_Question', 'FAQ_Answer','status','complaint_Type','action'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  result: any;
  serviceLocation=[];
  constructor(public manageFAQService:ManageFAQService,
     public router:Router,
     private dialog: MatDialog,
    private snackBar: MatSnackBar) { }
  

  ngOnInit(): void {
    this.fill();  
  }
  fill(){
    this.manageFAQService.list().subscribe(res=>      
      {        
        this.dataSource = new MatTableDataSource(res.content);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      });
  }
  ngAfterViewInit() { 
  }

  applyFilter(filterValue: string) {    
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  redirectEdit(id)
  {
   
  this.router.navigate(['edit-faq'], { queryParams: { id: id } });
  } 
  updateStatus(id,status) {    
    const dialogRef = this.dialog.open(ConfirmDialogComponent,{
      data:{
        message: 'Are you sure want to change the status?',
        buttonText: {
          primarybtn: 'Confirm',
          cancelbtn: 'Cancel'
        }
      }
    });
    
    dialogRef.afterClosed().subscribe((confirmed) => {      
      if (confirmed.isOk) {
        this.manageFAQService.status(id,status).subscribe(res=>{
          if(res.isOK){
            this.snackBar.open(res.message, 'Fechar', {
              duration: 2000,
              panelClass: ['close-snackbar']
            });
            this.fill(); 
          }
        });        
      }
    });
  }

  delete(id) {    
    const dialogRef = this.dialog.open(ConfirmDialogComponent,{
      data:{
        message: 'Are you sure want to change the delete?',
        buttonText: {
          primarybtn: 'Confirm',
          cancelbtn: 'Cancel'
        }
      }
    });
    
    dialogRef.afterClosed().subscribe((confirmed) => {      
      if (confirmed.isOk) {
        this.manageFAQService.delete(id).subscribe(res=>{
          if(res.isOK){
            this.snackBar.open(res.message, 'Fechar', {
              duration: 2000,
              panelClass: ['delete-snackbar']
            });
            this.fill(); 
          }
        });        
      }
    });
  }
}
