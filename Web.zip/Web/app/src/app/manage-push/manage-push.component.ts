import { Component, OnInit } from '@angular/core';
declare var $:any;

@Component({
  selector: 'app-manage-push',
  templateUrl: './manage-push.component.html',
  styleUrls: ['./manage-push.component.scss']
})
export class ManagePushComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    $(document).ready(function() {
      $('#multiple-checkboxes').multiselect({
        includeSelectAllOption: true,
      });
      $('#multiple-checkboxes1').multiselect({
        includeSelectAllOption: true,
      });
  });
  }

}
