import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagePushComponent } from './manage-push.component';

describe('ManagePushComponent', () => {
  let component: ManagePushComponent;
  let fixture: ComponentFixture<ManagePushComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagePushComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagePushComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
