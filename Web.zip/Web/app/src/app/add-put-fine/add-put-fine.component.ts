import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DriverService } from '../common/services/driver.service';
import { VehicleService } from '../common/services/vehicle.service';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-add-put-fine',
  templateUrl: './add-put-fine.component.html',
  styleUrls: ['./add-put-fine.component.scss']
})
export class AddPutFineComponent implements OnInit {
  submitted = false;
  constructor(private formBuilder: FormBuilder, 
    private driverService:DriverService, 
    private router:Router,
    private snackBar: MatSnackBar,
    private vehicleService:VehicleService) { }
  registerForm:FormGroup;
  driverList
  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      driverName: ['', Validators.required],
      amount: ['', Validators.required],
      reason: ['', Validators.required]
    });

    this.driverService.listDriver().subscribe(res=>      
      { 
        this.driverList = res.content; 
      })
  }
  get f() { return this.registerForm.controls; }

  onSubmit() {
    this.submitted = true;
  
    var modalUser={
      driverid: this.registerForm.controls.driverName.value,
      fineamount: this.registerForm.controls.amount.value,
      fine_reason: this.registerForm.controls.reason.value,
    }


    this.driverService.saveFine(modalUser).subscribe(res => {
      if(res.isOK)
      {
        this.router.navigate(['manage-fine']);
      }
      else
      {
        this.snackBar.open(res.message, 'Fechar', {
          duration: 2000,
          panelClass: ['close-snackbar']
        });
      }
    });
  }
  cancel(){
    this.router.navigate(['manage-fine']);
  }
}

