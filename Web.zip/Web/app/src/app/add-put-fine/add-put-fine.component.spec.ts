import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddPutFineComponent } from './add-put-fine.component';

describe('AddPutFineComponent', () => {
  let component: AddPutFineComponent;
  let fixture: ComponentFixture<AddPutFineComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddPutFineComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddPutFineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
