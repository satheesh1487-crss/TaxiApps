import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { VehicleService } from '../common/services/vehicle.service';

@Component({
  selector: 'app-driver-wallet',
  templateUrl: './driver-wallet.component.html',
  styleUrls: ['./driver-wallet.component.scss']
})
export class DriverWalletComponent implements OnInit {

  displayedColumns: string[] = ['no', 'transaction','amount', 'date','action'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  id: number;
  amountAdded
  amountBalance
  amountSpent
  constructor( private activatedRoute:ActivatedRoute,public vehicleService: VehicleService, ) { }

  ngOnInit(): void {
    this.activatedRoute
      .queryParams
      .subscribe(params => {
        // Defaults to 0 if no query param provided.
        this.id = Number(params['id']);
      });
      this.fillList();
  }
  fillList(){
    this.vehicleService.getWallet(this.id).subscribe(res=>{
      if(res.isOK)
      {
        this.dataSource = new MatTableDataSource(res.content.walletList);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.amountAdded =res.content.amountadded;
        this.amountBalance =res.content.amountbalance;
        this.amountSpent =res.content.amountspent;
      }
    });
  }

}
