import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router'; 
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog'; 
import { ConfirmDialogComponent } from 'src/app/confirm-dialog/confirm-dialog.component';
import { NotificationService } from '../common/services/notification.service';


@Component({
  selector: 'app-manage-sms-option',
  templateUrl: './manage-sms-option.component.html',
  styleUrls: ['./manage-sms-option.component.scss']
})
export class ManageSmsOptionComponent implements OnInit {
  displayedColumns: string[] = ['no', 'smstitle', 'description','status','action'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  result: any;
 
  constructor(public notificationService:NotificationService,
     public router:Router,
     private dialog: MatDialog,
    private snackBar: MatSnackBar) { }
  

  ngOnInit(): void {
    this.fillSms();  
  }
  fillSms(){
    this.notificationService.listSms().subscribe(res=>      
      {        
        this.dataSource = new MatTableDataSource(res.content);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      });
  }
  ngAfterViewInit() { 
  }

  applyFilter(filterValue: string) {    
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  redirectEdit(id)
  {
   
  this.router.navigate(['edit-sms'], { queryParams: { id: id } });
  } 
  updateStatus(id,status) {
    
    const dialogRef = this.dialog.open(ConfirmDialogComponent,{
      data:{
        message: 'Are you sure want to change the status?',
        buttonText: {
          primarybtn: 'Confirm',
          cancelbtn: 'Cancel'
        }
      }
    });
    
    dialogRef.afterClosed().subscribe((confirmed) => {
      
      if (confirmed.isOk) {
        this.notificationService.statusSms(id,status).subscribe(res=>{
          if(res.isOK){
            this.snackBar.open(res.message, 'Fechar', {
              duration: 2000,
              panelClass: ['close-snackbar']
            });
            this.fillSms(); 
          }
        })
        
      }
    });
  }
  
}
