import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageSmsOptionComponent } from './manage-sms-option.component';

describe('ManageSmsOptionComponent', () => {
  let component: ManageSmsOptionComponent;
  let fixture: ComponentFixture<ManageSmsOptionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageSmsOptionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageSmsOptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
