import { Component, OnInit} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ServiceLocationService } from '../common/services/servicelocation.service';
import { Router} from '@angular/router';
import { ManageFAQService } from '../common/services/manageFAQ.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-add-faq',
  templateUrl: './add-faq.component.html',
  styleUrls: ['./add-faq.component.scss']
})
export class AddFaqComponent implements OnInit {
  authService: any; 
  isSubmitted = false;
  ErrorMessage
  areaVal = '';
  registerForm: FormGroup;
  arealist: any;
  constructor(private formBuilder: FormBuilder,
    private router: Router,
    private snackBar: MatSnackBar,
    public manageFAQService: ManageFAQService,
    public serviceLocationService: ServiceLocationService,) { }

  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      areaname: ['', Validators.required],     
      faQ_Question: ['', Validators.required],
      faQ_Answer: ['', Validators.required],
      complaint_Type: ['', Validators.required]
    });
    this.serviceLocationService.list().subscribe(res => {
      if (res.isOK) {
        this.arealist = res.content;
      }
    });
  }
  onSubmit() { 
    this.isSubmitted = true;
    if (!this.registerForm.valid) {
      return;
  }
       var faq={
      servicelocid:this.registerForm.controls.areaname.value,     
      faQ_Question:this.registerForm.controls.faQ_Question.value,
      faQ_Answer:this.registerForm.controls.faQ_Answer.value,
      complaint_Type:this.registerForm.controls.complaint_Type.value,      
    }
    this.manageFAQService.save(faq).subscribe(res=>{
      if(res.isOK){
        this.router.navigate(['manage-faq']);
      }
      else
      {
        this.snackBar.open(res.message, 'Fechar', {
          duration: 2000,
          panelClass: ['close-snackbar']
        });
      }
    });

  } 
  get f() {
    return this.registerForm.controls;
  } 
  cancel(){
    this.router.navigate(['manage-faq']);
  } 
}
