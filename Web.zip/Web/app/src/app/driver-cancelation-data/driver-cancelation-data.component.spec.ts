import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DriverCancelationDataComponent } from './driver-cancelation-data.component';

describe('DriverCancelationDataComponent', () => {
  let component: DriverCancelationDataComponent;
  let fixture: ComponentFixture<DriverCancelationDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DriverCancelationDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DriverCancelationDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
