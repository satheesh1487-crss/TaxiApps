import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-driver-cancelation-data',
  templateUrl: './driver-cancelation-data.component.html',
  styleUrls: ['./driver-cancelation-data.component.scss']
})
export class DriverCancelationDataComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
