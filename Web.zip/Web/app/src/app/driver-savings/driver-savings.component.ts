import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-driver-savings',
  templateUrl: './driver-savings.component.html',
  styleUrls: ['./driver-savings.component.scss']
})
export class DriverSavingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
