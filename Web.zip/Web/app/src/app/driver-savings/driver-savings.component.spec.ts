import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DriverSavingsComponent } from './driver-savings.component';

describe('DriverSavingsComponent', () => {
  let component: DriverSavingsComponent;
  let fixture: ComponentFixture<DriverSavingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DriverSavingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DriverSavingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
