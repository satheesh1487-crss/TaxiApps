import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from '../common/auth/auth.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MustMatch } from '../common/utility/common.validator';
import { UtilityService } from '../common/services/utility.service';
import { DriverService } from '../common/services/driver.service';
import { ServiceLocationService } from '../common/services/servicelocation.service';
import { ZoneService } from '../common/services/zone.service';
import { VehicleService } from '../common/services/vehicle.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-edit-driver',
  templateUrl: './edit-driver.component.html',
  styleUrls: ['./edit-driver.component.scss']
})
export class EditDriverComponent implements OnInit {
  
  filename
  submitted = false;
  langs: any;
  CountryVal =''; 
  TimeZoneVal ='';

  areaVal = '';
  currencyVal = '';
  unitVal = '';
    
  arealist: any;
  countries: any;
  driverType
  vechileType:any;
  zoneList: any;
  id: number;
  constructor(private router:Router,
    private vehicleService:VehicleService,
    private driverService:DriverService,
    private utilityService:UtilityService,
    private snackBar: MatSnackBar,
    private serviceLocationService:ServiceLocationService,
    private zoneService:ZoneService,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder) { }
    registerForm:FormGroup;
  ngOnInit(): void {
    this.route
    .queryParams
    .subscribe(params => {
      // Defaults to 0 if no query param provided.
      this.id = Number(params['id']);
    });


    this.registerForm = this.formBuilder.group({
      firstname: ['', Validators.required],
      lastname: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phonenumber: ['', Validators.required],
      Gender: ['', Validators.required],
      Address: ['', Validators.required],
      City: ['', Validators.required],
      State: ['', Validators.required],
      Country: ['', Validators.required],
      areaname:['',Validators.required],
      DriverArea: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(8)]],
      confirmPassword: ['', Validators.required],
      DriverType: ['', Validators.required],
      NationalID: ['', Validators.required],
      profilepicture:['']
    }, {
      validator: MustMatch('password', 'confirmPassword')
  });
  this.getbyId();

  this.utilityService.listCountry().subscribe(res=>      
    {       
      this.countries = res.content; 
    });

    this.vehicleService.listtype().subscribe(res=>      
      {           
        this.vechileType = res.content; 
      });
     
}
getbyId(){
  this.driverService.getById(this.id).subscribe(res => {
    debugger
    if(res.isOK){
      this.registerForm = this.formBuilder.group({      
      firstname: [res.content.firstName, Validators.required],
      lastname: [res.content.lastName, Validators.required],
      email: [res.content.email, [Validators.required, Validators.email]],
      phonenumber: [res.content.contactNo, Validators.required],
      Gender: [res.content.gender, Validators.required],
      Address: [res.content.address, Validators.required],
      City: [res.content.city, Validators.required],
      State: [res.content.state, Validators.required],
      Country: [res.content.country, Validators.required],
      areaname:[res.content.driverArea,Validators.required],
      DriverArea: [res.content.DriverArea, Validators.required],
     
      DriverType: [res.content.driverType, Validators.required],
      NationalID: [res.content.NationalID, Validators.required],
      profilepicture:[res.content.profilepicture, Validators.required] 
    });
    this.fillServiceArea(res.content.country);
    this.fillServiceZone(res.content.driverArea);
  }
  });
 
}
ErrorMessage
fileToUpload: File = null;

handleFileInput(files: FileList) {
  console.log(files)
 var regex = new RegExp("(.*?)\.(docx|doc|pdf|xml|bmp|ppt|xls)$");
  this.fileToUpload = files.item(0);
  if (!(regex.test(this.fileToUpload[0]))) {
    
  }
} 
  numberOnly(event): boolean {   
  const charCode = (event.which) ? event.which : event.keyCode;
  if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    return false;
  }
  return true;
}

  get f() { return this.registerForm.controls; }


  onChange(event){
    this.zoneService.serviceBasedZone(event.srcElement.value).subscribe(res=>      
      {           
        this.zoneList = res.content; 
      }); 
  }

  onArea(event){ 
    this.serviceLocationService.countryByservicelocId(event.srcElement.value).subscribe(res=>      
      {           
        this.arealist = res.content; 
      });
  }
 
  onSubmit() {
    this.submitted = true;
     
    
    var driverModal={
     
      firstName: this.registerForm.controls.firstname.value,
      lastName: this.registerForm.controls.lastname.value,
      email: this.registerForm.controls.email.value,
      contactNo: this.registerForm.controls.phonenumber.value,
      city: this.registerForm.controls.City.value,
      state: this.registerForm.controls.State.value,
      country: this.registerForm.controls.Country.value,
      driverArea: this.registerForm.controls.DriverArea.value,
       driverType: this.registerForm.controls.DriverType.value,
      areaname:this.registerForm.controls.areaname.value,
      driverid:this.id,
      
      gender: this.registerForm.controls.Gender.value,
     
      nationalId: this.registerForm.controls.NationalID.value,      
      address: this.registerForm.controls.Address.value,
      
      profilepicture:"document" 
  }; 
  this.driverService.editDriver(driverModal,this.id).subscribe(res => {
    if (res.isOK) {
      this.router.navigate(['manage-driver']);
    }
    else
      {
        this.snackBar.open(res.message, 'Fechar', {
          duration: 2000,
          panelClass: ['close-snackbar']
        });
      }
  });
  }
  dropChange(event,name){
    
  }
  cancel(){
    this.router.navigate(['manage-driver']);
  }

  fillServiceArea(val){
    this.serviceLocationService.countryByservicelocId(val).subscribe(res=>      
      {           
        this.arealist = res.content; 
      });
  }

  fillServiceZone(val){
    this.zoneService.serviceBasedZone(val).subscribe(res=>      
      {           
        this.zoneList = res.content; 
      }); 
  }
}
