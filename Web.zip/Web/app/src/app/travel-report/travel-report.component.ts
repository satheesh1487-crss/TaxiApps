import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-travel-report',
  templateUrl: './travel-report.component.html',
  styleUrls: ['./travel-report.component.scss']
})
export class TravelReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
