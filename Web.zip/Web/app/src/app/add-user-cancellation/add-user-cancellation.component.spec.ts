import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddUserCancellationComponent } from './add-user-cancellation.component';

describe('AddUserCancellationComponent', () => {
  let component: AddUserCancellationComponent;
  let fixture: ComponentFixture<AddUserCancellationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddUserCancellationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddUserCancellationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
