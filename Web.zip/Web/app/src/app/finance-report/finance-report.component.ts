import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-finance-report',
  templateUrl: './finance-report.component.html',
  styleUrls: ['./finance-report.component.scss']
})
export class FinanceReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
