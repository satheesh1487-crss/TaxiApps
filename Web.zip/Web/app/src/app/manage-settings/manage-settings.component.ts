import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { SettingService } from '../common/services/settings.service';

@Component({
  selector: 'app-manage-settings',
  templateUrl: './manage-settings.component.html',
  styleUrls: ['./manage-settings.component.scss']
})
export class ManageSettingsComponent implements OnInit {
  submitted = false; 
  id: number;
  constructor(private formBuilder: FormBuilder,
    private settingService:SettingService,
    private route: ActivatedRoute,
    private snackBar: MatSnackBar,
    public router:Router) { }
  registerForm:FormGroup;
  ngOnInit(): void {
    this.route
    .queryParams
    .subscribe(params => {
      // Defaults to 0 if no query param provided.
      this.id = Number(params['id']);
    });

    this.registerForm = this.formBuilder.group({
      trip_how_trip_assign: ['', Validators.required],
      trip_how_many_seconds: ['', Validators.required],
      trip_radius_to_get_captains: ['', Validators.required],
      trip_auto_transfer: ['', Validators.required],
      trip_captain_auto_offline: ['', Validators.required],
      trip_how_many_trips: ['', Validators.required],
      trip_pickup_location: ['', Validators.required],
      trip_top20_captains: ['', Validators.required],
      trip_grace_time_waiting: ['', Validators.required],
      trip_minimum_time_period: ['', Validators.required],
      trip_dispatch_request: ['', Validators.required],
      trip_cancel_button_enable: ['', Validators.required],
      trip_reward_points: ['', Validators.required],
      wallet_user_wallet_amount: ['', Validators.required],
      wallet_captain_wallet_amount: ['', Validators.required],
      wallet_maximum_balance: ['', Validators.required],
      wallet_maximum_amount_added: ['', Validators.required],
      installation_google_browser_key: ['', Validators.required],
      installation_sms_gateway_url: ['', Validators.required],
      installation_sms_account_sid: ['', Validators.required],
      installation_sms_auth_taken: ['', Validators.required],
      installation_sms_auth_number: ['', Validators.required],
      installation_braintree_environment: ['', Validators.required],
      installation_sandbox: ['', Validators.required],
      installation_braintree_merchant_id: ['', Validators.required],
      installation_braintree_public_key: ['', Validators.required],
      installation_braintree_private_key: ['', Validators.required],
      installation_braintree_master_merchant: ['', Validators.required],
      installation_braintree_default_merchant: ['', Validators.required],
      installation_payment_gateway_merchant_id: ['', Validators.required],
      installation_stripe_payment_public_key: ['', Validators.required],
      installation_stripe_payment_private_key: ['', Validators.required],
      installation_stripe_payment_master_merchant: ['', Validators.required],
      installation_stripe_payment_default_merchant: ['', Validators.required],
      general_application_name: ['', Validators.required],
      general_application_logo: ['', Validators.required],
      general_head_office_number: ['', Validators.required],
      general_customer_care_number: ['', Validators.required],
      general_help_email_address: ['', Validators.required],
      general_time_zone: ['', Validators.required],
      isActive: ['', Validators.required]      
    });  
    this.getbyId(); 
  }  
  getbyId(){
    this.settingService.getById(this.id).subscribe(res => {
        this.registerForm = this.formBuilder.group({        
        trip_how_trip_assign: [res.content.trip_how_trip_assign, [Validators.required]],
        trip_how_many_seconds: [res.content.number, [Validators.required]],
        trip_radius_to_get_captains: [res.content.number, [Validators.required]],
        trip_auto_transfer: [res.content.number, [Validators.required]],
        trip_captain_auto_offline: [res.content.number, [Validators.required]],
        trip_how_many_trips: [res.content.number, [Validators.required]],
        trip_pickup_location: [res.content.number, [Validators.required]],
        trip_top20_captains: [res.content.number, [Validators.required]],
        trip_grace_time_waiting: [res.content.number, [Validators.required]],
        trip_minimum_time_period: [res.content.number, [Validators.required]],
        trip_dispatch_request: [res.content.number, [Validators.required]],
        trip_cancel_button_enable: [res.content.number, [Validators.required]],
        trip_reward_points: [res.content.number, [Validators.required]],
        wallet_user_wallet_amount: [res.content.number, [Validators.required]],
        wallet_captain_wallet_amount: [res.content.number, [Validators.required]],
        wallet_maximum_balance: [res.content.number, [Validators.required]],
        wallet_maximum_amount_added: [res.content.number, [Validators.required]],
        installation_google_browser_key: [res.content.number, [Validators.required]],
        installation_sms_gateway_url: [res.content.number, [Validators.required]],
        installation_sms_account_sid: [res.content.number, [Validators.required]],
        installation_sms_auth_taken: [res.content.number, [Validators.required]],
        installation_sms_auth_number: [res.content.number, [Validators.required]],
        installation_braintree_environment: [res.content.number, [Validators.required]],
        installation_sandbox: [res.content.number, [Validators.required]],
        installation_braintree_merchant_id: [res.content.number, [Validators.required]],
        installation_braintree_public_key: [res.content.number, [Validators.required]],
        installation_braintree_private_key: [res.content.number, [Validators.required]],
        installation_braintree_master_merchant: [res.content.number, [Validators.required]],
        installation_braintree_default_merchant: [res.content.number, [Validators.required]],
        installation_payment_gateway_merchant_id: [res.content.number, [Validators.required]],
        installation_stripe_payment_public_key: [res.content.number, [Validators.required]],
        installation_stripe_payment_private_key: [res.content.number, [Validators.required]],
        installation_stripe_payment_master_merchant: [res.content.number, [Validators.required]],
        installation_stripe_payment_default_merchant: [res.content.number, [Validators.required]],
        general_application_name: [res.content.number, [Validators.required]],
        general_application_logo: [res.content.number, [Validators.required]],
        general_head_office_number: [res.content.number, [Validators.required]],
        general_customer_care_number: [res.content.number, [Validators.required]],
        general_help_email_address: [res.content.number, [Validators.required]],
        general_time_zone: [res.content.number, [Validators.required]],
        isActive: [res.content.number, [Validators.required]], 
      });
    })
  }
  get f() { return this.registerForm.controls; }
  onSubmit() {    
    this.submitted = true;
 
    if (!this.registerForm.valid) {
        return;
    }
    var settingModal = {      
      trip_how_trip_assign: this.registerForm.controls.trip_how_trip_assign.value,
      trip_how_many_seconds: this.registerForm.controls.trip_how_many_seconds.value,
      trip_radius_to_get_captains: this.registerForm.controls.trip_radius_to_get_captains.value,
      trip_auto_transfer: this.registerForm.controls.trip_auto_transfer.value,
      trip_captain_auto_offline: this.registerForm.controls.trip_captain_auto_offline.value,
      trip_how_many_trips: this.registerForm.controls.trip_how_many_trips.value,
      trip_pickup_location: this.registerForm.controls.trip_pickup_location.value,
      trip_top20_captains: this.registerForm.controls.trip_top20_captains.value,
      trip_grace_time_waiting: this.registerForm.controls.trip_grace_time_waiting.value,
      trip_minimum_time_period: this.registerForm.controls.trip_minimum_time_period.value,
      trip_dispatch_request: this.registerForm.controls.trip_dispatch_request.value,
      trip_cancel_button_enable: this.registerForm.controls.trip_cancel_button_enable.value,
      trip_reward_points: this.registerForm.controls.trip_reward_points.value,
      wallet_user_wallet_amount: this.registerForm.controls.wallet_user_wallet_amount.value,
      wallet_captain_wallet_amount: this.registerForm.controls.wallet_captain_wallet_amount.value,
      wallet_maximum_balance: this.registerForm.controls.wallet_maximum_balance.value,
      wallet_maximum_amount_added: this.registerForm.controls.wallet_maximum_amount_added.value,
      installation_google_browser_key: this.registerForm.controls.installation_google_browser_key.value,
      installation_sms_gateway_url: this.registerForm.controls.installation_sms_gateway_url.value,
      installation_sms_account_sid: this.registerForm.controls.installation_sms_account_sid.value,
      installation_sms_auth_taken: this.registerForm.controls.installation_sms_auth_taken.value,
      installation_sms_auth_number: this.registerForm.controls.installation_sms_auth_number.value,
      installation_braintree_environment: this.registerForm.controls.installation_braintree_environment.value,
      installation_sandbox: this.registerForm.controls.installation_sandbox.value,
      installation_braintree_merchant_id: this.registerForm.controls.installation_braintree_merchant_id.value,
      installation_braintree_public_key: this.registerForm.controls.installation_braintree_public_key.value,
      installation_braintree_private_key: this.registerForm.controls.installation_braintree_private_key.value,
      installation_braintree_master_merchant: this.registerForm.controls.installation_braintree_master_merchant.value,
      installation_braintree_default_merchant: this.registerForm.controls.installation_braintree_default_merchant.value,
      installation_payment_gateway_merchant_id: this.registerForm.controls.installation_payment_gateway_merchant_id.value,
      installation_stripe_payment_public_key: this.registerForm.controls.installation_stripe_payment_public_key.value,
      installation_stripe_payment_private_key: this.registerForm.controls.installation_stripe_payment_private_key.value,
      installation_stripe_payment_master_merchant: this.registerForm.controls.installation_stripe_payment_master_merchant.value,
      installation_stripe_payment_default_merchant: this.registerForm.controls.installation_stripe_payment_default_merchant.value,
      general_application_name: this.registerForm.controls.general_application_name.value,
      general_application_logo: this.registerForm.controls.general_application_logo.value,
      general_head_office_number: this.registerForm.controls.general_head_office_number.value,
      general_customer_care_number: this.registerForm.controls.general_customer_care_number.value,
      general_help_email_address: this.registerForm.controls.general_help_email_address.value,
      general_time_zone: this.registerForm.controls.general_time_zone.value,
      isActive: this.registerForm.controls.isActive.value,
      Id: this.id, 
    };
    this.settingService.save(settingModal).subscribe(res => {
      if (res.isOK) {
        this.router.navigate(['manage-settings']);
      }
      else
      {
        this.snackBar.open(res.message, 'Fechar', {
          duration: 2000,
          panelClass: ['close-snackbar']
        });
      }
    });
  } 
  cancel(){
    this.router.navigate(['manage-settings']);
  } 
}
