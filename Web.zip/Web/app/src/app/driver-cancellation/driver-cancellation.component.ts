import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { CancelService } from '../common/services/cancel.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-driver-cancellation',
  templateUrl: './driver-cancellation.component.html',
  styleUrls: ['./driver-cancellation.component.scss']
})
export class DriverCancellationComponent implements OnInit {
  displayedColumns: string[] = ['no', 'cancellationlist', 'payingstatus','status','type','arrivalstatus','isActive'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  result: any;
  
  constructor(public cancelService:CancelService, public router:Router,private dialog: MatDialog,
    private snackBar: MatSnackBar) {}
  

  ngOnInit(): void {
    this.fillDriverCancel();    
  }
  fillDriverCancel(){
    this.cancelService.listCancelDriver().subscribe(res=>      
      { 
        console.log(res)
        this.dataSource = new MatTableDataSource(res.content);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      })
  }
  ngAfterViewInit() { 
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  redirectEdit(id)
  {
    this.router.navigate(['edit-driver-cancellation'], { queryParams: { id: id } });
  } 
  delete(id) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent,{
      data:{
        message: 'Are you sure want to delete?',
        buttonText: {
          primarybtn: 'Confirm',
          cancelbtn: 'Cancel'
        }
      }
    });
    
    dialogRef.afterClosed().subscribe((confirmed) => {
      if (confirmed.isOk) {
        this.cancelService.deleteDriver(id).subscribe(res=>{
          if(res.isOK){
            this.snackBar.open(res.message, 'Fechar', {
              duration: 2000,
              panelClass: ['delete-snackbar']
            });
            this.fillDriverCancel();
          }
        })
        
      }
    });
  }
  updateStatus(id,status) {    
    const dialogRef = this.dialog.open(ConfirmDialogComponent,{
      data:{
        message: 'Are you sure want to change the status?',
        buttonText: {
          primarybtn: 'Confirm',
          cancelbtn: 'Cancel'
        }
      }
    });
    
    dialogRef.afterClosed().subscribe((confirmed) => {
      
      if (confirmed.isOk) {
        this.cancelService.statusDriver(id,status).subscribe(res=>{
          if(res.isOK){
            this.snackBar.open(res.message, 'Fechar', {
              duration: 2000,
              panelClass: ['close-snackbar']
            });
            this.fillDriverCancel();
          }
        })
        
      }
    });
  }
}

