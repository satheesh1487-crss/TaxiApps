import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DriverCancellationComponent } from './driver-cancellation.component';

describe('DriverCancellationComponent', () => {
  let component: DriverCancellationComponent;
  let fixture: ComponentFixture<DriverCancellationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DriverCancellationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DriverCancellationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
