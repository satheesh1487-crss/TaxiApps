import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { VehicleService } from '../common/services/vehicle.service';
import { MatSnackBar } from '@angular/material/snack-bar';


@Component({
  selector: 'app-add-sos',
  templateUrl: './add-sos.component.html',
  styleUrls: ['./add-sos.component.scss']
})
export class AddSosComponent implements OnInit {
  submitted = false;
    constructor(private router:Router,
      private snackBar: MatSnackBar,
      private vehicleService:VehicleService,
      private formBuilder: FormBuilder) { }
      registerForm:FormGroup;
    ngOnInit(): void {
      this.registerForm = this.formBuilder.group({
        SOSName: ['', Validators.required],
        SOSNumber:['', Validators.required]       
      });
    }
    ErrorMessage
    numberOnly(event): boolean {
   
      const charCode = (event.which) ? event.which : event.keyCode;
      if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
      }
      return true;
    }
    get f() { return this.registerForm.controls; }
  
    onSubmit() { 
      this.submitted = true;
      if (this.registerForm.invalid) {
          return;
      }
      var vehicleEmerModal = {
        name: this.registerForm.controls.SOSName.value,
        number: this.registerForm.controls.SOSNumber.value,
        
      };
      this.vehicleService.saveEmer(vehicleEmerModal).subscribe(res => {
        if (res.isOK) {
          this.router.navigate(['manage-sos']);
        }
        else
      {
        this.snackBar.open(res.message, 'Fechar', {
          duration: 2000,
          panelClass: ['close-snackbar']
        });
      }
      });
    }
  }
  