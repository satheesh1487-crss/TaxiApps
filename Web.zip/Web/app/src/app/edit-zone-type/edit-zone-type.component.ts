import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { VehicleService } from '../common/services/vehicle.service';
import { ZoneService } from '../common/services/zone.service';

@Component({
  selector: 'app-edit-zone-type',
  templateUrl: './edit-zone-type.component.html',
  styleUrls: ['./edit-zone-type.component.scss']
})
export class EditZoneTypeComponent implements OnInit {
  vechileType: any;
  submitted;
  isSubmitted;
  registerForm: FormGroup;
  zoneId: any;
  typeId: any;
  constructor(private zoneService: ZoneService,
    private vehicleService: VehicleService,
    private route: ActivatedRoute,
    private router: Router,
    private formBuilder: FormBuilder) { }
  ngOnInit(): void {
    this.vehicleService.listtype().subscribe(res => {
      this.vechileType = res.content;
    });

    this.route
      .queryParams
      .subscribe(params => {
        // Defaults to 0 if no query param provided.
        this.zoneId = Number(params['zoneId']);
        this.typeId = Number(params['typeId']);
      });
    this.registerForm = this.formBuilder.group({
      areaname: ['', Validators.required],
      showbill: ['', Validators.required],
      cash: [''],
      wallet: [''],
      card: [''],
    });
    this.filById();
  }

  filById() {
    this.zoneService.getByTypeId(this.typeId, this.zoneId).subscribe(res => {
      if (res.isOk) {
        console.log(res.content)
        this.registerForm = this.formBuilder.group({
          areaname: [res.content.areaname, Validators.required],
          showbill: [res.content.showbill, Validators.required],
          cash: [''],
          wallet: [''],
          card: [''],
        });
      }
    });
  }
  Payment = '';
  onChange(event, payType) {
    if (payType == "Cash") {
      if (event.srcElement.checked)
        this.Payment = this.Payment + "Cash ,";
      else
        this.Payment = this.Payment.replace("Cash ,", "")
    }
    if (payType == "Wallet") {
      if (event.srcElement.checked)
        this.Payment = this.Payment + "Wallet ,";
      else
        this.Payment = this.Payment.replace("Wallet ,", "")
    }
    if (payType == "Card") {
      if (event.srcElement.checked)
        this.Payment = this.Payment + "Card ,";
      else
        this.Payment = this.Payment.replace("Card ,", "")
    }
  }
  get f() {
    return this.registerForm.controls;
  } 
  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid

    this.isSubmitted = true;  
    if (!this.registerForm.valid) {
      return;
    }  


    var body = {
      zoneid: this.zoneId,
      paymentmode: this.Payment,
      showbill: this.registerForm.controls.showbill.value,
      typeid: this.registerForm.controls.areaname.value,
      relationid: this.typeId,

    }
    this.zoneService.editOperationType(body).subscribe(res => {
      if (res.isOK) {
        this.router.navigate(['zone-type-view'], { queryParams: { zoneId: this.zoneId } });
      }
    });
  }
  add() {
    this.router.navigate(['zone-type-view'], { queryParams: { zoneId: this.zoneId } });
  }
  zone() {

  }

}
