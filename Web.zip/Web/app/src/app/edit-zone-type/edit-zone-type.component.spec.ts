import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditZoneTypeComponent } from './edit-zone-type.component';

describe('EditZoneTypeComponent', () => {
  let component: EditZoneTypeComponent;
  let fixture: ComponentFixture<EditZoneTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditZoneTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditZoneTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
