import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-blocked-documents',
  templateUrl: './manage-blocked-documents.component.html',
  styleUrls: ['./manage-blocked-documents.component.scss']
})
export class ManageBlockedDocumentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
