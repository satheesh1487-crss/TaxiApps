import { Component, OnInit, ViewChild } from '@angular/core';
import { CurrencyService } from '../common/services/currency.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { VehicleService } from '../common/services/vehicle.service';
import { Router, ActivatedRoute } from '@angular/router';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-add-money-wallet',
  templateUrl: './add-money-wallet.component.html',
  styleUrls: ['./add-money-wallet.component.scss']
})
export class AddMoneyWalletComponent implements OnInit {
  id: number;
  displayedColumns: string[] = ['no', 'amount', 'date'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(public currencyService: CurrencyService,
    public vehicleService: VehicleService,
    public router:Router,
    private snackBar: MatSnackBar,
    private route:ActivatedRoute, 
    private formBuilder: FormBuilder,) { }
  currencyList
  registerForm:FormGroup;
  submitted
  ngOnInit(): void {
    this.route
      .queryParams
      .subscribe(params => {
        // Defaults to 0 if no query param provided.
        this.id = Number(params['id']);
      });
    this.registerForm = this.formBuilder.group({
      currencyName: ['', Validators.required],
      amount: ['', Validators.required],
    });
    this.currencyService.list().subscribe(res => {
      this.currencyList = res.content;
    })
    this.fillList();
  }


  fillList(){
    this.vehicleService.getWallet(this.id).subscribe(res=>{
      if(res.isOK)
      {
        this.dataSource = new MatTableDataSource(res.content.walletList);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      }
    });
  }

  onSubmit() {
    this.submitted = true;
      var modalUser={
        driverId:this.id,
        currencyid: this.registerForm.controls.currencyName.value,
        walletamount: this.registerForm.controls.amount.value,
      }


      this.vehicleService.saveWallet(modalUser).subscribe(res=>{
        if(res.isOK)
        {
          this.router.navigate(['manage-wallet-payment']);
        }
        else
      {
        this.snackBar.open(res.message, 'Fechar', {
          duration: 2000,
          panelClass: ['close-snackbar']
        });
      }
      })
    }


    get f() { return this.registerForm.controls; }

}
