import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UtilityService } from 'src/app/common/services/utility.service';
import { ServiceLocationService } from 'src/app/common/services/servicelocation.service';
import { RoleService } from 'src/app/common/services/role.service';
import { AdminService } from 'src/app/common/services/admin.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-manage-admin-edit',
  templateUrl: './manage-admin-edit.component.html',
  styleUrls: ['./manage-admin-edit.component.scss']
})
export class ManageAdminEditComponent implements OnInit {

  submitted = false;
  langs: any;
  roles: any;
  zones: any; 
  id
  areaList: any;
  constructor(private formBuilder: FormBuilder,
    private utilityService: UtilityService,
    private adminService: AdminService,
    private route: ActivatedRoute,
    public router: Router,
    private snackBar: MatSnackBar,
    private serviceLocationService: ServiceLocationService,
    public roleService: RoleService) { }
  registerForm: FormGroup;
  countries
  ngOnInit(): void {

    this.route
      .queryParams
      .subscribe(params => {
        // Defaults to 0 if no query param provided.
        this.id = Number(params['id']);
      });
    this.registerForm = this.formBuilder.group({
      firstname: ['', Validators.required],
      lastname: ['', Validators.required],
      rolename: ['', Validators.required],
      areaname: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phonenumber: ['', Validators.required],
      Emerphonenumber: ['', Validators.required],
      Postalcode: ['', Validators.required, Validators.minLength(6)],
      Country: ['', Validators.required],
      Address: ['', Validators.required],
      TimeZone: ['', Validators.required],
      languagename: ['', Validators.required],
      confirmPassword: ['', Validators.required],
      profilePicture: ['', Validators.required],
      documentName: ['', Validators.required],
      document: ['', Validators.required]
    });


    this.roleService.listRole().subscribe(res => {
      this.roles = res.content;
    })
    this.utilityService.listCountry().subscribe(res => {
      this.countries = res.content;
    })
    this.utilityService.listLang().subscribe(res => {
      this.langs = res.content;
    })
    this.utilityService.listZone().subscribe(res => {
      this.zones = res.content;
    })
    this.serviceLocationService.list().subscribe(res => {
      this.areaList = res.content;
    })
    this.getById();
  }

  getById() {
    this.adminService.getById(this.id).subscribe(res => {
      debugger
      if (res.isOK) {
        this.registerForm = this.formBuilder.group({
          firstname: [res.content.firstname, Validators.required],
          lastname: ['', Validators.required],
          rolename: ['', Validators.required],
          areaname: ['', Validators.required],
          email: ['', [Validators.required, Validators.email]],
          phonenumber: ['', Validators.required],
          Emerphonenumber: ['', Validators.required],
          Postalcode: ['', Validators.required, Validators.minLength(6)],
          Country: ['', Validators.required],
          Address: ['', Validators.required],
          TimeZone: ['', Validators.required],
          languagename: ['', Validators.required],
          confirmPassword: ['', Validators.required],
          profilePicture: ['', Validators.required],
          documentName: ['', Validators.required],
          document: ['', Validators.required]
        });
      }
    })
  }
  ErrorMessage
  fileToUpload: File = null;

  handleFileInput(files: FileList) {
    var regex = new RegExp("(.*?)\.(docx|doc|pdf|xml|bmp|ppt|xls)$");
    this.fileToUpload = files.item(0);
    if (!(regex.test(this.fileToUpload[0]))) {

    }
  }
  numberOnly(event): boolean {

    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;

  }





  get f() { return this.registerForm.controls; }

  onSubmit() {
    this.submitted = true;
   
    var modalUser = {
      firstname: this.registerForm.controls.firstname.value,
      lastname: this.registerForm.controls.lastname.value,
      email: this.registerForm.controls.email.value,
      phonenumber: this.registerForm.controls.phonenumber.value,
      emerphonenumber: this.registerForm.controls.Emerphonenumber.value,
      postalcode: this.registerForm.controls.Postalcode.value,
      country: this.registerForm.controls.Country.value,
      address: this.registerForm.controls.Address.value,      
      roleId: this.registerForm.controls.rolename.value,
      timeZone: this.registerForm.controls.TimeZone.value,
      area: this.registerForm.controls.areaname.value,
      languagename: this.registerForm.controls.languagename.value,
      profilePicture: "document",
      documentName: this.registerForm.controls.documentName.value,
      document: "document",
      id:this.id
    }
    this.adminService.edit(modalUser,this.id).subscribe(res => {
      if (res.isOK) {
        this.router.navigate(['manageadmin']);
      }else
      {
        this.snackBar.open(res.message, 'Fechar', {
          duration: 2000,
          panelClass: ['close-snackbar']
        });
      }

    })



  }

  dropChange(evt, role) {

  }
  cancel() {
    this.router.navigate(['manageadmin']);
  }

}
