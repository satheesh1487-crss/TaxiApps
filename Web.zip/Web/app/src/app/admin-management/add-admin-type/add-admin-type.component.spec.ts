import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddAdminTypeComponent } from './add-admin-type.component';

describe('AddAdminTypeComponent', () => {
  let component: AddAdminTypeComponent;
  let fixture: ComponentFixture<AddAdminTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddAdminTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddAdminTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
