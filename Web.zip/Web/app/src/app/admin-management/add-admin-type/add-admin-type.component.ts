import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms'; 
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { RoleService } from 'src/app/common/services/role.service';

@Component({
  selector: 'app-add-admin-type',
  templateUrl: './add-admin-type.component.html',
  styleUrls: ['./add-admin-type.component.scss']
})
export class AddAdminTypeComponent implements OnInit {
  authService: any; 
  submitted = false;
  constructor(private formBuilder: FormBuilder,
    private router:Router,
    private snackBar: MatSnackBar,
    public roleService:RoleService) { }
  registerForm:FormGroup;
  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      Typename: ['', Validators.required],
      Displayname: ['', Validators.required],
      Description: ['', Validators.required]
    });
  }
  //ErrorMessage

  get f() { return this.registerForm.controls; }

  onSubmit() {
    this.submitted = true;
 
    if (!this.registerForm.valid) {
        return;
    }

    var body ={
      roleName: this.registerForm.controls.Typename.value,
      displayName:this.registerForm.controls.Displayname.value,
      description:this.registerForm.controls.Description.value
      }

      this.roleService.save(body).subscribe(res=>{
         if(res.isOK){
          this.router.navigate(['manage-role']);
        }
        else
      {
        this.snackBar.open(res.message, 'Fechar', {
          duration: 2000,
          panelClass: ['close-snackbar']
        });
      }
      });
  }
  cancel()
  {
    this.router.navigate(['manage-role']);
  }
}
