import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms'; 
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { RoleService } from 'src/app/common/services/role.service';


export interface Role {
  DisplayName: string;
  description: string;
  isActive: boolean;
  roleID: string;
  roleName: string;
}
@Component({
  selector: 'app-edit-role',
  templateUrl: './edit-role.component.html',
  styleUrls: ['./edit-role.component.scss']
})
export class EditRoleComponent implements OnInit {
  authService: any;
  
  registerForm: FormGroup;
    submitted = false;
    id:number;
    modelRole:any={};
  constructor(private formBuilder: FormBuilder,
    private roleService:RoleService,
    private route:ActivatedRoute, 
    private snackBar: MatSnackBar,
    private router:Router) { }
   
  ngOnInit(): void {
     this.route
      .queryParams
      .subscribe(params => {
        // Defaults to 0 if no query param provided.
        this.id = Number(params['id']);
      });

    this.registerForm = this.formBuilder.group({
      Typename: ['', Validators.required],
      Displayname: ['', Validators.required],
      Description: ['', Validators.required]
  });
  this.roleService.getById(this.id).subscribe(res=>      
    {       
      if(res.isOK){       
        this.modelRole = res.content;
        this.registerForm = this.formBuilder.group({
          Typename: [this.modelRole.roleName, Validators.required],
          Displayname: [this.modelRole.DisplayName, Validators.required],
          Description: [this.modelRole.description, Validators.required]
      });
      }
    }); 
  }
 
 get f() { return this.registerForm.controls; }
ErrorMsg;
  onSubmit() {
    this.submitted = true;
    if (!this.registerForm.valid) {
        return;
    }

    
    var body ={   
      roleID:this.id,  
      roleName: this.registerForm.controls.Typename.value,
      displayName:this.registerForm.controls.Displayname.value,
      description:this.registerForm.controls.Description.value
      }

      this.roleService.edit(body,this.id).subscribe(res=>{
        console.log(res);
        
        if(res.isOK){
          this.router.navigate(['manage-role']);
        }
        else
      {
        this.snackBar.open(res.message, 'Fechar', {
          duration: 2000,
          panelClass: ['close-snackbar']
        });
      }
      });
  }
  cancel()
  {
    this.router.navigate(['manage-role']);
  }
}
