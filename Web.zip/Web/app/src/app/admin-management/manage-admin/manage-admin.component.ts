import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router'; 
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog'; 
import { AdminService } from 'src/app/common/services/admin.service';
import { RoleService } from 'src/app/common/services/role.service';
import { ConfirmDialogComponent } from 'src/app/confirm-dialog/confirm-dialog.component';
import * as XLSX from 'xlsx';
import * as FileSaver from 'file-saver';
import { ExcelService } from 'src/app/common/services/export.service';

@Component({
  selector: 'app-manage-admin',
  templateUrl: './manage-admin.component.html',
  styleUrls: ['./manage-admin.component.scss']
})
export class ManageAdminComponent implements OnInit {
  displayedColumns: string[] = ['no', 'name', 'rgcode', 'email','phoneno','role','status','operations','action'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  roles: any=[];

  adminList=[];

   EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
 EXCEL_EXTENSION = '.xlsx';   
  constructor(public adminService:AdminService,
    public roleService:RoleService,
    public router:Router,
    public exportService:ExcelService,
    private dialog: MatDialog,
    private snackBar: MatSnackBar) { }
  
  ngOnInit(): void {
    this.fillAdmin();
    this.roleService.listRole().subscribe(res=>      
      {         
        this.roles = res.content; 
      })
      }

fillAdmin(){
    this.adminService.list().subscribe(res=>      
      { 
        this.adminList =res.content
        this.dataSource = new MatTableDataSource(res.content);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      })
   
  }
  ngAfterViewInit() { 
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  redirectEdit(id)
  {
    this.router.navigate(['edit-admin'], { queryParams: { id: id } });
  } 

  redirectEditPwd(id)
  {
    this.router.navigate(['edit-password'], { queryParams: { id: id } });
  } 

  delete(id) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent,{
      data:{
        message: 'Are you sure want to delete?',
        buttonText: {
          primarybtn: 'Confirm',
          cancelbtn: 'Cancel'
        }
      }
    });
    
    dialogRef.afterClosed().subscribe((confirmed) => {
      
      if (confirmed.isOk) {       
        this.adminService.delete(id).subscribe(res=>{
          if(res.isOK){
            this.snackBar.open(res.message, 'Fechar', {
              duration: 200000,
              panelClass: ['delete-snackbar']
            });
            this.fillAdmin();
          }
        })
        
      }
    });
  }

  updateStatus(id,status) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent,{
      data:{
        message: 'Are you sure want to change the status?',
        buttonText: {
          primarybtn: 'Confirm',
          cancelbtn: 'Cancel'
        }
      }
    });
    
    dialogRef.afterClosed().subscribe((confirmed) => {
      
      if (confirmed.isOk) {
        this.adminService.status(id,status).subscribe(res=>{
          if(res.isOK){
            this.snackBar.open(res.message, 'Fechar', {
              duration: 2000,
              panelClass: ['close-snackbar']
            });
            this.fillAdmin();
          }
        })
        
      }
    });
  }

  exportexcel():void {
    this.exportService.exportAsExcelFile(this.adminList, 'Admin');
 }
}
