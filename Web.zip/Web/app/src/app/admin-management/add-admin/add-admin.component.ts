import { Component, OnInit, HostListener, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MustMatch } from '../../common/utility/common.validator';
import { UtilityService } from '../../common/services/utility.service';
import { RoleService } from '../../common/services/role.service';
import { ServiceLocationService } from '../../common/services/servicelocation.service';
import { AdminService } from '../../common/services/admin.service';
import { ZoneService } from '../../common/services/zone.service';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-add-admin',
  templateUrl: './add-admin.component.html',
  styleUrls: ['./add-admin.component.scss']
})
export class AddAdminComponent implements OnInit {

  submitted = false;
  langs: any;
  roles: any;
  zones: any;
  areaVal
  roleVal = '';
  CountryVal = '';
  languageVal = '';
  TimeZoneVal = '';
  areaList: any;
  constructor(private formBuilder: FormBuilder,
    private utilityService: UtilityService,
    private adminService: AdminService,
    private utilityServcice: UtilityService,
    public router: Router,
    private snackBar: MatSnackBar,
    private serviceLocationService: ServiceLocationService,
    public roleService: RoleService) { }
  registerForm: FormGroup;
  countries
  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      firstname: ['', Validators.required],
      lastname: ['', Validators.required],
      rolename: ['', Validators.required],
      areaname: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phonenumber: ['', Validators.required],
      Emerphonenumber: ['', Validators.required],
      Postalcode: ['', Validators.required, Validators.minLength(6)],
      Country: ['', Validators.required],
      Address: ['', Validators.required],
      TimeZone: ['', Validators.required],
      languagename: ['', Validators.required],
      userlogin: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]],
      confirmPassword: ['', Validators.required],
      profilePicture: [''],
    }, {
      validator: MustMatch('password', 'confirmPassword')
    });


    this.roleService.listRole().subscribe(res => {
      this.roles = res.content;
    })

    this.utilityService.listLang().subscribe(res => {
      this.langs = res.content;
    })
    this.fillcountry();

  }
  fillZone() {
    this.utilityService.listZone().subscribe(res => {
      this.zones = res.content;
    })
  }
  fillServiceLocation() {
    this.serviceLocationService.list().subscribe(res => {
      this.areaList = res.content;
    })
  }
  fillcountry() {
    this.utilityService.listCountry().subscribe(res => {
      this.countries = res.content;
    })
  }
  ErrorMessage
  fileToUpload: File = null;

  handleFileInput(files: FileList) {
    var regex = new RegExp("(.*?)\.(docx|doc|pdf|xml|bmp|ppt|xls)$");
    this.fileToUpload = files.item(0);
    if (!(regex.test(this.fileToUpload[0]))) {

    }
  }
  numberOnly(event): boolean {

    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;

  }


  dropChange(evt, role) {
    if (evt != "") {
      this.utilityServcice.getZoneBycountryId(evt).subscribe(res => {
        this.zones = res.content;
      });

      this.serviceLocationService.countryByservicelocId(evt).subscribe(res => {
        this.areaList = res.content;
      });
    }
    
  }


  get f() { return this.registerForm.controls; }

  onSubmit() {
    this.submitted = true;
    

   /* if (!this.registerForm.valid) {
      return;
    }*/
    var modalUser = {
      firstname: this.registerForm.controls.firstname.value,
      lastname: this.registerForm.controls.lastname.value,
      email: this.registerForm.controls.email.value,
      phonenumber: this.registerForm.controls.phonenumber.value,
      emerphonenumber: this.registerForm.controls.Emerphonenumber.value,
      postalcode: this.registerForm.controls.Postalcode.value,
      country: this.registerForm.controls.Country.value,
      address: this.registerForm.controls.Address.value,
      userlogin: this.registerForm.controls.userlogin.value,
      password: this.registerForm.controls.password.value,
      roleId: this.registerForm.controls.rolename.value,
      timeZone: this.registerForm.controls.TimeZone.value,
      area: this.registerForm.controls.areaname.value,
      languagename: this.registerForm.controls.languagename.value,
      profilePicture: "document",
     
    }
    this.adminService.save(modalUser).subscribe(res => {
      if (res.isOK) {
        this.router.navigate(['manageadmin']);
      }else{
     
        this.snackBar.open(res.message, 'Fechar', {
          duration: 2000,
          panelClass: ['close-snackbar']
        });
      }
    });
  }


  cancel() {
    this.router.navigate(['manageadmin']);
  }

}
