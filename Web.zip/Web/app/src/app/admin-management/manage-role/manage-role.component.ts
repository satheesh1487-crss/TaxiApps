import { Component, OnInit, ViewChild } from '@angular/core';

import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort'; 
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';

import { Router } from '@angular/router';
import { RoleService } from 'src/app/common/services/role.service';
import { ConfirmDialogComponent } from 'src/app/confirm-dialog/confirm-dialog.component';
import { ExcelService } from 'src/app/common/services/export.service';

@Component({
  selector: 'app-manage-role',
  templateUrl: './manage-role.component.html',
  styleUrls: ['./manage-role.component.scss']
})
export class ManageRoleComponent implements OnInit {
  displayedColumns: string[] = ['no', 'roleName', 'displayName', 'description','action'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  result: any;
  roleList=[];
  constructor(public roleService:RoleService, 
    public router:Router,
    private dialog: MatDialog,
    public exportService:ExcelService,
    private snackBar: MatSnackBar)  { }
  

  ngOnInit(): void {
    this.roleService.listRole().subscribe(res=>      
      { 
        this.roleList =res.content
        this.dataSource = new MatTableDataSource(res.content);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      })
  }
  ngAfterViewInit() { 
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  redirectEdit(id)
  {    
    this.router.navigate(['edit-role'], { queryParams: { id: id } });
  } 
  openDialog() {
    const dialogRef = this.dialog.open(ConfirmDialogComponent,{
      data:{
        message: 'Are you sure want to delete?',
        buttonText: {
          primarybtn: 'Confirm',
          cancelbtn: 'Cancel'
        }
      }
    });
   
    dialogRef.afterClosed().subscribe((confirmed) => {
      if (confirmed.isOk) {
       
        this.snackBar.open('', 'Fechar', {
          duration: 2000,
          panelClass: ['delete-snackbar']
        });
      }
    });
  }
  exportexcel():void {
    this.exportService.exportAsExcelFile(this.roleList, 'Role');
 }
}
