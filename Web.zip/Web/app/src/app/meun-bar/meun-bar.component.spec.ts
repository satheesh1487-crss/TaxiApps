import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MeunBarComponent } from './meun-bar.component';

describe('MeunBarComponent', () => {
  let component: MeunBarComponent;
  let fixture: ComponentFixture<MeunBarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MeunBarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MeunBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
