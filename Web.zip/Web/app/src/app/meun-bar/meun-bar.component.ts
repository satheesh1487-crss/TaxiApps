import { Component, OnInit, AfterViewInit  } from '@angular/core';
import { PermissionService } from '../common/services/permission.service';
declare var $:any;

@Component({
  selector: 'app-meun-bar',
  templateUrl: './meun-bar.component.html',
  styleUrls: ['./meun-bar.component.scss']
})
export class MeunBarComponent implements OnInit {   
  ngAfterViewInit(){
    $(document).ready(function(){
      $('.scrollbar-inner').scrollbar();
    });
}

isPermission(key){
 
      const isAPermissionAvailable = this.permissionService.checkPermission(key);      
        return isAPermissionAvailable ? true :false;
      // return  this.permissionService.checkPermission('ARO');
 
    }
  
  constructor(private permissionService :PermissionService) { }

  ngOnInit(): void {
     
  }

  showTab = 0;
  toggle(index){
    this.showTab =index;
  }

 
}
