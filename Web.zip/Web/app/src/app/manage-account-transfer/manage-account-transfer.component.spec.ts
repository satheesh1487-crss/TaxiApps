import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageAccountTransferComponent } from './manage-account-transfer.component';

describe('ManageAccountTransferComponent', () => {
  let component: ManageAccountTransferComponent;
  let fixture: ComponentFixture<ManageAccountTransferComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageAccountTransferComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageAccountTransferComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
