import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-account-transfer',
  templateUrl: './manage-account-transfer.component.html',
  styleUrls: ['./manage-account-transfer.component.scss']
})
export class ManageAccountTransferComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
