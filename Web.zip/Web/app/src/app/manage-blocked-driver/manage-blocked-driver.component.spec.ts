import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageBlockedDriverComponent } from './manage-blocked-driver.component';

describe('ManageBlockedDriverComponent', () => {
  let component: ManageBlockedDriverComponent;
  let fixture: ComponentFixture<ManageBlockedDriverComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageBlockedDriverComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageBlockedDriverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
