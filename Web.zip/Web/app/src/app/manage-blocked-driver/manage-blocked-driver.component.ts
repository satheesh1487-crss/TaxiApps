import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { DriverService } from '../common/services/driver.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { ExcelService } from '../common/services/export.service';

@Component({
  selector: 'app-manage-blocked-driver',
  templateUrl: './manage-blocked-driver.component.html',
  styleUrls: ['./manage-blocked-driver.component.scss']
})
export class ManageBlockedDriverComponent implements OnInit {
  displayedColumns: string[] = ['no', 'registrationcode', 'name', 'email', 'phonenumber', 'rating', 'blockedstatus', 'status','action'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  result: any;
  blockedDriver=[];
  constructor(public driverService:DriverService, public exportService:ExcelService,public router:Router,private dialog: MatDialog,
  private snackBar: MatSnackBar) {}
  

  ngOnInit(): void {
    this.fillDriver();
  }
  fillDriver(){
    this.driverService.listBlockDriver().subscribe(res=>      
      { 
        this.blockedDriver =res.content
        this.dataSource = new MatTableDataSource(res.content);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      })
  }
  ngAfterViewInit() { 
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }
  
  openDialog(id,status) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent,{
      data:{
        message: 'Are you sure want to Change Status?',
        buttonText: {
          primarybtn: 'Confirm',
          cancelbtn: 'Cancel'
        }
      }
    });
    
    dialogRef.afterClosed().subscribe((confirmed) => {
      if (confirmed) {
        this.driverService.statusDriver(id,status).subscribe(res=>{
          if(res.isOK)
          {
            this.fillDriver();
        this.snackBar.open(res.message, 'Fechar', {
          duration: 2000,
          panelClass: ['close-snackbar']
        });
      }
    })
      }
    });
  }
  exportexcel():void {
    this.exportService.exportAsExcelFile(this.blockedDriver, 'BlockedDriver');
 }
}
