import { Component, OnInit } from '@angular/core';
declare var $:any;

@Component({
  selector: 'app-manage-sms',
  templateUrl: './manage-sms.component.html',
  styleUrls: ['./manage-sms.component.scss']
})
export class ManageSmsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    $(document).ready(function() {
      $('#multiple-checkboxes').multiselect({
        includeSelectAllOption: true,
      });
      $('#multiple-checkboxes1').multiselect({
        includeSelectAllOption: true,
      });
  });
  }

}
