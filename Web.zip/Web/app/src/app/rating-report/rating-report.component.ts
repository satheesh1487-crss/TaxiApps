import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rating-report',
  templateUrl: './rating-report.component.html',
  styleUrls: ['./rating-report.component.scss']
})
export class RatingReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
