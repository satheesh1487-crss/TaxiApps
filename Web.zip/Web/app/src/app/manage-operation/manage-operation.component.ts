import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { ZoneService } from '../common/services/zone.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-manage-operation',
  templateUrl: './manage-operation.component.html',
  styleUrls: ['./manage-operation.component.scss']
})
export class ManageOperationComponent implements OnInit {
  displayedColumns: string[] = ['no', 'zonename', 'status','action'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  result: any;
  
  constructor(public zoneService:ZoneService, public router:Router,private dialog: MatDialog,
    private snackBar: MatSnackBar) {}
  

  ngOnInit(): void {
    this.zoneService.listZone().subscribe(res=>      
      {       
        this.dataSource = new MatTableDataSource(res.content);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      })
  }
  ngAfterViewInit() { 
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  redirectEdit(id)
  {   
     
     this.router.navigate(['zone-type-view'], { queryParams: { zoneId: id } });
  } 
  openDialog() {
    const dialogRef = this.dialog.open(ConfirmDialogComponent,{
      data:{
        message: 'Are you sure want to delete?',
        buttonText: {
          ok: 'Save',
          cancel: 'No'
        }
      }
    });
   
    dialogRef.afterClosed().subscribe((confirmed) => {
      if (confirmed.isOk) {
      
        this.snackBar.open('Closing snack bar in a few seconds', 'Fechar', {
          duration: 2000,
          panelClass: ['delete-snackbar']
        });
      }
    });
  }
}
