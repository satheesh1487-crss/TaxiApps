import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ZoneSettingsComponent } from './zone-settings.component';

describe('ZoneSettingsComponent', () => {
  let component: ZoneSettingsComponent;
  let fixture: ComponentFixture<ZoneSettingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ZoneSettingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ZoneSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
