import { Component, OnInit } from '@angular/core'; 
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../common/auth/auth.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-zone-settings',
  templateUrl: './zone-settings.component.html',
  styleUrls: ['./zone-settings.component.scss']
})
export class ZoneSettingsComponent implements OnInit {
  authService: any;
  isSubmitted=false;
  constructor(private formBuilder: FormBuilder,
     private router: Router) { }
  registerForm:FormGroup;
  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      areaname:['',Validators.required],
      currencytype:['',Validators.required],
      unittype:['',Validators.required]
    });
    
  }

  ErrorMessage

  areaVal ='';
  currencyVal ='';
  unitVal ='';

dropChange(evt,role){

  switch(role){
    case "area":
      this.areaVal=evt.srcElement.value;
      break;
      case "currency":
        this.currencyVal=evt.srcElement.value;
      break;
      case "unit":
        this.unitVal=evt.srcElement.value;
      break;
    }
}

  onSubmit(){ 
    this.isSubmitted = true;

    // stop here if form is invalid
    if (this.registerForm.invalid) {
        return;
    }
  }

  get f() {
    
    return this.registerForm.controls;
  }

  // City Names
  City: any = ['Florida', 'South Dakota', 'Tennessee', 'Michigan']


  cancel(){
    this.router.navigate(['manage-zone']);
  } 
}
