import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DriverComplaintComponent } from './driver-complaint.component';

describe('DriverComplaintComponent', () => {
  let component: DriverComplaintComponent;
  let fixture: ComponentFixture<DriverComplaintComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DriverComplaintComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DriverComplaintComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
