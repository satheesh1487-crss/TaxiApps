import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SetPrivillageComponent } from './set-privillage.component';

describe('SetPrivillageComponent', () => {
  let component: SetPrivillageComponent;
  let fixture: ComponentFixture<SetPrivillageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SetPrivillageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SetPrivillageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
