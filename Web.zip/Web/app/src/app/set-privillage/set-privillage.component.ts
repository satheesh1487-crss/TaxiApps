import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatTreeFlatDataSource, MatTreeFlattener } from '@angular/material/tree';
import { FlatTreeControl } from '@angular/cdk/tree';
import { RoleService } from '../common/services/role.service';



interface FoodNode {
  menuid: number,
  name: string;
  viewstate: boolean
  children?: FoodNode[];
}

const TREE_DATAUSER: FoodNode[] = [{ name: "Dashboard", menuid: 1, viewstate: false, children: [] },
{
  name: "Admin Management", menuid: 2, viewstate: false,
  children: [{
    name: "Manage Admin", menuid: 3, viewstate: false,
    children: [{ name: "Add Admin", menuid: 4, viewstate: false },
    { name: "Edit", menuid: 5, viewstate: false },
    { name: "Delete", menuid: 6, viewstate: false },
    { name: "Admin Status Modify", menuid: 7, viewstate: false }]
  },
  {
    name: "Manage Role", menuid: 8, viewstate: false,
    children: [{ name: "Add Role", menuid: 9, viewstate: false },
    { name: "Edit", menuid: 10, viewstate: false },
    { name: "Set privilege", menuid: 11, viewstate: false }]
  }]
},
{
  name: "User Management", menuid: 12, viewstate: false,
  children: [{
    name: " Manage User", menuid: 13, viewstate: false,
    children: [{ name: "Add User", menuid: 14, viewstate: false },
    { name: "Edit", menuid: 15, viewstate: false },
    { name: "Delete", menuid: 16, viewstate: false },
    { name: "Wallet", menuid: 17, viewstate: false }]
  },
  {
    name: "Blocked User", menuid: 18, viewstate: false,
    children: [{ name: "Modify User Status", menuid: 19, viewstate: false }]
  }]
},
{
  name: "Driver Management", menuid: 20, viewstate: false,
  children: [{
    name: "Manage Driver", menuid: 21, viewstate: false,
    children: [{ name: "Add Driver", menuid: 22, viewstate: false },
    { name: "Upload Drivers", menuid: 23, viewstate: false },
    { name: "Edit", menuid: 24, viewstate: false },
    { name: "Delete", menuid: 25, viewstate: false },
    { name: "Edit Reward Point", menuid: 26, viewstate: false },
    { name: "Modify Driver Status", menuid: 27, viewstate: false }]
  },
  {
    name: "Manage Wallet Payment", menuid: 28, viewstate: false,
    children: [{ name: "Wallet", menuid: 29, viewstate: false },
    { name: "Add Money", menuid: 30, viewstate: false }]
  },
  {
    name: "Manage Account Payment", menuid: 31, viewstate: false,
    children: [{ name: "Add account", menuid: 32, viewstate: false },
    { name: "Transfer", menuid: 33, viewstate: false }]
  },
  {
    name: "Manage Earning Payment", menuid: 34, viewstate: false,
    children: [{ name: "Earnings", menuid: 35, viewstate: false },
    { name: "Savings", menuid: 36, viewstate: false },
    { name: "Cancellation balance", menuid: 37, viewstate: false }]
  },
  {
    name: "Manage Fine", menuid: 38, viewstate: false,
    children: [{ name: "Add Fine", menuid: 39, viewstate: false },
    { name: "Edit", menuid: 40, viewstate: false },
    { name: "Delete", menuid: 41, viewstate: false },
    { name: "Pay Fine", menuid: 42, viewstate: false }]
  },
  {
    name: "Manage Bonus", menuid: 43, viewstate: false,
    children: [{ name: "Add Bonus", menuid: 44, viewstate: false }]
  },
  {
    name: "Blocked Driver", menuid: 45, viewstate: false,
    children: [{ name: "Approve", menuid: 46, viewstate: false }]
  }]
}, {
  name: "Zone Management", menuid: 47, viewstate: false,
  children: [{
    name: "Manage Zone", menuid: 48, viewstate: false,
    children: [{ name: "Add Zone", menuid: 49, viewstate: false },
    { name: "Edit Zone", menuid: 50, viewstate: false },
    { name: "Map View", menuid: 51, viewstate: false },
    { name: "Delete", menuid: 52, viewstate: false },
    { name: "Modify Zone Status", menuid: 53, viewstate: false }]
  }, {
    name: "Manage Operation", menuid: 54, viewstate: false,
    children: [{ name: "Add type", menuid: 55, viewstate: false },
    { name: "Zone Setting", menuid: 56, viewstate: false }]
  }]
}]
const TREE_DATA: FoodNode[] = [
  {
    menuid: 1,
    name: 'Fruit',
    viewstate: true,
    children: [
      { name: 'Apple', menuid: 2, viewstate: true },
      { name: 'Banana', menuid: 3, viewstate: true },
      { name: 'Fruit loops', menuid: 4, viewstate: true },
    ]
  }, {
    menuid: 5,
    name: 'Vegetables',
    viewstate: true,
    children: [
      {
        menuid: 6,
        name: 'Green',
        viewstate: true,
        children: [
          { name: 'Broccoli', menuid: 7, viewstate: true },
          { name: 'Brussels sprouts', menuid: 8, viewstate: true },
        ],

      }, {
        menuid: 9,
        viewstate: true,
        name: 'Orange',
        children: [
          { name: 'Pumpkins', menuid: 10, viewstate: false },
          { name: 'Carrots', menuid: 11, viewstate: true },
        ]
      },
    ]
  },
];

/** Flat node with expandable and level information */
interface ExampleFlatNode {
  expandable: boolean;
  name: string;
  level: number;
  viewstate: boolean,
}



@Component({
  selector: 'app-set-privillage',
  templateUrl: './set-privillage.component.html',
  styleUrls: ['./set-privillage.component.scss']
})
export class SetPrivillageComponent implements OnInit {
  private _transformer = (node: FoodNode, level: number) => {

    return {

      expandable: !!node.children && node.children.length > 0,
      name: node.name,
      level: level,
      viewstate: node.viewstate,
    };
  }

  treeControl = new FlatTreeControl<ExampleFlatNode>(
    node => node.level, node => node.expandable);

  treeFlattener = new MatTreeFlattener(
    this._transformer, node => node.level, node => node.expandable, node => node.children);

  dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);

  constructor(private roleService: RoleService) {
    this.dataSource.data = TREE_DATAUSER;
    this.roleService.listPrivillage(2).subscribe(res => {
      // this.dataSource.data =res.content;
    })
  }



  ngOnInit(): void {
    throw new Error("Method not implemented.");
  }

  hasChild = (_: number, node: ExampleFlatNode) => node.expandable;
}
