import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DriverReferralComponent } from './driver-referral.component';

describe('DriverReferralComponent', () => {
  let component: DriverReferralComponent;
  let fixture: ComponentFixture<DriverReferralComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DriverReferralComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DriverReferralComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
