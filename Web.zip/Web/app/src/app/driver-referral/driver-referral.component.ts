import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { ReferralService } from '../common/services/referral.service';


@Component({
  selector: 'app-driver-referral',
  templateUrl: './driver-referral.component.html',
  styleUrls: ['./driver-referral.component.scss']
})
export class DriverReferralComponent implements OnInit {
  displayedColumns: string[] = ['no', 'referralCode', 'userName','amountearned'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  result: any;
  
  constructor(public referralService:ReferralService, public router:Router) { }
  

  ngOnInit(): void {
    this.referralService.listUserRefferal().subscribe(res=>      
      { 
        console.log(res)
        this.dataSource = new MatTableDataSource(res.content);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      })
  }
  ngAfterViewInit() { 
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  redirectEdit(id)
  {
    console.log('Edit RollId?=Id' +id);
    //this.router.navigate(['edit-role'], { queryParams: { id: id } });
  } 
}
