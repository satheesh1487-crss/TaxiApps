import { Component, OnInit, NgZone, ElementRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MapsAPILoader, } from '@agm/core';
import { CurrencyService } from '../common/services/currency.service';
import { ServiceLocationService } from '../common/services/servicelocation.service';
import { ZoneService } from '../common/services/zone.service';
import { Router, ActivatedRoute } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
declare const google: any;

@Component({
  selector: 'app-add-zone',
  templateUrl: './add-zone.component.html',
  styleUrls: ['./add-zone.component.scss']
})
export class AddZoneComponent implements OnInit {
  authService: any; 
  isSubmitted = false;
  lat = 20.5937;
  lng = 78.9629;
  pointList: { latitude: number; longtitude: number }[] = [];
  drawingManager: any;
  selectedShape: any;
  selectedArea = 0;
  private geoCoder;
  latitude: number;
  longitude: number;
  zoom: number;
  address: string;
  @ViewChild('search')
  public searchElementRef: ElementRef;
  ErrorMessage
  areaVal = '';
  currencyVal = '';
  unitVal = '';
  currencylist = [];
  registerForm: FormGroup;
  arealist: any;

  constructor(private formBuilder: FormBuilder,
    private mapsAPILoader: MapsAPILoader,
    private router: Router,
    private snackBar: MatSnackBar,
    public currencyService: CurrencyService,
    public zoneService: ZoneService,
    private route: ActivatedRoute,
    public serviceLocationService: ServiceLocationService,
    private ngZone: NgZone) { }

  ngOnInit(): void {
    this.getCurrency();
    this.registerForm = this.formBuilder.group({
      areaname: ['', Validators.required],     
      unittype: ['', Validators.required],
      zonename: ['', Validators.required],
      SearchLocation: ['', Validators.required]
    });
    //load Places Autocomplete
    this.mapsAPILoader.load().then(() => {

      this.setCurrentPosition();
      this.geoCoder = new google.maps.Geocoder;

      let autocomplete = new google.maps.places.Autocomplete(this.searchElementRef.nativeElement);
      autocomplete.addListener("place_changed", () => {
        this.ngZone.run(() => {
          //get the place result
          let place: google.maps.places.PlaceResult = autocomplete.getPlace();

          //verify result
          if (place.geometry === undefined || place.geometry === null) {
            return;
          }

          //set latitude, longitude and zoom
          this.latitude = place.geometry.location.lat();
          this.longitude = place.geometry.location.lng();
          this.zoom = 12;
        });
      });
    });

  }


  dropChange(evt, role) {

    switch (role) {
      case "area":
        this.areaVal = evt.srcElement.value;
        break;
      case "currency":
        this.currencyVal = evt.srcElement.value;
        break;
      case "unit":
        this.unitVal = evt.srcElement.value;
        break;
    }
  }

  markerDragEnd($event: MouseEvent) {
      this.getAddress(this.latitude, this.longitude);
  }

  getAddress(latitude, longitude) {
    this.geoCoder.geocode({ 'location': { latitude: latitude, longtitude: longitude } }, (results, status) => {
      if (status === 'OK') {
        if (results[0]) {
          this.zoom = 12;
          this.address = results[0].formatted_address;
        } else {
          window.alert('No results found');
        }
      } else {
        window.alert('Geocoder failed due to: ' + status);
      }

    });
  }
  onSubmit() { 
    this.isSubmitted = true;
    if (!this.registerForm.valid) {
      return;
    }    

    var zone={
      zonePolygoneList:this.pointList,
      serviceslocid:this.registerForm.controls.areaname.value,     
      unit:this.registerForm.controls.unittype.value,
      zoneName:this.registerForm.controls.zonename.value,
      
    }
    this.zoneService.save(zone).subscribe(res=>{
      if(res.isOK){
        this.router.navigate(['manage-zone']);
      }
      else
      {
        this.snackBar.open(res.message, 'Fechar', {
          duration: 2000,
          panelClass: ['close-snackbar']
        });
      }
    });

  } 
  get f() {
    return this.registerForm.controls;
  } 





  onMapReady(map) {
    this.initDrawingManager(map);
  }

  initDrawingManager = (map: any) => {
    const self = this;
    const options = {
      drawingControl: true,
      drawingControlOptions: {
        drawingModes: ['polygon'],
      },
      polygonOptions: {
        draggable: true,
        editable: true,
      },
      drawingMode: google.maps.drawing.OverlayType.POLYGON,
    };
    this.drawingManager = new google.maps.drawing.DrawingManager(options);
    this.drawingManager.setMap(map);
    google.maps.event.addListener(
      this.drawingManager,
      'overlaycomplete',
      (event) => {
        if (event.type === google.maps.drawing.OverlayType.POLYGON) {
          const paths = event.overlay.getPaths();
          for (let p = 0; p < paths.getLength(); p++) {
            google.maps.event.addListener(
              paths.getAt(p),
              'set_at',
              () => {
                if (!event.overlay.drag) {
                  self.updatePointList(event.overlay.getPath());
                }
              }
            );
            google.maps.event.addListener(
              paths.getAt(p),
              'insert_at',
              () => {
                self.updatePointList(event.overlay.getPath());
              }
            );
            google.maps.event.addListener(
              paths.getAt(p),
              'remove_at',
              () => {
                self.updatePointList(event.overlay.getPath());
              }
            );
          }
          self.updatePointList(event.overlay.getPath());
        }
        if (event.type !== google.maps.drawing.OverlayType.MARKER) {
          // Switch back to non-drawing mode after drawing a shape.
          self.drawingManager.setDrawingMode(null);
          // To hide:
          self.drawingManager.setOptions({
            drawingControl: false,
          });

          // set selected shape object
          const newShape = event.overlay;
          newShape.type = event.type;
          this.setSelection(newShape);

        }
      }
    );
  }
  private setCurrentPosition() {

    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition((position) => {
        this.lat = position.coords.latitude;
        this.lng = position.coords.longitude;
      });
    }
  }
  clearSelection() {
    if (this.selectedShape) {
      this.selectedShape.setEditable(false);
      this.selectedShape = null;
      this.pointList = [];
    }
  }
  setSelection(shape) {
    this.clearSelection();
    this.selectedShape = shape;
    shape.setEditable(true);
  }

  deleteSelectedShape() {
    if (this.selectedShape) {
      this.selectedShape.setMap(null);
      this.selectedArea = 0;
      this.pointList = [];
      // To show:
      this.drawingManager.setOptions({
        drawingControl: true,
      });
    }
  }

  updatePointList(path) {
    this.pointList = [];
    const len = path.getLength();
    for (let i = 0; i < len; i++) {
      this.pointList.push(
        path.getAt(i).toJSON()
      );
    }
    this.selectedArea = google.maps.geometry.spherical.computeArea(
      path
    );
  }

  getCurrency() {
    this.currencyService.list().subscribe(res => {
      if (res.isOK) {
        this.currencylist = res.content;
      }
    });
    this.serviceLocationService.list().subscribe(res => {
      if (res.isOK) {
        this.arealist = res.content;
      }
    });
  }
  cancel(){
    this.router.navigate(['manage-zone']);
  } 
}
