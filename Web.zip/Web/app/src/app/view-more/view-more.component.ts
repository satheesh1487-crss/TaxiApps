import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { RequestService } from '../common/services/request.service';

@Component({
  selector: 'app-view-more',
  templateUrl: './view-more.component.html',
  styleUrls: ['./view-more.component.scss']
})
export class ViewMoreComponent implements OnInit {
  submitted
  id
  registerForm: FormGroup;
  constructor(private requestService: RequestService,
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    this.route
      .queryParams
      .subscribe(params => {
       this.id = Number(params['id']);
      });
      this.registerForm = this.formBuilder.group({
        type: ['', Validators.required],
        zone: ['', Validators.required],
        startTime: ['', Validators.required],
        driverRated: ['', Validators.required],
        userRated: ['', Validators.required],
        driverName: ['', Validators.required],
        driverEmail: ['', Validators.required],
        driverContactNo: ['', Validators.required]
      });

      this.getbyId();
  } 
  
  getbyId() {debugger
    this.requestService.getByRequestId(this.id).subscribe(res => {
      if (res.isOK) {                
        this.registerForm = this.formBuilder.group({         
          type: [res.content.type, Validators.required],
        zone: [res.content.zone, Validators.required],
        startTime: [res.content.startTime, Validators.required],
        driverRated: [res.content.driverRated, Validators.required],
        userRated: [res.content.userRated, Validators.required],
        driverName: [res.content.driverName, Validators.required],
        driverEmail: [res.content.driverEmail, Validators.required],
        driverContactNo: [res.content.driverContactNo, Validators.required],                 
        });      
      }
    })
  }
  get f() { return this.registerForm.controls; }
  /*onSubmit() {
    this.submitted = true;
   
    var requestModal = {
      type: this.registerForm.controls.type.value,
        zone: this.registerForm.controls.zone.value,
        startTime: this.registerForm.controls.startTime.value,
        driverRated: this.registerForm.controls.driverRated.value,
        userRated: this.registerForm.controls.userRated.value,
        driverName: this.registerForm.controls.driverName.value, 
        driverEmail: this.registerForm.controls.driverEmail.value,
        driverContactNo: this.registerForm.controls.driverContactNo.value,       
      Id: this.id 
    };
      this.requestService.editSms(smsModal,this.id).subscribe(res => {
      if (res.isOK) {
        this.router.navigate(['manage-sms-options']);
      }
    });
  }
  cancel(){
    this.router.navigate(['manage-sms-options']);
  }
  */
}
