import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../common/auth/auth.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MustMatch } from '../common/utility/common.validator';
import { UtilityService } from '../common/services/utility.service';
import { DriverService } from '../common/services/driver.service';
import { ServiceLocationService } from '../common/services/servicelocation.service';
import { ZoneService } from '../common/services/zone.service';
import { VehicleService } from '../common/services/vehicle.service';
import { MatSnackBar } from '@angular/material/snack-bar';


@Component({
  selector: 'app-add-driver',
  templateUrl: './add-driver.component.html',
  styleUrls: ['./add-driver.component.scss']
})
export class AddDriverComponent implements OnInit {
  filename
  submitted = false;
  langs: any;
  CountryVal =''; 
  TimeZoneVal ='';

  areaVal = '';
  currencyVal = '';
  unitVal = '';
    
  arealist: any;
  countries: any;
  driverType
  vechileType:any;
  zoneList: any;
  constructor(private router:Router,
    private authService:AuthService,
    private snackBar: MatSnackBar,
    private driverService:DriverService,
    private verchileService:VehicleService,
    private utilityService:UtilityService,
    private serviceLocationService:ServiceLocationService,
    private zoneService:ZoneService,
    private formBuilder: FormBuilder) { }
    registerForm:FormGroup;
  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      firstname: ['', Validators.required],
      lastname: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phonenumber: ['', Validators.required],
      Gender: ['', Validators.required],
      Address: ['', Validators.required],
      City: ['', Validators.required],
      State: ['', Validators.required],
      Country: ['', Validators.required],
      areaname:['',Validators.required],
      DriverArea: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(8)]],
      confirmPassword: ['', Validators.required],
      DriverType: ['', Validators.required],
      NationalID: ['', Validators.required],
      carModel: ['',Validators.required],
      carColour: ['',Validators.required],
      carNumber: ['',Validators.required],
      carManu: ['',Validators.required],
      carYear: ['',Validators.required],
      profilepicture:['']
    }, {
      validator: MustMatch('password', 'confirmPassword')
  });
  this.utilityService.listCountry().subscribe(res=>      
  {       
    this.countries = res.content; 
  });

  this.verchileService.listtype().subscribe(res=>      
    {           
      this.vechileType = res.content; 
    });
}
ErrorMessage
fileToUpload: File = null;

handleFileInput(files: FileList) {
   var regex = new RegExp("(.*?)\.(docx|doc|pdf|xml|bmp|ppt|xls)$");
  this.fileToUpload = files.item(0);
  if (!(regex.test(this.fileToUpload[0]))) {
    
  }
} 
  numberOnly(event): boolean {   
  const charCode = (event.which) ? event.which : event.keyCode;
  if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    return false;
  }
  return true;

}

  get f() { return this.registerForm.controls; }
 
  onSubmit() {
    this.submitted = true;    
    var driverModal={     
      firstName: this.registerForm.controls.firstname.value,
      lastName: this.registerForm.controls.lastname.value,
      email: this.registerForm.controls.email.value,
      contactNo: this.registerForm.controls.phonenumber.value,
      city: this.registerForm.controls.City.value,
      state: this.registerForm.controls.State.value,
      country: this.registerForm.controls.Country.value,
      driverArea: this.registerForm.controls.DriverArea.value,
      //driverType: this.registerForm.controls.DriverType.value,
      areaname:this.registerForm.controls.areaname.value,
      driverType: "1",
      gender: this.registerForm.controls.Gender.value,
      password: this.registerForm.controls.password.value,
      nationalId: this.registerForm.controls.NationalID.value,      
      address: this.registerForm.controls.Address.value,
      carModel: this.registerForm.controls.carModel.value,
      carColour: this.registerForm.controls.carColour.value,
      carNumber: this.registerForm.controls.carNumber.value,
      carManu: this.registerForm.controls.carManu.value,
      carYear: this.registerForm.controls.carYear.value,
      profilepicture:"document" 
  }; 
  this.driverService.saveDriver(driverModal).subscribe(res=>{
    if(res.isOK)
    {
     this.router.navigate(['manage-driver']);
    }
    else
      {
        this.snackBar.open(res.message, 'Fechar', {
          duration: 2000,
          panelClass: ['close-snackbar']
        });
      }
  })
  }
  onChange(event){
    this.zoneService.serviceBasedZone(event.srcElement.value).subscribe(res=>      
      {           
        this.zoneList = res.content; 
      }); 
  }

  onArea(event){ 
    this.serviceLocationService.countryByservicelocId(event.srcElement.value).subscribe(res=>      
      {           
        this.arealist = res.content; 
      });
  }
  
  cancel(){
    this.router.navigate(['manage-driver']);
  }
}
