import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router'; 
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog'; 
import { ServiceLocationService } from 'src/app/common/services/servicelocation.service';
import { ConfirmDialogComponent } from 'src/app/confirm-dialog/confirm-dialog.component';
import { ExcelService } from '../common/services/export.service';
import { NotificationService } from '../common/services/notification.service';


@Component({
  selector: 'app-manage-email',
  templateUrl: './manage-email.component.html',
  styleUrls: ['./manage-email.component.scss']
})
export class ManageEmailComponent implements OnInit {
  displayedColumns: string[] = ['no', 'emailtitle', 'description','status','action'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  result: any;
  serviceLocation=[];
  constructor(public notificationService:NotificationService,
     public router:Router,
     private dialog: MatDialog,
    private snackBar: MatSnackBar) { }
  

  ngOnInit(): void {
    this.fillEmail();  
  }
  fillEmail(){
    this.notificationService.listEmail().subscribe(res=>      
      {        
        this.dataSource = new MatTableDataSource(res.content);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      });
  }
  ngAfterViewInit() { 
  }

  applyFilter(filterValue: string) {    
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  redirectEdit(id)
  {
   
  this.router.navigate(['edit-email'], { queryParams: { id: id } });
  } 
  updateStatus(id,status) {
    
    const dialogRef = this.dialog.open(ConfirmDialogComponent,{
      data:{
        message: 'Are you sure want to change the status?',
        buttonText: {
          primarybtn: 'Confirm',
          cancelbtn: 'Cancel'
        }
      }
    });
    
    dialogRef.afterClosed().subscribe((confirmed) => {
      
      if (confirmed.isOk) {
        this.notificationService.statusEmail(id,status).subscribe(res=>{
          if(res.isOK){
            this.snackBar.open(res.message, 'Fechar', {
              duration: 2000,
              panelClass: ['close-snackbar']
            });
            this.fillEmail(); 
          }
        })
        
      }
    });
  }
}
