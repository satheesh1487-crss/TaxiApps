import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { CancelService } from '../common/services/cancel.service';

@Component({
  selector: 'app-edit-user-cancellation',
  templateUrl: './edit-user-cancellation.component.html',
  styleUrls: ['./edit-user-cancellation.component.scss']
})
export class EditUserCancellationComponent implements OnInit {
  submitted = false;
  id: number;
  zoneArea: any;
  cancelModel: any;
  constructor(private formBuilder: FormBuilder,
    private cancelService: CancelService,
    private route: ActivatedRoute,
    public router: Router) { }
  registerForm: FormGroup;
  ngOnInit(): void {
   
    this.route
      .queryParams
      .subscribe(params => {
        // Defaults to 0 if no query param provided.
        this.id = Number(params['id']);
      });

      

    this.registerForm = this.formBuilder.group({
      AreaName: ['', Validators.required],
      paymentStatus: ['', Validators.required],
      arrivalStatus: ['', Validators.required],
      cancelReasonEnglish: ['', Validators.required],
      cancelReasonArabic: ['', Validators.required],
      cancelReasonSpanish: ['', Validators.required]
    });
    this.cancelService.listArea().subscribe(res => {
        this.zoneArea = res.content;
      })

    this.getbyId();
   
  }
    getbyId() {
    this.cancelService.getByUserId(this.id).subscribe(res => {
      if (res.isOK) {
        this.cancelModel = res.content;
        this.registerForm = this.formBuilder.group({
          AreaName: [res.content.zonetypeid, Validators.required],
          paymentStatus: [this.cancelModel.paymentstatus, Validators.required],
          arrivalStatus: [this.cancelModel.arrivalstatus, Validators.required],
          cancelReasonEnglish: [this.cancelModel.cancelReasonEnglish, Validators.required],
          cancelReasonArabic: [this.cancelModel.cancelReasonArabic, Validators.required],
          cancelReasonSpanish: [this.cancelModel.cancelReasonSpanish, Validators.required]
        });
      }
    })
  }


  Areaval = '';
  dropChange(evt, role) {
    switch (role) {
      case "Area":
        this.Areaval = evt.srcElement.value;
        break;
    }
  }
  get f() { return this.registerForm.controls; }
  onSubmit() {
    this.submitted = true;
    if (this.registerForm.invalid) {
      return;
  }
    var cancelModal = {
      paymentStatus: this.registerForm.controls.paymentStatus.value,
      arrivalStatus: this.registerForm.controls.arrivalStatus.value,
      cancelReasonEnglish: this.registerForm.controls.cancelReasonEnglish.value,
      cancelReasonArabic: this.registerForm.controls.cancelReasonArabic.value,
      cancelReasonSpanish: this.registerForm.controls.cancelReasonSpanish.value,
      id: this.id,
      zonetypeid:this.registerForm.controls.AreaName.value
    };
    this.cancelService.editUser(cancelModal).subscribe(res => {
      if (res.isOK) {
        this.router.navigate(['user-cancellation']);
      }
    });
  }
  cancel(){
    this.router.navigate(['user-cancellation']);
  }
}