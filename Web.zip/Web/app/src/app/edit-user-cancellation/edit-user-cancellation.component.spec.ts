import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditUserCancellationComponent } from './edit-user-cancellation.component';

describe('EditUserCancellationComponent', () => {
  let component: EditUserCancellationComponent;
  let fixture: ComponentFixture<EditUserCancellationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditUserCancellationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditUserCancellationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
