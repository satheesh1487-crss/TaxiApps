import { Component, OnInit} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ServiceLocationService } from '../common/services/servicelocation.service';
import { Router, ActivatedRoute} from '@angular/router';
import { ManageFAQService } from '../common/services/manageFAQ.service';

@Component({
  selector: 'app-edit-faq',
  templateUrl: './edit-faq.component.html',
  styleUrls: ['./edit-faq.component.scss']
})
export class EditFaqComponent implements OnInit {
  authService: any; 
  isSubmitted = false;
  ErrorMessage
  areaVal = '';
  id
  registerForm: FormGroup;
  arealist: any;
  constructor(private formBuilder: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    public manageFAQService: ManageFAQService,
    public serviceLocationService: ServiceLocationService,) { }

  ngOnInit(): void {
    this.route
      .queryParams
      .subscribe(params => {
       this.id = Number(params['id']);
      });

    this.registerForm = this.formBuilder.group({
      FAQ_Question: ['', Validators.required],
      FAQ_Answer: ['', Validators.required],
      complaint_Type: ['', Validators.required]
    });  
    this.getbyId();  
  }

  getbyId() {
    this.manageFAQService.getById(this.id).subscribe(res => {
      if (res.isOK) {                
        this.registerForm = this.formBuilder.group({         
          FAQ_Question: [res.content.FAQ_Question, Validators.required],  
          FAQ_Answer: [res.content.FAQ_Answer, Validators.required],
          complaint_Type: [res.content.Complaint_Type, Validators.required],       
        });      
      }
    })
  }

  onSubmit() { 
    this.isSubmitted = true;
    if (!this.registerForm.valid) {
      return;
    }

       var faq={
        FAQ_Question:this.registerForm.controls.FAQ_Question.value,
        FAQ_Answer:this.registerForm.controls.FAQ_Answer.value,
        Complaint_Type:this.registerForm.controls.complaint_Type.value,
      servicelocid:this.registerForm.controls.servicelocid,   
      id:this.id 
    };
    this.manageFAQService.edit(faq,this.id).subscribe(res => {
      if (res.isOK) {
        this.router.navigate(['manage-faq']);
      }
    });

  } 
  get f() {
    return this.registerForm.controls;
  } 
  cancel(){
    this.router.navigate(['manage-faq']);
  } 
}
