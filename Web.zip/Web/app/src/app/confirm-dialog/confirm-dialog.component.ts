import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
export interface ConfirmationData {
  header: string;
  message: string;
  icon: string;
  buttonText:{
  primarybtn: string;
  cancelbtn: string;
  }
}
@Component({
  selector: 'app-confirm-dialog',
  templateUrl: './confirm-dialog.component.html',
  styleUrls: ['./confirm-dialog.component.scss']
})
export class ConfirmDialogComponent implements OnInit {
   
  constructor(
    private dialogRef: MatDialogRef<ConfirmDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data: ConfirmationData
  ) { 

    
     // Diasable/ Enable modal dialog close, when click out side the modal
     dialogRef.disableClose = true;
  }

  ngOnInit() {
  }

  accept() {
    this.dialogRef.close({
      isOk: true,
      data: {}
    });
  }

  reject() {
    this.dialogRef.close({
      isOk: false,
      data: {}
    });
  }

}

 
