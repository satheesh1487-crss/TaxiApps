import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SurgePricingComponent } from './surge-pricing.component';

describe('SurgePricingComponent', () => {
  let component: SurgePricingComponent;
  let fixture: ComponentFixture<SurgePricingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SurgePricingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SurgePricingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
