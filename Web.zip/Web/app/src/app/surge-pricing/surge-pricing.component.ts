import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { VehicleService } from '../common/services/vehicle.service';
import { Router, ActivatedRoute } from '@angular/router';

declare var $:any;

@Component({
  selector: 'app-surge-pricing',
  templateUrl: './surge-pricing.component.html',
  styleUrls: ['./surge-pricing.component.scss']
})
export class SurgePricingComponent implements OnInit {
  id: number;
  registerForm:FormGroup;
  submitted;
  constructor(private formBuilder: FormBuilder,
    private vehicleService: VehicleService,
    private route: ActivatedRoute,
    private router: Router,
    private snackBar: MatSnackBar) { }

  ngOnInit(): void {

    this.route
    .queryParams
    .subscribe(params => {
      // Defaults to 0 if no query param provided.
      this.id = Number(params['id']);
    });
  this.registerForm = this.formBuilder.group({
    surgepricetype: ['',Validators.required],
    starttime: ['', Validators.required],
    endtime: ['', Validators.required],
    peaktype: ['', Validators.required],
    surgepricevalue: ['', Validators.required],
});
this.getbyId();

    $(document).ready(function() {
      $('#multiple-checkboxes').multiselect({
        includeSelectAllOption: true,
      });
    
  });
  

  }
  getbyId(){
    this.vehicleService.getBySurge(this.id).subscribe(res => {

     
        this.registerForm = this.formBuilder.group({

          surgepricetype: [res.content.surgepricetype, [Validators.required]],
          starttime: [res.content.starttime, [Validators.required]],
          endtime: [res.content.endtime, [Validators.required]],
          peaktype: [res.content.peaktype, [Validators.required]], 
          surgepricevalue: [res.content.surgepricevalue, [Validators.required]], 
      });
    })
  }
  onSubmit(){ 
    
    this.submitted = true;
    /*if (!this.registerForm.valid) {
      return;
    } 
*/
    var body ={
      zoneid:this.id,
      surgepricetype: this.registerForm.controls.surgepricetype.value,
      starttime:this.registerForm.controls.starttime.value,
      endtime:this.registerForm.controls.endtime.value,
      peaktype:this.registerForm.controls.peaktype.value,
      surgepricevalue:this.registerForm.controls.surgepricevalue.value
      }
   
    this.vehicleService.saveSurge(body).subscribe(res=>{
    if(res.isOK)
    {
      this.snackBar.open(res.message, 'Fechar', {
        duration: 2000,
        panelClass: ['close-snackbar']
      });
      this.getbyId();
    }
    else{
      this.snackBar.open(res.message, 'Fechar', {
        duration: 2000,
        panelClass: ['close-snackbar']
      });
    }
    })
      
      }
      cancel(){
        this.router.navigate(['manage-pricing']);
      }
}
