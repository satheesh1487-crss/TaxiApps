import { Component,ViewChild} from '@angular/core';
import { AuthService } from './common/auth/auth.service';
import { AppConfigService } from './common/services/app-initializer.service';
import { TranslateService } from './common/utility/translate.service';
import { TranslatePipe } from './common/utility/translate.pipe';
import { ErrorService } from './common/services/error.services';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
 
  showLoader: boolean =false;

  isLoggedIn=false;
  constructor(private authService:AuthService
    ,public appConfig:AppConfigService,
    private translate: TranslatePipe,
    private errorService: ErrorService,
    private translateService: TranslateService)
  {
     this.authService.isLoggedIn.subscribe(res=>{
       this.isLoggedIn =res;
     });
    /* this.errorService.showLoader.subscribe(res=>  {           
      this.showLoader=res; 
      console.log(res)         
    });*/
  }
  ngOnInit(){

    this.translateService.activeLangChanged.subscribe(event => {

    });
  }


}
