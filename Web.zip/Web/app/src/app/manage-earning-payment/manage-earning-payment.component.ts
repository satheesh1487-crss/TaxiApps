import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { DriverService } from '../common/services/driver.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { ExcelService } from '../common/services/export.service';


@Component({
  selector: 'app-manage-earning-payment',
  templateUrl: './manage-earning-payment.component.html',
  styleUrls: ['./manage-earning-payment.component.scss']
})
export class ManageEarningPaymentComponent implements OnInit {
  displayedColumns: string[] = ['no', 'registrationcode', 'name', 'email', 'phonenumber', 'rating', 'status','action'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  result: any;
  driverEarning=[];
  constructor(public driverService:DriverService, public router:Router,private dialog: MatDialog,
    public exportService:ExcelService,
    private snackBar: MatSnackBar) {}
  

  ngOnInit(): void {
    this.driverService.listEarningsPayment().subscribe(res=>      
      { 
        this.driverEarning =res.content
        this.dataSource = new MatTableDataSource(res.content);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      })
  }
  ngAfterViewInit() { 
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  redirectEdit(id)
  {
    console.log('Edit RollId?=Id' +id);
    //this.router.navigate(['edit-role'], { queryParams: { id: id } });
  } 
  openDialog() {
    const dialogRef = this.dialog.open(ConfirmDialogComponent,{
      data:{
        message: 'Are you sure want to delete?',
        buttonText: {
          ok: 'Save',
          cancel: 'No'
        }
      }
    });
    const snack = this.snackBar.open('Snack bar open before dialog');

    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (confirmed) {
        snack.dismiss();
        const a = document.createElement('a');
        a.click();
        a.remove();
        snack.dismiss();
        this.snackBar.open('Closing snack bar in a few seconds', 'Fechar', {
          duration: 2000,
          panelClass: ['delete-snackbar']
        });
      }
    });
  }
  exportexcel():void {
    this.exportService.exportAsExcelFile(this.driverEarning, 'DriverEarning');
 }
}
