import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageEarningPaymentComponent } from './manage-earning-payment.component';

describe('ManageEarningPaymentComponent', () => {
  let component: ManageEarningPaymentComponent;
  let fixture: ComponentFixture<ManageEarningPaymentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageEarningPaymentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageEarningPaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
