import { Component, OnInit, NgZone, ElementRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MapsAPILoader, } from '@agm/core';
import { CurrencyService } from '../common/services/currency.service';
import { ServiceLocationService } from '../common/services/servicelocation.service';
import { ZoneService } from '../common/services/zone.service';
import { Router, ActivatedRoute } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
declare const google: any;

@Component({
  selector: 'app-edit-zone',
  templateUrl: './edit-zone.component.html',
  styleUrls: ['./edit-zone.component.scss']
})
export class EditZoneComponent implements OnInit {
  authService: any; 
  isSubmitted = false;
  lat;
  lng ;
  pointList: { latitude: number; longtitude: number }[] = [];
  polygondraw:{ lat:number, lng:number}[]=[];
  drawingManager: any;
  selectedShape: any;
  selectedArea = 0;
  private geoCoder;
  latitude: number;
  longitude: number;
  zoom: number;
  address: string;
  @ViewChild('search')
  public searchElementRef: ElementRef;
  ErrorMessage
  areaVal = '';
  currencyVal = '';
 
  currencylist = [];
  registerForm: FormGroup;
  arealist: any;
  id: number;
  modelZone;
  constructor(private formBuilder: FormBuilder,
    private mapsAPILoader: MapsAPILoader,
    private router: Router,
    private snackBar: MatSnackBar,
    public currencyService: CurrencyService,
    public zoneService: ZoneService,
    private route: ActivatedRoute,
    public serviceLocationService: ServiceLocationService,
    private ngZone: NgZone) { 
      this.start_end_mark.push(this.latlng[0]);
      this.start_end_mark.push(this.latlng[this.latlng.length - 1]);
    }

  ngOnInit(): void {
    this.route
    .queryParams
    .subscribe(params => {
      // Defaults to 0 if no query param provided.
      this.id = Number(params['id']);
    });
    this.getCurrency();
    this.registerForm = this.formBuilder.group({
      serviceslocid: ['', Validators.required],     
      unit: ['', Validators.required],
      zoneName: ['', Validators.required],
      SearchLocation: ['', Validators.required]
    }); 

    //load Places Autocomplete
    this.mapsAPILoader.load().then(() => {
      this.setCurrentPosition();
      this.geoCoder = new google.maps.Geocoder;
      let autocomplete = new google.maps.places.Autocomplete(this.searchElementRef.nativeElement);
      autocomplete.addListener("place_changed", () => {
        this.ngZone.run(() => {
          //get the place result
          let place: google.maps.places.PlaceResult = autocomplete.getPlace();

          //verify result
          if (place.geometry === undefined || place.geometry === null) {
            return;
          }
          //set latitude, longitude and zoom
          this.latitude = place.geometry.location.lat();
          this.longitude = place.geometry.location.lng();
          this.zoom = 12;
        });
      });
    });
  }

  getById(){
    this.zoneService.getById(this.id).subscribe(res=>  {       
      if(res.isOK){       
        this.modelZone = res.content;
        this.registerForm = this.formBuilder.group({
          serviceslocid: [res.content.serviceslocid, Validators.required],
          zoneName: [res.content.zoneName, Validators.required],
          unit: [res.content.unit, Validators.required],
          
          zonePolygoneList:[this.modelZone.zonepolygonlist]
      });
      this.modelZone.zonepolygonlist.forEach(element => {
       
        this.polygondraw.push({lat:element.lat,lng:element.lng});
      });
      this.polygondraw.push({lat:this.modelZone.zonepolygonlist[0].lat,lng:this.modelZone.zonepolygonlist[0].lng});
    this.latitude =  this.lat =this.modelZone.zonepolygonlist[0].lat;
    this.longitude=  this.lng =this.modelZone.zonepolygonlist[0].lng;
   this.setCurrentPosition();
      }
    }); 
  }
  onSubmit() {   
  
    this.isSubmitted = true; 
    if (!this.registerForm.valid) {
      return;
    }    
   
    var zone={
      zonePolygoneList:this.pointList.length===0 ? this.modelZone.zonepolygonlist:this.pointList,
      serviceslocid:this.registerForm.controls.serviceslocid.value,     
      unit:this.registerForm.controls.unit.value,
      zoneName:this.registerForm.controls.zoneName.value,   
      zoneid:this.id,     
    }
    this.zoneService.edit(zone).subscribe(res=>{
      if(res.isOK){
        this.router.navigate(['manage-zone']);
      }else
      {
        this.snackBar.open(res.message, 'Fechar', {
          duration: 2000,
          panelClass: ['close-snackbar']
        });
      }
    });
  }   

  markerDragEnd($event: MouseEvent) {
    this.getAddress(this.latitude, this.longitude);
  }

  getAddress(latitude, longitude) {
    this.geoCoder.geocode({ 'location': { latitude: latitude, longtitude: longitude } }, (results, status) => {
    
      if (status === 'OK') {
        if (results[0]) {
          this.zoom = 12;
          this.address = results[0].formatted_address;
        } else {
          window.alert('No results found');
        }
      } else {
        window.alert('Geocoder failed due to: ' + status);
      }

    });
  }
  
  get f() {
    return this.registerForm.controls;
  } 





  onMapReady(map) {
    this.initDrawingManager(map);
  }

  initDrawingManager = (map: any) => {
    const self = this;
    const options = {
      drawingControl: true,
      drawingControlOptions: {
        drawingModes: ['polygon'],
      },
      polygonOptions: {
        draggable: true,
        editable: true,
      },
      drawingMode: google.maps.drawing.OverlayType.POLYGON,
    };
    this.drawingManager = new google.maps.drawing.DrawingManager(options);
    this.drawingManager.setMap(map);
    google.maps.event.addListener(
      this.drawingManager,
      'overlaycomplete',
      (event) => {
        if (event.type === google.maps.drawing.OverlayType.POLYGON) {
          const paths = event.overlay.getPaths();
          for (let p = 0; p < paths.getLength(); p++) {
            google.maps.event.addListener(
              paths.getAt(p),
              'set_at',
              () => {
                if (!event.overlay.drag) {
                  self.updatePointList(event.overlay.getPath());
                }
              }
            );
            google.maps.event.addListener(
              paths.getAt(p),
              'insert_at',
              () => {
                self.updatePointList(event.overlay.getPath());
              }
            );
            google.maps.event.addListener(
              paths.getAt(p),
              'remove_at',
              () => {
                self.updatePointList(event.overlay.getPath());
              }
            );
          }
          self.updatePointList(event.overlay.getPath());
        }
        if (event.type !== google.maps.drawing.OverlayType.MARKER) {
          // Switch back to non-drawing mode after drawing a shape.
          self.drawingManager.setDrawingMode(null);
          // To hide:
          self.drawingManager.setOptions({
            drawingControl: false,
          });

          // set selected shape object
          const newShape = event.overlay;
          newShape.type = event.type;
          this.setSelection(newShape);

        }
      }
    );
  }
  private setCurrentPosition() {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition((position) => {
        this.lat = position.coords.latitude;
        this.lng = position.coords.longitude;
      });
    }
  }
  clearSelection() {
    if (this.selectedShape) {
      this.selectedShape.setEditable(false);
      this.selectedShape = null;
      this.pointList = [];
    }
  }
  setSelection(shape) {
    this.clearSelection();
    this.selectedShape = shape;
    shape.setEditable(true);
  }

  deleteSelectedShape() {
    if (this.selectedShape) {
      this.selectedShape.setMap(null);
      this.selectedArea = 0;
      this.pointList = [];
      // To show:
      this.drawingManager.setOptions({
        drawingControl: true,
      });
    }
  }

  updatePointList(path) {
    this.pointList = [];
    const len = path.getLength();
    for (let i = 0; i < len; i++) {
      this.pointList.push(
        path.getAt(i).toJSON()
      );
    }
    this.selectedArea = google.maps.geometry.spherical.computeArea(
      path
    );
  }

  getCurrency() {
  
    this.serviceLocationService.list().subscribe(res => {
      if (res.isOK) {
        this.arealist = res.content;
        this.getById();
      }
    });
  }


  start_end_mark = [];
  latlng = [
    [
      11.004556,
      76.961632
    ],
    [
      12.972442,
      77.580643
    ],
    [
      13.067439,
    	80.237617
    ]
    ,
    [
      13.067439,
    	80.237617
    ]
  ];
}
