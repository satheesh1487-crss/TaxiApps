import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { CancelService } from '../common/services/cancel.service';

@Component({
  selector: 'app-add-driver-cancellation',
  templateUrl: './add-driver-cancellation.component.html',
  styleUrls: ['./add-driver-cancellation.component.scss']
})
export class AddDriverCancellationComponent implements OnInit {
  submitted = false;
  zoneArea: any;
  constructor(private formBuilder: FormBuilder,
    private cancelService:CancelService,
    private snackBar: MatSnackBar,
    public router:Router) { }
  registerForm:FormGroup;
  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      AreaName: ['', Validators.required],
      paymentStatus: ['', Validators.required],
      arrivalStatus: ['', Validators.required],
      cancelReasonEnglish: ['', Validators.required],
      cancelReasonArabic: ['', Validators.required],
      cancelReasonSpanish: ['',Validators.required]
    });
    this.cancelService.listArea().subscribe(res=>      
      { 
        this.zoneArea = res.content; 
      })
  }
  Areaval='';
  dropChange(evt,role){
    switch(role){
      case "Area":
        this.Areaval=evt.srcElement.value;
        break;
      }
  }
  get f() { return this.registerForm.controls; }
  onSubmit() {
    this.submitted = true;
 
    if (!this.registerForm.valid) {
        return;
    }
    var cancelModal = {
      zonetypeid:this.registerForm.controls.AreaName.value,
      paymentStatus: this.registerForm.controls.paymentStatus.value,
      arrivalStatus: this.registerForm.controls.arrivalStatus.value,
      cancelReasonEnglish: this.registerForm.controls.cancelReasonEnglish.value,
      cancelReasonArabic: this.registerForm.controls.cancelReasonArabic.value,
      cancelReasonSpanish: this.registerForm.controls.cancelReasonSpanish.value,
    };
    this.cancelService.saveDriver(cancelModal).subscribe(res => {
      if (res.isOK) {
        this.router.navigate(['driver-cancellation']);
      }
      else
      {
        this.snackBar.open(res.message, 'Fechar', {
          duration: 2000,
          panelClass: ['close-snackbar']
        });
      }
        });    
  }
  cancel(){
    this.router.navigate(['driver-cancellation']);
  }  
}
