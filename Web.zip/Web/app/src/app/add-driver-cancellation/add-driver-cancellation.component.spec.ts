import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddDriverCancellationComponent } from './add-driver-cancellation.component';

describe('AddDriverCancellationComponent', () => {
  let component: AddDriverCancellationComponent;
  let fixture: ComponentFixture<AddDriverCancellationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddDriverCancellationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddDriverCancellationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
