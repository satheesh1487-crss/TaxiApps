import { Component, OnInit } from '@angular/core';
import { ZoneService } from '../common/services/zone.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-map-view',
  templateUrl: './map-view.component.html',
  styleUrls: ['./map-view.component.scss']
})
export class MapViewComponent implements OnInit {
   
  polygondraw:{ lat:number, lng:number}[]=[];
  constructor(private zoneService:ZoneService,
    private route: ActivatedRoute,) {
    // this i write because to display a marks on first place and last place
    
  }
  id
  ngOnInit() {
  /**   this.zoneService.getById(this.id).subscribe(res=>  {       
      if(res.isOK){       
        this.modelZone = res.content.zonepolygonlist;
        this.start_end_mark.push(res.content.zonepolygonlist[0]);
  this.start_end_mark.push(res.content.zonepolygonlist[res.content.zonepolygonlist.length - 1]);
      }
    }); */


    this.route
    .queryParams
    .subscribe(params => {
      // Defaults to 0 if no query param provided.
      this.id = Number(params['id']);
    });


    this.getById();
  }
  modelZone;
  lat;
  lng;
  getById(){
    this.zoneService.getById(this.id).subscribe(res=>  {       
      if(res.isOK){       
        this.modelZone = res.content;
        
      this.modelZone.zonepolygonlist.forEach(element => {
       
        this.polygondraw.push({lat:element.lat,lng:element.lng});
      });
      this.polygondraw.push({lat:this.modelZone.zonepolygonlist[0].lat,lng:this.modelZone.zonepolygonlist[0].lng});
      this.lat= this.modelZone.zonepolygonlist[0].lat;
      this.lng =this.modelZone.zonepolygonlist[0].lng;
      }


      console.log(this.lat + this.lng)
    }); 
  }
 
}
    
      
 
