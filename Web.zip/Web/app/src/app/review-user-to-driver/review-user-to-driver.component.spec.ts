import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReviewUserToDriverComponent } from './review-user-to-driver.component';

describe('ReviewUserToDriverComponent', () => {
  let component: ReviewUserToDriverComponent;
  let fixture: ComponentFixture<ReviewUserToDriverComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReviewUserToDriverComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReviewUserToDriverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
