import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { ReviewService } from '../common/services/review.service';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-review-user-to-driver',
  templateUrl: './review-user-to-driver.component.html',
  styleUrls: ['./review-user-to-driver.component.scss']
})
export class ReviewUserToDriverComponent implements OnInit {
  displayedColumns: string[] = ['no', 'userName', 'rating','comment','requestid','driverName','isActive','action'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  result: any;

  constructor( public snackBar: MatSnackBar,
    private dialog: MatDialog,public reviewService:ReviewService, public router:Router) { }

  ngOnInit(): void {
    this.fillUser();
   
  }
  fillUser(){
    this.reviewService.listUsertoDriver().subscribe(res=>      
      { 
        console.log(res)
        this.dataSource = new MatTableDataSource(res.content);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      })
  }
  ngAfterViewInit() { 
  }
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  redirectEdit(id)
  {
    console.log('Edit RollId?=Id' +id);
    //this.router.navigate(['edit-role'], { queryParams: { id: id } });
  } 
  updateStatus(id,status) {
    
    const dialogRef = this.dialog.open(ConfirmDialogComponent,{
      data:{
        message: 'Are you sure want to change the status?',
        buttonText: {
          primarybtn: 'Confirm',
          cancelbtn: 'Cancel'
        }
      }
    });
    
    dialogRef.afterClosed().subscribe((confirmed) => {
      
      if (confirmed.isOk) {
        this.reviewService.status(id,status).subscribe(res=>{
          if(res.isOK){
            this.snackBar.open(res.content, 'Fechar', {
              duration: 2000,
              panelClass: ['close-snackbar']
            });
            this.fillUser(); 
          }
        })
        
      }
    });
  }

}
