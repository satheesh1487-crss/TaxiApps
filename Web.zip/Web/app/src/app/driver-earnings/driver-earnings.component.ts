import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-driver-earnings',
  templateUrl: './driver-earnings.component.html',
  styleUrls: ['./driver-earnings.component.scss']
})
export class DriverEarningsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
