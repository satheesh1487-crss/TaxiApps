import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewMoreScheduleComponent } from './view-more-schedule.component';

describe('ViewMoreScheduleComponent', () => {
  let component: ViewMoreScheduleComponent;
  let fixture: ComponentFixture<ViewMoreScheduleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewMoreScheduleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewMoreScheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
