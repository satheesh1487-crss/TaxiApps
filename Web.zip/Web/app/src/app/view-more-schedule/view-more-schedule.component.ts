import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-more-schedule',
  templateUrl: './view-more-schedule.component.html',
  styleUrls: ['./view-more-schedule.component.scss']
})
export class ViewMoreScheduleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
